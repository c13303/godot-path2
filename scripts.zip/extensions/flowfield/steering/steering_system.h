#pragma once

#include "../core/types.h"
#include "../core/global_config.h"
#include "../grid/spatial_grid.h"
#include "agent.h"
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <cmath>
#include <algorithm>

namespace ffcore
{
    class FlowField;
    class SpatialGrid;
    class AgentManager;
    class SteeringSystem;

    struct ActiveAoE
    {
        Vec2 pos;
        Vec2 direction;        // ignored when angle_degrees >= 360 (radial)
        double radius = 0.0;
        double angle_degrees = 360.0;
        double force = 0.0;
        double friction_loss = 0.0;
        double falloff = 0.0;
        bool detach_flow = false;
        double control_suppression = 1.0;
        double control_suppression_duration = 0.0;
        int ignored_agent_id = -1;
        int owner_id = -1; // if valid, zone.pos tracks this agent's live position each tick
        Vec2 follow_offset; // added to the owner's live position so the zone can sit off-center
        int affected_smash_classes = 0;
        double time_left = 0.0;
        std::unordered_set<int> hit_ids;
    };

    struct BottleneckReservation
    {
        int owner_id = -1;
        double time_left = 0.0;
    };

    // Generic static circular obstacle. The C++ core knows nothing about what it
    // represents game-side (turret, prop, ...): it is only a position + radius that
    // moving agents are repelled from. Never registered as an agent, never updated
    // per tick, never iterated by AoE/fight/flowfield systems.
    struct StaticObstacle
    {
        int id = -1;
        Vec2 position;
        double radius = 0.0;
        double push_strength = 1.0;
    };

    class SteeringSystem
    {
    public:
        SteeringSystem();

        int register_agent(const Vec2 &pos, double max_speed, FlowField *flow);
        void unregister_agent(int id);

        void set_grid(SpatialGrid *g);
        void set_default_flowfield(FlowField *f);

        void set_agent_manager(AgentManager *m) { agent_manager = m; }

        const AgentData *get_agent(int id) const;
        void reactivate_agents_for_field(FlowField *field);

        void smooth_stop(int id);
        void update_all(double delta);
        void set_agent_group(int id, GroupID group);
        int register_agent_with_id(int fixed_id, const Vec2 &pos, double max_speed, FlowField *flow);
        void set_agent_flow_ptr(int id, FlowField *ff);
        void set_agent_control_mode(int id, int mode);
        void set_agent_input(int id, const Vec2 &direction);
        void set_agent_manual_motion(int id, double acceleration, double deceleration);
        void set_agent_profile(int id, const AgentProfile &profile);
        void apply_smash_impulse(int id, const Vec2 &direction, double force, double friction_loss, double delay, bool detach_flow, double control_suppression, double control_suppression_duration);
        void apply_area_smash(const Vec2 &pos, double radius, const Vec2 &direction, double force, double friction_loss, double falloff, bool detach_flow, double control_suppression, double control_suppression_duration, int ignored_agent_id, int affected_smash_classes);
        void apply_cone_smash(const Vec2 &pos, double radius, const Vec2 &direction, double angle_degrees, double force, double friction_loss, double falloff, bool detach_flow, double control_suppression, double control_suppression_duration, int ignored_agent_id, int affected_smash_classes);
        void apply_explosion(const Vec2 &pos, double radius, double intensity, double friction_loss);
        void apply_explosion_filtered(const Vec2 &pos, double radius, double intensity, double friction_loss, double falloff, int ignored_agent_id, double control_suppression, double control_suppression_duration, int affected_smash_classes);
        void spawn_aoe_zone(const Vec2 &pos, const Vec2 &direction, double radius, double angle_degrees, double duration, double force, double friction_loss, double falloff, bool detach_flow, double control_suppression, double control_suppression_duration, int ignored_agent_id, int affected_smash_classes, const Vec2 &follow_offset = Vec2(0, 0));
        void set_agent_never_rest(int id, bool value);
        void set_agent_phase(int id, AgentPhase phase, float eating_seconds);
        double get_max_fight_query_padding() const { return max_fight_query_padding; }

        // Path-follow API. Agent keeps its flow pointer (for wall-repel / bottleneck
        // physics), but desired direction is sourced from the path while one is active.
        void set_agent_path(int id, const std::vector<Vec2> &waypoints_world);
        void clear_agent_path(int id);
        bool agent_path_arrived(int id) const;

        // Generic static circular obstacle registry. Game-side decides which world
        // positions become obstacles; the core only stores/queries them so moving
        // agents are locally pushed around them. These are NOT agents.
        void register_static_obstacle(int id, const Vec2 &position, double radius, double push_strength = 1.0);
        void unregister_static_obstacle(int id);
        void clear_static_obstacles();
        bool has_static_obstacle(int id) const;
        int get_static_obstacle_count() const { return (int)static_obstacles.size(); }

    private:
        // Dedicated spatial index for static obstacles. Kept separate from the moving-agent
        // SpatialGrid so obstacle ids can never leak into id_to_index / agent iteration.
        struct StaticObstacleGrid
        {
            double cell_size = 32.0;
            std::unordered_map<long long, std::vector<int>> cells;
            std::unordered_map<int, long long> id_cell;

            long long key(int cx, int cy) const
            {
                return (static_cast<long long>(cx) << 32) ^ static_cast<unsigned int>(cy);
            }
            long long key_for(const Vec2 &p) const
            {
                int cx = (int)std::floor(p.x / cell_size);
                int cy = (int)std::floor(p.y / cell_size);
                return key(cx, cy);
            }
            void insert(int id, const Vec2 &p)
            {
                long long k = key_for(p);
                cells[k].push_back(id);
                id_cell[id] = k;
            }
            void remove(int id)
            {
                auto it = id_cell.find(id);
                if (it == id_cell.end())
                    return;
                auto cell_it = cells.find(it->second);
                if (cell_it != cells.end())
                {
                    auto &list = cell_it->second;
                    list.erase(std::remove(list.begin(), list.end(), id), list.end());
                    if (list.empty())
                        cells.erase(cell_it);
                }
                id_cell.erase(it);
            }
            void clear()
            {
                cells.clear();
                id_cell.clear();
            }
            void query(const Vec2 &p, double radius, std::vector<int> &out) const
            {
                out.clear();
                if (cells.empty())
                    return;
                int r = (int)std::ceil(radius / cell_size);
                int cx = (int)std::floor(p.x / cell_size);
                int cy = (int)std::floor(p.y / cell_size);
                for (int dy = -r; dy <= r; ++dy)
                    for (int dx = -r; dx <= r; ++dx)
                    {
                        auto it = cells.find(key(cx + dx, cy + dy));
                        if (it == cells.end())
                            continue;
                        for (int id : it->second)
                            out.push_back(id);
                    }
            }
        };

        std::vector<AgentData> agents;
        std::unordered_map<int, int> id_to_index;
        int next_id = 1;
        std::vector<ActiveAoE> active_aoes;
        std::unordered_map<FlowField *, std::unordered_map<int, BottleneckReservation>> bottleneck_reservations;
        double max_fight_query_padding = 0.0;
        double max_world_radius = 0.0;

        // Static obstacle storage. Touched only on register/unregister/clear, never per tick.
        std::unordered_map<int, StaticObstacle> static_obstacles;
        StaticObstacleGrid static_obstacle_grid;
        double max_static_obstacle_radius = 0.0;

        FlowField *default_flow = nullptr;
        SpatialGrid *grid = nullptr;

        AgentManager *agent_manager = nullptr;

        Vec2 force_voisine(const AgentData &agent);
        // Soft static obstacle repulsion (pushes agents away from circular obstacles).
        Vec2 static_obstacle_repulsion_force(const AgentData &agent);
        // Hard depenetration: pushes an agent's foot point out of any overlapping static
        // obstacle after integration. Guarantees blocking even when soft steering is
        // damped by lerp/momentum. Generic: applies to any moving agent.
        void resolve_static_obstacle_overlap(AgentData &agent);
        Vec2 wall_repulsion_force(const AgentData &a, FlowField *ff);
        void apply_bottleneck_traffic(AgentData &agent, FlowField *ff, Vec2 &target_velocity, double delta);
        Vec2 desired_velocity_for_flow(const AgentData &agent, FlowField *ff, const Vec2 &nav_dir, const Vec2 &wall_repel, const Vec2 &agent_separation, const Vec2 &static_obstacle_repel, double target_speed) const;
        void ultimate_wall_correction(AgentData &a, FlowField *ff, double delta);
        Vec2 apply_walk_with_walls(const AgentData &agent, const Vec2 &step, FlowField *ff);
        bool is_agent_footprint_navigable(const Vec2 &body_position, const AgentProfile &profile, FlowField *ff) const;
        AgentProfile sanitize_agent_profile(const AgentProfile &profile) const;
        void recompute_hitbox_query_extents();
    };

    SteeringSystem *get_global_steering_system();

} // namespace ffcore
