extends Node
class_name BuildingManager

signal startup_loading_progress(progress: float, label: String)
signal startup_loading_finished

const AGENT_SCENE: PackedScene = preload("res://scenes/entities/character.tscn")
const BUILD_TILES_INDEX_PATH: String = "res://scripts/map/build_tiles_index.tres"
const DEFAULT_SPAWN_COOLDOWN: float = 2.0
const EATING_COOLDOWN: float = 5.0
const IDLE_GROUP: int = 0
const INVALID_CELL: Vector2i = Vector2i(2147483647, 2147483647)
const EXIT_WALL_ATLAS: Vector2i = Vector2i(13, 0)
const PLANT_ZONE_MARGIN: int = 2
# Max walkable path length (in cells) allowed between two plants for them to share
# a garden, measured through walkable cells so walls split gardens. BFS from a
# seed plant is bounded by this radius and re-seeded from each plant it absorbs,
# so a chain of plants each within this distance forms one connected garden.
#
# Matches the OLD effective merge reach: gardens used to merge when their
# PLANT_ZONE_MARGIN-radius (2) zone boxes were 8-adjacent, i.e. when two plants
# were within Chebyshev distance 2 + 2 + 1 = 5. In open floor a BFS step (incl.
# diagonals) advances Chebyshev distance by 1, so a bound of 5 reproduces that
# reach while remaining wall-aware.
const GARDEN_LINK_DISTANCE: int = PLANT_ZONE_MARGIN * 2 + 1
const SPAWN_FAILURE_WARN_INTERVAL_MS: int = 3000

# Garden access-cell scoring penalties. Distance / escape cost stays the main
# driver; these only nudge selection away from obviously bad local geometry (a
# wall-pocket exit that forces an immediate reversal, a dead-ended outside tile).
# They are deliberately conservative and additive: a valid access cell is never
# rejected outright for being near walls, only ranked slightly lower when its
# continuation geometry is also poor. Tune as needed.
const ACCESS_NO_OUTSIDE_PENALTY: float = 1000.0
const ACCESS_EXIT_WORSE_PENALTY: float = 100.0
const ACCESS_EXIT_FLAT_PENALTY: float = 10.0
const ACCESS_DEAD_CONTINUATION_PENALTY: float = 100.0
const ACCESS_NARROW_CONTINUATION_PENALTY: float = 20.0
const ACCESS_REVERSAL_PENALTY: float = 100.0
const ACCESS_TURN_PENALTY: float = 5.0
const ACCESS_BLOCKED_CARDINAL_PENALTY: float = 2.0
# Enter mode uses softer continuation penalties (the agent is heading inward, so
# outside continuation matters less than for exits).
const ACCESS_ENTER_DEAD_CONTINUATION_PENALTY: float = 30.0
const ACCESS_ENTER_NARROW_CONTINUATION_PENALTY: float = 10.0

@export var floorz: TileMapLayer
@export var wallz: TileMapLayer
@export var plantz: TileMapLayer
@export var buildings: TileMapLayer
@export var plant_manager: Node
@export var flow: Node
@export var agent_manager: Node
@export var pathfinder: Node
@export var parent_for_agents: Node
@export var global_config: Node
@export var debug_logs: bool = false
@export_group("CPP > Gardens")
@export var dont_shrink_gardens: bool = true
@export_group("")
@export_range(0, 32, 1, "or_greater") var empty_garden_local_retarget_radius: int = 5
# Hard upper bound on queued agents retargeted per frame after a garden rebuild.
# This is now a safety cap only — the *primary* limiter is garden_retarget_budget_ms
# below. Keeps the rebuild frame cheap by spreading the (expensive) re-path/escape
# work over several frames. Raise if reassignment feels too slow, lower if it causes
# frame spikes.
@export_range(1, 64, 1, "or_greater") var garden_retarget_budget_per_frame: int = 8
# Primary limiter: max intended time spent processing the garden retarget queue per
# frame. A single retarget can cost 15-20ms, so a count-based budget alone lets
# several expensive retargets stack into one big spike. With a time budget we always
# do at least one item (so the queue drains), then stop once we've spent this long —
# spreading a burst of waiting agents across several smaller frames instead of one.
# 0 falls back to one item per frame (the safest non-spiking behavior).
@export_range(0.0, 100.0, 0.5, "or_greater") var garden_retarget_budget_ms: float = 4.0
# Spawner processing budget. Previously every ready spawner was spawned+assigned in
# the same frame; with 4 spawners firing together that stacked 4 (individually
# sub-threshold) spawn passes into one 30-40ms hitch. Ready spawners are now queued
# and drained round-robin across frames: at most this many ready spawners per frame.
@export_range(1, 32, 1) var spawner_budget_per_frame: int = 1
# Optional time budget for draining the ready-spawner queue. We always do at least
# one ready spawner per frame (so the queue drains), then stop once we've spent this
# long. 0 disables the time check and falls back to the count cap above.
@export_range(0.0, 100.0, 0.5, "or_greater") var spawner_budget_ms: float = 4.0
@export var debug_show_plantzone: bool = true:
	set(value):
		debug_show_plantzone = value
		if _zone_overlay:
			_zone_overlay.visible = value
			_zone_overlay.queue_redraw()

var _tile_defs_by_atlas: Dictionary = {}
var _spawners: Dictionary = {}
var _spawn_timers: Dictionary = {}
# Round-robin queue of spawner cells that are ready to spawn (cooldown elapsed) but
# have not yet been drained this/last frame. _update_spawner_timers_and_enqueue_ready
# fills it; _drain_ready_spawner_queue_budgeted pops a bounded number per frame so the
# spawn+assign work of multiple ready spawners is spread over several frames instead
# of stacking into one hitch. _ready_spawner_queue_set mirrors the queued cells so a
# spawner can't be enqueued twice while it waits its turn.
var _ready_spawner_queue: Array[Vector2i] = []
var _ready_spawner_queue_set: Dictionary = {}  # Vector2i -> true
var _spawner_routes: Dictionary = {}
var _spawner_garden_routes: Dictionary = {}
# Route-cache hit/miss counters (lifetime-of-process), bumped in
# _get_or_create_spawner_garden_route. Used by the _process_spawners lag detector
# to attribute time to cache misses vs. hits.
var _route_cache_hits: int = 0
var _route_cache_misses: int = 0
# Per-pass count summary for the _process_spawners lag detector. Filled in during
# _process_spawners() and read by the parent warning at the call site. Pure
# instrumentation; never affects spawn behavior.
var _spawn_pass_stats: Dictionary = {}
# Parent-triggered retarget breakdown profiling. Child functions always fill these
# (cheap int writes) so the parent _retarget_agent_or_escape can emit ONE consolidated
# "debug_garden_lag_breakdown" line when it exceeds threshold — even when every inner
# section is individually below threshold and so wouldn't self-report. Pure
# instrumentation; never read by gameplay. See _reset_retarget_profile().
#   _last_local_retarget_profile      - filled by _try_local_retarget_agent
#   _last_find_local_retarget_profile - filled by _find_local_retarget_plant
#   _find_path_in_zone_accum          - per-retarget accumulator across every
#                                       _find_path_in_zone call (reset by the plant
#                                       search, added to by each path query).
var _last_retarget_profile: Dictionary = {}
var _last_local_retarget_profile: Dictionary = {}
var _last_find_local_retarget_profile: Dictionary = {}
var _find_path_in_zone_accum: Dictionary = {}
# Side-channel: _sync_pathfinder_zone_tiles writes the time it spent in
# _wall_blockers_for_cells here so the caller can split sync time into
# blocker-construction vs. the rest, without changing the void signature.
var _last_zone_blocker_us: int = 0
var _eating_agents: Dictionary = {}
var _eating_time: float = EATING_COOLDOWN
var _escaping_agents: Dictionary = {}
var _entry_path_agents: Dictionary = {}
var _astar_in_agents: Dictionary = {}
# Reverse index: target plant cell -> { nav_id -> true }, plus nav_id -> target cell.
# Lets plant removal find the (usually 0-2) agents heading for that exact plant in
# O(agents_targeting_this_plant) instead of scanning every _astar_in_agents entry.
# Maintained exclusively by _set_astar_in_agent / _erase_astar_in_agent (which call
# _register_/_unregister_astar_in_target). _register ALWAYS unregisters the nav_id
# from its previous bucket first, so a nav_id is in at most one bucket and the two
# dictionaries can never disagree. The plant-removal retarget additionally validates
# every bucket entry against the live record and scrubs any that don't match, so even
# a stale entry that slipped in can never be double-counted across removals.
var _astar_in_agents_by_target_plant: Dictionary = {}  # Vector2i -> { nav_id -> true }
var _astar_in_target_by_nav_id: Dictionary = {}        # nav_id -> Vector2i
# When true, _retarget_agents_targeting_removed_plant_only also runs the old full
# scan and warns on any mismatch with the index. OFF by default (reintroduces the
# very scan cost the index removes); flip on only to debug index consistency.
var _debug_check_retarget_index: bool = false
# Side-channel counts from the last _retarget_agents_targeting_removed_plant_only
# call, so the caller's lag warning can report what the index touched without the
# function having to return anything.
var _last_plant_retarget_astar_in: int = 0       # _astar_in_agents.size() at entry
var _last_plant_retarget_bucket: int = 0         # raw bucket entries for the cell
var _last_plant_retarget_affected: int = 0       # valid agents actually retargeted
var _last_plant_retarget_queued: int = 0         # of those, deferred to the queue
var _last_plant_retarget_stale: int = 0          # bucket entries dropped as invalid
var _last_plant_retarget_already_queued: int = 0 # valid but already in retarget queue
# Budgeted retargeting after a garden topology rebuild. When a rebuild invalidates
# the garden an agent was targeting/eating-in, we cannot afford to re-path every
# affected agent in the same frame (potential large spike). Instead each affected
# agent is detached from its stale path/flow cheaply, parked in "waiting_new_status",
# and queued here; _process_garden_retarget_queue() then re-assigns a bounded number
# of them per frame. Queue items are Dictionaries:
#   { "nav_id": int, "intent": String ("escape"|"retarget"), "spawner_cell": Vector2i }
# _garden_retarget_queued mirrors the queued nav_ids so we never double-enqueue.
var _garden_retarget_queue: Array[Dictionary] = []
var _garden_retarget_queued: Dictionary = {}  # nav_id -> true
var _scan_timer: float = 0.0
var _last_wall_signature: int = 0
var _last_scan_summary: String = ""
var _last_spawn_failure: String = ""
var _last_spawn_failure_at_ms: Dictionary = {}
var _flow_ready: bool = false
var _startup_loading_started: bool = false
var _startup_ready: bool = false
var _dirty_spawner_escapes: Dictionary = {}
# One escape flow field per exit-wall tile, shared by all monsters. Keyed by the
# exit-wall cell. Each value: { "escape_group": int, "escape_target_cell":
# Vector2i, "escape_world": Vector2, "ready": bool }. A finishing monster picks
# the exit with the lowest route cost from its position (FlowFieldNative.
# group_route_cost_at_world), so it leaves through the nearest reachable wall
# exit. Rebuilt only on dirty events (level load / walls changed).
var _exit_wall_escapes: Dictionary = {}  # Vector2i -> Dictionary
var _gardens: Dictionary = {}
var _garden_by_plant_cell: Dictionary = {}
var _dirty_gardens: Dictionary = {}
# Garden ids are monotonic and never reused: a full rebuild keeps climbing instead
# of resetting to 1, so an id from a previous rebuild can never collide with a new
# garden. _gardens_epoch is bumped on every full rebuild and stamped on each garden
# + each spawner route; a route is only current if its epoch matches, so stale
# routes (and their flow-field goals) from a previous night/rebuild are rejected
# even if a garden id/version happens to line up. Fixes night-2 agents flowing to a
# deleted night-1 garden's entry tile and oscillating there.
var _next_garden_id: int = 1
var _gardens_epoch: int = 0
# TEMP DEBUG (garden crash hunt): set true while iterating _gardens or
# _spawner_garden_routes so any erase that happens mid-iteration is reported
# before it can corrupt the iteration. Remove once the silent crash is confirmed
# fixed. See _erase_garden / _warn_if_iterating.
# Depth counter (not a bool) so nested guarded iterations don't clear the guard
# early. Iteration is considered active while _gardens_iter_depth > 0.
var _gardens_iter_depth: int = 0
var _garden_debug_logs: bool = true
# Eat-exit transition counters: monsters finishing eating attach directly to the
# existing per-exit-wall escape FF (no garden-exit selection, no per-agent A* out).
# A failure is expected to be rare and indicates an FF coverage/walkability bug.
var eat_exit_direct_ff_success: int = 0
var eat_exit_direct_ff_failed: int = 0
# Gardens found empty during a _gardens iteration; erased after the loop ends.
var _pending_empty_gardens: Dictionary = {}  # garden_id -> true
# Memoizes the expensive scored garden-entry selection (_nearest_garden_entry =
# _select_scored_garden_entry in "enter" mode, no escape group). The chosen entry
# depends only on (garden_id, source/spawner cell): scoring runs flow lookups +
# per-candidate neighbor/walkability scans over every entry cell, and the retarget
# path calls it once per (spawner, garden) pair for every agent, so many agents
# targeting the same routes recompute identical results. Keyed by "spawner|garden"
# so different spawners never share a (possibly far/bad) entry — the result is
# source-dependent, never cached by garden_id alone. Value: the selected entry
# Vector2i (may be INVALID_CELL — cached too, that "no entry" result is also reused).
# Invalidated wholesale on any topology/wall/entry rebuild (see
# _clear_garden_entry_resolve_cache call sites); plain plant eating that leaves the
# garden connected with the same entries does NOT touch it.
var _garden_entry_resolve_cache: Dictionary = {}  # "spawner|garden" -> Vector2i
# Retarget breakdown debug counters (read into the consolidated profile line).
# Per-call flag set by _nearest_garden_entry; per-resolve tallies accumulated by
# _select_spawner_garden_for_agent (which calls _nearest_garden_entry many times).
var _garden_entry_resolve_cache_hit: bool = false
var _garden_entry_resolve_hits: int = 0
var _garden_entry_resolve_misses: int = 0
# Cells reachable from any spawner over the walkable map. Recomputed once per
# garden rebuild (single source flood-fill); read when deciding if a garden is
# reachable. A sealed enclosure has no entry cell in this set, so it is ignored.
var _spawner_reachable_cells: Dictionary = {}  # Vector2i -> true
var _walkable_map_tiles: Dictionary = {}  # Vector2i -> true

# Day/night: set true once at least one monster has spawned during the current
# night, so an empty scene can flip back to day only after a real night ran.
var _spawned_this_night: bool = false

# Plant zone compatibility caches. Tiles use the floorz tilemap cell space.
var _plant_zone_tiles: Dictionary = {}  # Vector2i -> true
var _plant_zone_margin_tiles: Dictionary = {}  # Vector2i -> true (entry/exit candidates)
var _plant_zone_built: bool = false
var _zone_overlay: Node2D
var _show_enters_exits: bool = false
# When on, prints "x gardens recomputed with y entry points" every time gardens
# (and their entry points) are recomputed. Pushed from CppDebugOptions.verbose;
# _verbose_pushed flips true once that push has happened. Until then _is_verbose()
# pulls the value straight off the CPP node so the startup recompute is logged
# even if it runs before CppDebugOptions._ready().
var _verbose: bool = false
var _verbose_pushed: bool = false
var _cpp_debug_options: Node = null

const DEBUG_PLANTFF_FRAME_LAG_MS_FALLBACK: float = 100.0
const DEBUG_PLANTFF_FF_LAG_MS_FALLBACK: float = 10.0

func _frame_lag_threshold_ms() -> float:
	if global_config and global_config.has_method("get_debug_nav_frame_lag_ms"):
		return float(global_config.call("get_debug_nav_frame_lag_ms"))
	if global_config and global_config.has_method("get_debug_plantff_frame_lag_ms"):
		return float(global_config.call("get_debug_plantff_frame_lag_ms"))
	return DEBUG_PLANTFF_FRAME_LAG_MS_FALLBACK

func _ff_lag_threshold_ms() -> float:
	if global_config and global_config.has_method("get_debug_flowfield_rebuild_lag_ms"):
		return float(global_config.call("get_debug_flowfield_rebuild_lag_ms"))
	if global_config and global_config.has_method("get_debug_plantff_ff_lag_ms"):
		return float(global_config.call("get_debug_plantff_ff_lag_ms"))
	return DEBUG_PLANTFF_FF_LAG_MS_FALLBACK

# ---------------------------------------------------------------------------
# Granular garden/navigation lag instrumentation. The total-frame detector in
# _process() only says "the frame was slow"; these per-task detectors say WHICH
# garden/nav task spiked. Threshold comes from CppDebugOptions.debug_gardens_lag_ms
# (read directly off the node; not pushed to C++). 0 disables per-task warnings.
#
# Overhead discipline: time with get_ticks_usec() and ONLY build the (potentially
# large) context string when the elapsed time is over threshold. Never construct
# context inside hot per-agent loops unless the individual op itself is over.
# ---------------------------------------------------------------------------
const DEBUG_GARDENS_LAG_MS_FALLBACK: float = 15.0

func _find_cpp_debug_options() -> Node:
	# The node is "CPP" in the current scene (same path _is_verbose() uses).
	if not is_inside_tree():
		return null
	var scene: Node = get_tree().get_current_scene()
	if scene == null:
		return null
	var node: Node = scene.get_node_or_null("CPP")
	if node:
		return node
	node = scene.get_node_or_null("CppDebugOptions")
	if node:
		return node
	node = scene.find_child("CppDebugOptions", true, false)
	if node:
		return node
	return null

func _garden_lag_threshold_ms() -> float:
	if _cpp_debug_options == null:
		_cpp_debug_options = _find_cpp_debug_options()
	if _cpp_debug_options and "debug_gardens_lag_ms" in _cpp_debug_options:
		return float(_cpp_debug_options.get("debug_gardens_lag_ms"))
	return DEBUG_GARDENS_LAG_MS_FALLBACK

# Warn when a timed block exceeds the per-task threshold. `elapsed_us` is in
# microseconds (timed with get_ticks_usec()); output is reported in ms. `extra` is
# pre-built context — callers must build it cheaply (it is unconditional here, so
# only pass strings that are cheap to construct, or use the threshold check at the
# call site to gate expensive context). Use _over_garden_threshold_us() to gate
# heavy context construction before calling this.
func _warn_garden_task_lag_us(task_name: String, elapsed_us: int, extra: String = "") -> void:
	var threshold_ms: float = _garden_lag_threshold_ms()
	if threshold_ms <= 0.0:
		return
	var elapsed_ms: float = float(elapsed_us) / 1000.0
	if elapsed_ms <= threshold_ms:
		return
	var suffix: String = ""
	if extra != "":
		suffix = " " + extra
	push_warning("debug_garden_lag:%s %dms (threshold=%dms)%s" % [
		task_name,
		int(round(elapsed_ms)),
		int(threshold_ms),
		suffix
	])

# True when `elapsed_us` is over the per-task threshold. Lets a call site decide
# whether to spend cycles building an expensive context string before calling
# _warn_garden_task_lag_us(); returns false (and skips) when the detector is
# disabled (threshold <= 0).
func _over_garden_threshold_us(elapsed_us: int) -> bool:
	var threshold_ms: float = _garden_lag_threshold_ms()
	if threshold_ms <= 0.0:
		return false
	return (float(elapsed_us) / 1000.0) > threshold_ms

func set_empty_garden_local_retarget_radius(value: int) -> void:
	empty_garden_local_retarget_radius = maxi(0, value)

func set_eating_time(value: float) -> void:
	_eating_time = maxf(0.0, value)

func _ready() -> void:
	startup_loading_progress.emit(0.48, "Preparing zones")
	_load_tile_definitions()
	_migrate_special_tiles_from_wallz()
	_setup_plant_manager()
	_setup_zone_overlay()
	_wait_for_flow_ready()
	GameState.mode_changed.connect(_on_game_mode_changed)

func _on_game_mode_changed(is_night: bool) -> void:
	if not is_night:
		return
	# Entering night: start fresh so monsters spawn promptly.
	_validate_dirty_gardens()
	_rebuild_spawner_garden_route_cache()
	_spawned_this_night = false
	for cell in _spawn_timers.keys():
		_spawn_timers[cell] = 0.0

func _monster_count() -> int:
	return get_tree().get_nodes_in_group("monsters").size()

func _wait_for_flow_ready() -> void:
	var code_node: Node = null
	if flow:
		for child in flow.get_children():
			if child.has_signal("flow_field_ready"):
				code_node = child
				break
	if code_node == null:
		_flow_ready = true
		call_deferred("_run_startup_after_flow_ready")
		return
	if bool(code_node.get("is_ready")):
		_flow_ready = true
		call_deferred("_run_startup_after_flow_ready")
		return
	code_node.connect("flow_field_ready", Callable(self, "_on_flow_field_ready"))

func _on_flow_field_ready() -> void:
	_flow_ready = true
	call_deferred("_run_startup_after_flow_ready")

func _run_startup_after_flow_ready() -> void:
	if _startup_loading_started or _startup_ready:
		return
	_startup_loading_started = true
	startup_loading_progress.emit(0.55, "Building plant zone")
	await get_tree().process_frame

	_build_gardens_from_plants()
	_validate_dirty_gardens()
	startup_loading_progress.emit(0.70, "Finding spawner routes")
	await get_tree().process_frame

	await _sync_runtime_state()
	_startup_ready = true
	startup_loading_progress.emit(1.0, "Ready")
	startup_loading_finished.emit()

func _setup_zone_overlay() -> void:
	_zone_overlay = Node2D.new()
	_zone_overlay.name = "PlantZoneOverlay"
	_zone_overlay.z_index = -99
	_zone_overlay.z_as_relative = false
	_zone_overlay.visible = _plant_zone_debug_enabled()
	_zone_overlay.set_script(load("res://scripts/map/plant_zone_overlay.gd"))
	_zone_overlay.set("building_manager", self)
	var overlay_parent: Node = floorz.get_parent() if floorz and floorz.get_parent() else self
	overlay_parent.add_child(_zone_overlay)

func _plant_zone_debug_enabled() -> bool:
	if global_config and global_config.has_method("get_debug_show_zones"):
		return bool(global_config.call("get_debug_show_zones"))
	if global_config and global_config.has_method("get_debug_show_plant_zones"):
		return bool(global_config.call("get_debug_show_plant_zones"))
	return debug_show_plantzone

func _sync_plant_zone_debug_visibility() -> void:
	if not _zone_overlay:
		return
	var show: bool = _plant_zone_debug_enabled()
	if _zone_overlay.visible == show:
		return
	_zone_overlay.visible = show
	_zone_overlay.queue_redraw()

func _process(delta: float) -> void:
	if not _flow_ready or not _startup_ready:
		return
	var frame_start_us: int = Time.get_ticks_usec()
	var t: int = 0
	_scan_timer -= delta
	if _scan_timer <= 0.0:
		_scan_timer = 0.25
		t = Time.get_ticks_usec()
		_scan_buildings()
		_warn_garden_task_lag_us("_scan_buildings", Time.get_ticks_usec() - t,
			"spawners=%d" % _spawners.size())

	if not _dirty_spawner_escapes.is_empty():
		# Capture the count before the call: _drain_dirty_routes clears the dict.
		var dirty_escapes_before: int = _dirty_spawner_escapes.size()
		t = Time.get_ticks_usec()
		_drain_dirty_routes()
		_warn_garden_task_lag_us("_drain_dirty_routes", Time.get_ticks_usec() - t,
			"dirty_escapes=%d" % dirty_escapes_before)

	# Per-frame tasks: gate context construction on _over_garden_threshold_us so the
	# (string-formatting) context is only built on a real spike, never every frame.
	t = Time.get_ticks_usec()
	_process_eating_agents(delta)
	if _over_garden_threshold_us(Time.get_ticks_usec() - t):
		_warn_garden_task_lag_us("_process_eating_agents", Time.get_ticks_usec() - t,
			"eating=%d astar_in=%d escaping=%d" % [
				_eating_agents.size(), _astar_in_agents.size(),
				_escaping_agents.size()])

	t = Time.get_ticks_usec()
	_process_astar_in_arrivals()
	if _over_garden_threshold_us(Time.get_ticks_usec() - t):
		_warn_garden_task_lag_us("_process_astar_in_arrivals", Time.get_ticks_usec() - t,
			"entry=%d astar_in=%d" % [_entry_path_agents.size(), _astar_in_agents.size()])

	t = Time.get_ticks_usec()
	_process_plant_arrivals()
	if _over_garden_threshold_us(Time.get_ticks_usec() - t):
		_warn_garden_task_lag_us("_process_plant_arrivals", Time.get_ticks_usec() - t,
			"astar_in=%d eating=%d" % [_astar_in_agents.size(), _eating_agents.size()])

	t = Time.get_ticks_usec()
	_process_escape_arrivals()
	if _over_garden_threshold_us(Time.get_ticks_usec() - t):
		_warn_garden_task_lag_us("_process_escape_arrivals", Time.get_ticks_usec() - t,
			"escaping=%d" % _escaping_agents.size())

	t = Time.get_ticks_usec()
	var retarget_processed: int = _process_garden_retarget_queue()
	var retarget_elapsed_us: int = Time.get_ticks_usec() - t
	if _over_garden_threshold_us(retarget_elapsed_us):
		_warn_garden_task_lag_us("_process_garden_retarget_queue", retarget_elapsed_us,
			"processed=%d remaining=%d budget=%dms elapsed=%.1fms" % [
				retarget_processed,
				_garden_retarget_queue.size(),
				int(garden_retarget_budget_ms),
				float(retarget_elapsed_us) / 1000.0,
			])

	t = Time.get_ticks_usec()
	_process_spawners(delta)
	if _over_garden_threshold_us(Time.get_ticks_usec() - t):
		# Context (incl. the per-pass count summary) only built when over threshold.
		_warn_garden_task_lag_us("_process_spawners", Time.get_ticks_usec() - t,
			"spawners=%d processed=%d spawned=%d assigned=%d skipped=%d ready_remaining=%d budget_count=%d budget_ms=%.1f elapsed=%.1fms active_monsters=%d route_cache_hits=%d route_cache_misses=%d" % [
				_spawners.size(),
				int(_spawn_pass_stats.get("processed_spawners", 0)),
				int(_spawn_pass_stats.get("spawned_count", 0)),
				int(_spawn_pass_stats.get("assigned_count", 0)),
				int(_spawn_pass_stats.get("skipped_count", 0)),
				int(_spawn_pass_stats.get("ready_queue_remaining", 0)),
				spawner_budget_per_frame,
				spawner_budget_ms,
				float(_spawn_pass_stats.get("elapsed_ms", 0.0)),
				int(_spawn_pass_stats.get("active_monsters", -1)),
				_route_cache_hits,
				_route_cache_misses,
			])

	t = Time.get_ticks_usec()
	_sync_plant_zone_debug_visibility()
	_warn_garden_task_lag_us("_sync_plant_zone_debug_visibility", Time.get_ticks_usec() - t)

	var frame_us: int = Time.get_ticks_usec() - frame_start_us
	var frame_threshold_ms: float = _frame_lag_threshold_ms()
	if (float(frame_us) / 1000.0) > frame_threshold_ms:
		push_warning("debug_nav_total_frame_lag: %dms (threshold=%dms) eating=%d astar_in=%d escaping=%d retarget_queue=%d spawners=%d direct_ff_exit_success=%d direct_ff_exit_failed=%d" % [
			int(round(float(frame_us) / 1000.0)),
			int(frame_threshold_ms),
			_eating_agents.size(),
			_astar_in_agents.size(),
			_escaping_agents.size(),
			_garden_retarget_queue.size(),
			_spawners.size(),
			eat_exit_direct_ff_success,
			eat_exit_direct_ff_failed
		])

func _load_tile_definitions() -> void:
	_tile_defs_by_atlas.clear()
	var res: Resource = load(BUILD_TILES_INDEX_PATH)
	if not (res is JSON):
		return

	for key in res.data.keys():
		var definition: Variant = res.data[key]
		if not (definition is Dictionary):
			continue
		var tile_definition: Dictionary = definition as Dictionary
		var atlas: Array = tile_definition.get("atlas", [])
		if atlas.size() != 2:
			continue
		var atlas_key: String = _atlas_key(Vector2i(int(atlas[0]), int(atlas[1])))
		_tile_defs_by_atlas[atlas_key] = {
			"key": str(key),
			"kind": str(tile_definition.get("kind", "")),
			"cooldown": float(tile_definition.get("cooldown", DEFAULT_SPAWN_COOLDOWN))
		}

func _scan_buildings() -> void:
	if not buildings:
		return

	var t: int = Time.get_ticks_usec()
	var migrated: bool = _migrate_special_tiles_from_wallz()
	_warn_garden_task_lag_us("_migrate_special_tiles_from_wallz", Time.get_ticks_usec() - t,
		"migrated=%s" % str(migrated))

	t = Time.get_ticks_usec()
	var wall_signature: int = _tile_layer_signature(wallz)
	_warn_garden_task_lag_us("_tile_layer_signature", Time.get_ticks_usec() - t,
		"wall_cells=%d" % (wallz.get_used_cells().size() if wallz else 0))
	var walls_changed: bool = wall_signature != _last_wall_signature or migrated
	_last_wall_signature = wall_signature

	var seen_spawners: Dictionary = {}
	t = Time.get_ticks_usec()
	_scan_special_layer(buildings, seen_spawners)
	_scan_special_layer(wallz, seen_spawners)
	_warn_garden_task_lag_us("_scan_special_layer", Time.get_ticks_usec() - t,
		"seen_spawners=%d" % seen_spawners.size())
	_log_scan_summary(seen_spawners, migrated, walls_changed)

	for raw_spawner_cell in _spawners.keys():
		var cell: Vector2i = raw_spawner_cell
		if not seen_spawners.has(cell):
			_spawners.erase(cell)
			_spawn_timers.erase(cell)
			# Stale cells left in _ready_spawner_queue are skipped at drain time
			# (guarded by _spawners.has), but clear the mirror set so a re-added
			# spawner at the same cell isn't blocked from re-enqueueing.
			_ready_spawner_queue_set.erase(cell)
			_release_spawner_route(cell)
			_dirty_spawner_escapes.erase(cell)

	if walls_changed:
		_rebuild_walkable_map_cache()
		# Walls change navigation topology: a new wall can split a garden and a
		# removed wall can merge two. Re-cluster plants by walkable reachability
		# from scratch (single cached rebuild), then refresh cached spawner/garden
		# FFs against the new entries.
		if _plant_zone_built:
			_rebuild_plant_zone_from_layer()
		_rebuild_spawner_garden_route_cache()
		for raw_spawner_cell in _spawners.keys():
			_rebuild_spawner_plant_ff(raw_spawner_cell)
			_dirty_spawner_escapes[raw_spawner_cell] = true
		# Exit walls may have been added/removed: refresh per-exit escape FFs.
		var exits_us: int = Time.get_ticks_usec()
		_rebuild_exit_wall_escapes()
		_warn_garden_task_lag_us("_rebuild_exit_wall_escapes", Time.get_ticks_usec() - exits_us,
			"exits=%d" % _exit_wall_escapes.size())

func _sync_runtime_state() -> void:
	_scan_buildings()
	var spawner_cells: Array = _spawners.keys()
	var total_count: int = spawner_cells.size()
	if total_count == 0:
		startup_loading_progress.emit(0.98, "Ready")
		return
	var index: int = 0
	for raw_spawner_cell in spawner_cells:
		var spawner_cell: Vector2i = raw_spawner_cell
		_initialize_spawner_route(spawner_cell)
		index += 1
		var progress: float = 0.75 + (float(index) / float(total_count)) * 0.23
		startup_loading_progress.emit(progress, "Preparing routes")
		await get_tree().process_frame
	# Per-exit-wall escape FFs (shared by all monsters); built once at startup.
	_rebuild_exit_wall_escapes()

func _setup_plant_manager() -> void:
	if not plant_manager:
		return
	if plant_manager.has_method("initialize_from_layer"):
		plant_manager.call("initialize_from_layer")
	if plant_manager.has_signal("plant_added") and not plant_manager.is_connected("plant_added", Callable(self, "_on_plant_added")):
		plant_manager.connect("plant_added", Callable(self, "_on_plant_added"))
	if plant_manager.has_signal("plant_removed") and not plant_manager.is_connected("plant_removed", Callable(self, "_on_plant_removed")):
		plant_manager.connect("plant_removed", Callable(self, "_on_plant_removed"))

func _on_plant_added(_cell: Vector2i) -> void:
	_add_plant_to_gardens(_cell)
	_retarget_agents_for_garden_topology_change(_cell)
	if _zone_overlay:
		_zone_overlay.queue_redraw()

# Runtime plant removal (an agent ate a plant, or a plant was removed at runtime).
# This is CONTENT-ONLY: it never recomputes garden entry/access points and never
# triggers a full topology rebuild. We only narrow-retarget the agents that were
# specifically targeting the removed plant, and only fall back to the budgeted
# queue when the garden actually became empty. Full rebuilds are reserved for real
# topology changes (plant addition, walls/buildings, level load, manual rebuild).
func _on_plant_removed(cell: Vector2i) -> void:
	var removed_us: int = Time.get_ticks_usec()
	var result := _remove_plant_from_garden_content_only(cell)
	if not bool(result.get("was_removed", false)):
		return

	var garden_id := int(result.get("garden_id", 0))
	var became_empty := bool(result.get("became_empty", false))

	if became_empty and garden_id > 0:
		var empty_us: int = Time.get_ticks_usec()
		_handle_garden_became_empty(garden_id)
		_warn_garden_task_lag_us("_handle_garden_became_empty", Time.get_ticks_usec() - empty_us,
			"garden=%d retarget_queue=%d" % [garden_id, _garden_retarget_queue.size()])
	else:
		var rt_us: int = Time.get_ticks_usec()
		_retarget_agents_targeting_removed_plant_only(cell, garden_id)
		_warn_garden_task_lag_us("_retarget_agents_targeting_removed_plant_only", Time.get_ticks_usec() - rt_us,
			"garden=%d plant=%s astar_in=%d bucket_size=%d valid_affected=%d queued=%d already_queued=%d stale=%d indexed_targets=%d" % [
				garden_id, str(cell), _last_plant_retarget_astar_in,
				_last_plant_retarget_bucket, _last_plant_retarget_affected,
				_last_plant_retarget_queued, _last_plant_retarget_already_queued,
				_last_plant_retarget_stale, _astar_in_agents_by_target_plant.size()])

	if _zone_overlay:
		_zone_overlay.queue_redraw()

	if _no_plants_remaining():
		_queue_escape_for_all_monsters_budgeted()
	_warn_garden_task_lag_us("_on_plant_removed", Time.get_ticks_usec() - removed_us,
		"garden=%d empty=%s" % [garden_id, str(became_empty)])

func _scan_special_layer(layer: TileMapLayer, seen_spawners: Dictionary) -> void:
	if not layer:
		return

	for raw_cell in layer.get_used_cells():
		var map_cell: Vector2i = raw_cell
		var definition: Dictionary = _definition_for_layer_cell(layer, map_cell)
		var kind: String = str(definition.get("kind", ""))
		if kind == "spawner":
			_log("detected spawner layer=%s cell=%s atlas=%s floor=%s wall=%s" % [
				layer.name,
				map_cell,
				layer.get_cell_atlas_coords(map_cell),
				_has_floor(map_cell),
				_has_wall(map_cell)
			])
			seen_spawners[map_cell] = true
			_register_spawner(map_cell, float(definition.get("cooldown", DEFAULT_SPAWN_COOLDOWN)))

func _migrate_special_tiles_from_wallz() -> bool:
	if not wallz or not buildings:
		return false

	var migrated: bool = false
	for raw_cell in wallz.get_used_cells():
		var cell: Vector2i = raw_cell
		var definition: Dictionary = _definition_for_layer_cell(wallz, cell)
		var kind: String = str(definition.get("kind", ""))
		if kind == "" or kind == "wall":
			continue

		var target_layer: TileMapLayer = plantz if kind == "plantsToTarget" else buildings
		if not target_layer:
			continue
		target_layer.set_cell(
			cell,
			wallz.get_cell_source_id(cell),
			wallz.get_cell_atlas_coords(cell),
			wallz.get_cell_alternative_tile(cell)
		)
		wallz.erase_cell(cell)
		migrated = true
		_log("migrated special tile kind=%s cell=%s atlas=%s from wallz to %s" % [
			kind,
			cell,
			target_layer.get_cell_atlas_coords(cell),
			target_layer.name
		])

	if migrated:
		buildings.update_internals()
		if plantz:
			plantz.update_internals()
		wallz.update_internals()
	return migrated

func _definition_for_cell(cell: Vector2i) -> Dictionary:
	return _definition_for_layer_cell(buildings, cell)

func _definition_for_layer_cell(layer: TileMapLayer, cell: Vector2i) -> Dictionary:
	if not layer:
		return {}
	var atlas: Vector2i = layer.get_cell_atlas_coords(cell)
	var atlas_key: String = _atlas_key(atlas)
	return _tile_defs_by_atlas.get(atlas_key, {}) as Dictionary

func _register_spawner(cell: Vector2i, cooldown: float) -> void:
	var is_new: bool = not _spawners.has(cell)
	_spawners[cell] = {
		"cooldown": max(0.05, cooldown)
	}
	if not _spawn_timers.has(cell):
		_spawn_timers[cell] = 0.0
	if is_new and _flow_ready and _plant_zone_built and _startup_ready:
		_initialize_spawner_route(cell)

func _release_spawner_route(spawner_cell: Vector2i) -> void:
	var route: Dictionary = _spawner_routes.get(spawner_cell, {}) as Dictionary
	var escape_group: int = int(route.get("escape_group", -1))
	if agent_manager and agent_manager.has_method("dissolve_group"):
		if escape_group > IDLE_GROUP:
			agent_manager.call("dissolve_group", escape_group)
		if _spawner_garden_routes.has(spawner_cell):
			var garden_routes: Dictionary = _spawner_garden_routes[spawner_cell] as Dictionary
			for raw_route in garden_routes.values():
				var garden_route: Dictionary = raw_route as Dictionary
				var plant_group: int = int(garden_route.get("plant_group", -1))
				if plant_group > IDLE_GROUP:
					agent_manager.call("dissolve_group", plant_group)
	_spawner_routes.erase(spawner_cell)
	_spawner_garden_routes.erase(spawner_cell)

func _drain_dirty_routes() -> void:
	if not _flow_ready:
		return
	if not agent_manager or not agent_manager.has_method("create_group"):
		return
	if not flow or not flow.has_method("assign_flow_to_group"):
		return

	var escape_cells: Array = _dirty_spawner_escapes.keys()
	_dirty_spawner_escapes.clear()

	for raw_cell in escape_cells:
		if _spawners.has(raw_cell):
			_rebuild_spawner_escape_ff(raw_cell)

func _initialize_spawner_route(spawner_cell: Vector2i) -> void:
	# One-shot: compute static escape cells. Plant entry routes use per-agent A*
	# and are created lazily when a spawner needs a target garden.
	if not _flow_ready or not _plant_zone_built:
		return
	if not agent_manager or not flow:
		return

	var route: Dictionary = _spawner_routes.get(spawner_cell, {}) as Dictionary

	# Exit wall tile (nearest atlas (13,0) on wallz by Manhattan distance).
	var exit_wall_cell: Vector2i = _nearest_exit_wall_for_spawner(spawner_cell)
	route["exit_wall_cell"] = exit_wall_cell

	# Floor tile adjacent to the exit wall that the FF can target.
	var escape_wall_target_cell: Vector2i = INVALID_CELL
	if exit_wall_cell != INVALID_CELL:
		escape_wall_target_cell = _nearest_walkable_adjacent(exit_wall_cell)
	if escape_wall_target_cell == INVALID_CELL:
		# Fallback to spawner cell if no walkable adjacency to an exit wall.
		escape_wall_target_cell = _resolve_walkable_goal(spawner_cell, "escape@%s" % spawner_cell)
	route["escape_wall_target_cell"] = escape_wall_target_cell

	# Escape FF: goal = floor tile adjacent to exit wall (static).
	if escape_wall_target_cell != INVALID_CELL:
		var escape_group: int = int(route.get("escape_group", -1))
		if escape_group <= IDLE_GROUP:
			escape_group = int(agent_manager.call("create_group"))
		if escape_group > IDLE_GROUP:
			var escape_world: Vector2 = _cell_center(escape_wall_target_cell)
			if not _is_finite_world(escape_world):
				push_warning("LOST-AGENT-GUARD: insane escape_world %s (cell %s) for spawner %s" % [
					escape_world, escape_wall_target_cell, spawner_cell
				])
				route["escape_ready"] = false
				_spawner_routes[spawner_cell] = route
				return
			flow.call("assign_flow_to_group", escape_group, escape_world)
			route["escape_group"] = escape_group
			route["escape_world"] = escape_world
			route["escape_ready"] = true
		else:
			push_error("BuildingManager: spawner %s could not allocate escape group" % spawner_cell)
			route["escape_ready"] = false
	else:
		route["escape_ready"] = false

	_spawner_routes[spawner_cell] = route
	_log("initialized spawner=%s exit_wall=%s escape_target=%s" % [
		spawner_cell, exit_wall_cell, escape_wall_target_cell
	])

func _rebuild_spawner_plant_ff(spawner_cell: Vector2i) -> void:
	# Plant-entry routing no longer owns flow fields. Route freshness is validated
	# through garden version/epoch and each agent gets a direct A* path to entry.
	if not _spawner_garden_routes.has(spawner_cell):
		return
	var garden_routes: Dictionary = _spawner_garden_routes[spawner_cell] as Dictionary
	for raw_garden_id in garden_routes.keys():
		var garden_id: int = int(raw_garden_id)
		var route: Dictionary = garden_routes[garden_id] as Dictionary
		var entry_cell: Vector2i = route.get("entry_cell", INVALID_CELL) as Vector2i
		if entry_cell == INVALID_CELL:
			continue
		route["entry_world"] = _cell_center(entry_cell)
		garden_routes[garden_id] = route
	_spawner_garden_routes[spawner_cell] = garden_routes

func _rebuild_spawner_escape_ff(spawner_cell: Vector2i) -> void:
	# Re-run escape FF after walls change. Goal is the cached escape_wall_target_cell.
	var route: Dictionary = _spawner_routes.get(spawner_cell, {}) as Dictionary
	var target_cell: Vector2i = route.get("escape_wall_target_cell", INVALID_CELL) as Vector2i
	if target_cell == INVALID_CELL:
		return
	var escape_group: int = int(route.get("escape_group", -1))
	if escape_group <= IDLE_GROUP:
		return
	var escape_world: Vector2 = _cell_center(target_cell)
	_request_group_flow_rebuild(escape_group, escape_world)
	route["escape_world"] = escape_world
	_spawner_routes[spawner_cell] = route

func _rebuild_all_spawner_routes() -> void:
	if not _flow_ready or not _plant_zone_built:
		return
	for raw_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_cell
		_initialize_spawner_route(spawner_cell)

# Build/refresh one escape flow field per exit-wall tile. Each is a per-group FF
# whose goal is the floor tile adjacent to that exit wall. Runs only on dirty
# events; at runtime a monster reads each group's route cost to pick the nearest
# reachable exit. Stale exits (walls removed) are released.
func _rebuild_exit_wall_escapes() -> void:
	if not _flow_ready:
		return
	if not agent_manager or not agent_manager.has_method("create_group"):
		return
	# Exit walls are only rebuilt on wall changes (which also re-cluster gardens and
	# rebuild routes), but clear here too so this invalidation point is explicit.
	_clear_garden_entry_resolve_cache("rebuild_exit_escapes")
	if not flow:
		return

	var current_exits: Dictionary = {}  # Vector2i -> true
	if wallz:
		for raw_cell in wallz.get_used_cells():
			var c: Vector2i = raw_cell
			if wallz.get_cell_atlas_coords(c) == EXIT_WALL_ATLAS:
				current_exits[c] = true

	# Release escapes whose exit wall no longer exists.
	for raw_exit_cell in _exit_wall_escapes.keys():
		var exit_cell: Vector2i = raw_exit_cell
		if not current_exits.has(exit_cell):
			_release_exit_wall_escape(exit_cell)

	# Create/refresh an escape FF for every current exit wall.
	for raw_exit_cell in current_exits.keys():
		var exit_cell: Vector2i = raw_exit_cell
		var target_cell: Vector2i = _nearest_walkable_adjacent(exit_cell)
		if target_cell == INVALID_CELL:
			# No walkable tile next to this exit wall: drop any stale escape.
			_release_exit_wall_escape(exit_cell)
			continue
		var escape: Dictionary = _exit_wall_escapes.get(exit_cell, {}) as Dictionary
		var escape_group: int = int(escape.get("escape_group", -1))
		if escape_group <= IDLE_GROUP:
			escape_group = int(agent_manager.call("create_group"))
		if escape_group <= IDLE_GROUP:
			push_error("BuildingManager: could not allocate escape group for exit wall %s" % exit_cell)
			continue
		var escape_world: Vector2 = _cell_center(target_cell)
		if not _is_finite_world(escape_world):
			push_warning("LOST-AGENT-GUARD: insane exit-wall escape_world %s (cell %s) for exit %s" % [
				escape_world, target_cell, exit_cell
			])
			_release_exit_wall_escape(exit_cell)
			continue
		# Synchronous assign so the FF (and its route-cost field) is queryable
		# immediately; goals are static and rebuilds are rare (dirty events only).
		if flow.has_method("assign_flow_to_group"):
			flow.call("assign_flow_to_group", escape_group, escape_world)
		else:
			_request_group_flow_rebuild(escape_group, escape_world)
		escape["escape_group"] = escape_group
		escape["escape_target_cell"] = target_cell
		escape["escape_world"] = escape_world
		escape["ready"] = true
		_exit_wall_escapes[exit_cell] = escape

func _release_exit_wall_escape(exit_cell: Vector2i) -> void:
	if not _exit_wall_escapes.has(exit_cell):
		return
	var escape: Dictionary = _exit_wall_escapes[exit_cell] as Dictionary
	var escape_group: int = int(escape.get("escape_group", -1))
	if escape_group > IDLE_GROUP and agent_manager and agent_manager.has_method("dissolve_group"):
		agent_manager.call("dissolve_group", escape_group)
	_exit_wall_escapes.erase(exit_cell)

# Pick the exit-wall escape with the lowest walkable route cost from world_pos.
# Returns {} if none is reachable (caller falls back to the per-spawner escape).
func _nearest_reachable_exit_escape(world_pos: Vector2) -> Dictionary:
	if not flow or not flow.has_method("group_route_cost_at_world"):
		return {}
	var best: Dictionary = {}
	var best_cost: float = INF
	for raw_exit_cell in _exit_wall_escapes.keys():
		var escape: Dictionary = _exit_wall_escapes[raw_exit_cell] as Dictionary
		if not bool(escape.get("ready", false)):
			continue
		var escape_group: int = int(escape.get("escape_group", -1))
		if escape_group <= IDLE_GROUP:
			continue
		var cost: float = float(flow.call("group_route_cost_at_world", escape_group, world_pos))
		if cost < best_cost:
			best_cost = cost
			best = escape
	return best

func _request_group_flow_rebuild(group_id: int, goal_world: Vector2) -> void:
	# TEMP DEBUG (lost-agent guard): never push a non-finite / absurd goal into the
	# flow system — that is what makes agents map out of bounds and go lost.
	if not _is_finite_world(goal_world):
		push_warning("LOST-AGENT-GUARD: refused flow goal %s for group %d" % [goal_world, group_id])
		return
	if flow and flow.has_method("request_flow_to_group"):
		flow.call("request_flow_to_group", group_id, goal_world)
	elif flow and flow.has_method("assign_flow_to_group"):
		flow.call("assign_flow_to_group", group_id, goal_world)

func _is_finite_world(p: Vector2) -> bool:
	if not (is_finite(p.x) and is_finite(p.y)):
		return false
	var limit: float = float(_SANE_CELL_LIMIT) * 64.0
	return abs(p.x) <= limit and abs(p.y) <= limit

func _no_plants_remaining() -> bool:
	if plant_manager and plant_manager.has_method("is_empty"):
		return bool(plant_manager.call("is_empty"))
	return true

func _resolve_walkable_goal(cell: Vector2i, purpose: String) -> Vector2i:
	if _is_walkable(cell):
		return cell
	var fallback: Vector2i = _find_walkable_cell_near(cell)
	if fallback == INVALID_CELL:
		push_error("BuildingManager: %s target cell %s is not walkable and no walkable cell found within range. floor=%s wall=%s" % [
			purpose, cell, _has_floor(cell), _has_wall(cell)
		])
		return INVALID_CELL
	push_error("BuildingManager: %s target cell %s is a wall/non-walkable; falling back to nearest free tile %s" % [
		purpose, cell, fallback
	])
	return fallback

func _process_spawners(delta: float) -> void:
	# Reset the per-pass count summary consumed by the parent lag warning. Cheap;
	# always done so the caller never reads a stale dictionary.
	_spawn_pass_stats = {
		"processed_spawners": 0,
		"spawned_count": 0,
		"assigned_count": 0,
		"skipped_count": 0,
		"active_monsters": -1,
		"ready_queue_remaining": 0,
		"elapsed_ms": 0.0,
	}

	# Day/night gating: monsters only spawn at night. When the last monster of
	# the night is gone, automatically flip back to day. _monster_count() scans a
	# scene group (get_nodes_in_group), so time it as a potential offender.
	if not GameState.is_night:
		return
	var t_mc: int = Time.get_ticks_usec()
	var mc: int = _monster_count()
	_warn_garden_task_lag_us("_process_spawners.monster_count", Time.get_ticks_usec() - t_mc)
	_spawn_pass_stats["active_monsters"] = mc
	if mc == 0 and _spawned_this_night:
		GameState.start_day()
		return

	# Plant-state query (plant_manager.is_empty); cheap normally but time it in case
	# the plant manager scans on this call.
	var t_np: int = Time.get_ticks_usec()
	var no_plants: bool = _no_plants_remaining()
	_warn_garden_task_lag_us("_process_spawners.no_plants_remaining", Time.get_ticks_usec() - t_np)
	if no_plants:
		if debug_logs and not _spawners.is_empty():
			_log("no plants remaining for %d spawner(s)" % _spawners.size())
		return

	# Two phases so multiple ready spawners don't all spawn+assign in one frame:
	#   1. advance every spawner's cooldown timer (cheap) and enqueue the ones that
	#      just became ready,
	#   2. drain only a budgeted number of ready spawners this frame; the rest stay
	#      queued for following frames (round-robin, so none are starved).
	_update_spawner_timers_and_enqueue_ready(delta)
	_drain_ready_spawner_queue_budgeted()

# Phase 1: tick every spawner's cooldown and append the newly-ready ones to the
# round-robin queue. This stays cheap (timer arithmetic only) and runs for all
# spawners every frame, so existing per-spawner cadence is unchanged — the expensive
# spawn+assign work is what gets deferred to the drain step.
func _update_spawner_timers_and_enqueue_ready(delta: float) -> void:
	for raw_cell in _spawners.keys():
		var cell: Vector2i = raw_cell
		# Cooldown/timer update. Trivial arithmetic, but time it so a slow pass can
		# be definitively ruled out here rather than guessed at.
		var t_cd: int = Time.get_ticks_usec()
		var timer: float = float(_spawn_timers.get(cell, 0.0)) - delta
		var on_cooldown: bool = timer > 0.0
		_warn_garden_task_lag_us("_process_spawners.cooldown_update", Time.get_ticks_usec() - t_cd)
		if on_cooldown:
			_spawn_timers[cell] = timer
			_spawn_pass_stats["skipped_count"] = int(_spawn_pass_stats["skipped_count"]) + 1
			continue
		# Ready: clamp the timer at 0 so it doesn't keep counting further negative
		# while it waits in the queue, then enqueue once.
		_spawn_timers[cell] = 0.0
		if not _ready_spawner_queue_set.has(cell):
			_ready_spawner_queue.append(cell)
			_ready_spawner_queue_set[cell] = true

# Phase 2: spawn from at most spawner_budget_per_frame ready spawners (and, if a
# time budget is set, stop early once we exceed it — but always do at least one so
# the queue drains). Remaining ready spawners are processed on following frames.
func _drain_ready_spawner_queue_budgeted() -> void:
	var start_us: int = Time.get_ticks_usec()
	var budget_us: int = int(spawner_budget_ms * 1000.0)
	var processed: int = 0

	while not _ready_spawner_queue.is_empty():
		if processed >= spawner_budget_per_frame:
			break
		# Time budget only applies after the first spawn this frame, so a single
		# expensive spawner can't starve the queue entirely.
		if processed > 0 and budget_us > 0:
			if Time.get_ticks_usec() - start_us >= budget_us:
				break

		var cell: Vector2i = _ready_spawner_queue.pop_front()
		_ready_spawner_queue_set.erase(cell)
		# A spawner may have been removed (rescan) while queued; skip stale entries
		# without counting them against the budget.
		if not _spawners.has(cell):
			continue

		var spawner_us: int = Time.get_ticks_usec()
		_spawn_pass_stats["processed_spawners"] = int(_spawn_pass_stats["processed_spawners"]) + 1
		processed += 1

		var spawned: bool = _spawn_monster_from(cell)
		if spawned:
			_spawned_this_night = true
			_spawn_pass_stats["spawned_count"] = int(_spawn_pass_stats["spawned_count"]) + 1
			var spawner: Dictionary = _spawners[cell] as Dictionary
			_spawn_timers[cell] = float(spawner.get("cooldown", DEFAULT_SPAWN_COOLDOWN))
		else:
			_spawn_timers[cell] = 0.25

		# Whole spawner iteration. Build the (small) context only when over threshold.
		var spawner_elapsed_us: int = Time.get_ticks_usec() - spawner_us
		if _over_garden_threshold_us(spawner_elapsed_us):
			_warn_garden_task_lag_us("_process_spawners.spawner_total", spawner_elapsed_us,
				"spawner_cell=%s spawned=%s" % [str(cell), str(spawned)])

	_spawn_pass_stats["ready_queue_remaining"] = _ready_spawner_queue.size()
	_spawn_pass_stats["elapsed_ms"] = float(Time.get_ticks_usec() - start_us) / 1000.0

func _spawn_monster_from(spawner_cell: Vector2i) -> bool:
	# Select target garden: iterates all gardens, checks targetable / edible plants,
	# and runs _nearest_garden_entry per garden. Prime suspect for select-garden lag.
	var t_sel: int = Time.get_ticks_usec()
	var garden_id: int = _select_garden_for_spawner(spawner_cell)
	var sel_us: int = Time.get_ticks_usec() - t_sel
	if _over_garden_threshold_us(sel_us):
		_warn_garden_task_lag_us("_process_spawners.select_garden", sel_us,
			"spawner_cell=%s gardens=%d garden=%d" % [str(spawner_cell), _gardens.size(), garden_id])
	if garden_id <= 0:
		_log_spawn_failure("spawner %s has no reachable garden" % spawner_cell)
		return false

	# Route/cache lookup (+ entry-cell resolution). Hits are O(1); misses recompute
	# the nearest garden entry. Hit/miss counters live in the called function.
	var t_route: int = Time.get_ticks_usec()
	var route: Dictionary = _get_or_create_spawner_garden_route(spawner_cell, garden_id)
	var route_us: int = Time.get_ticks_usec() - t_route
	if _over_garden_threshold_us(route_us):
		_warn_garden_task_lag_us("_process_spawners.route_lookup", route_us,
			"spawner_cell=%s garden=%d ready=%s" % [str(spawner_cell), garden_id, str(route.get("ready", false))])
	if not bool(route.get("ready", false)):
		_log_spawn_failure("spawner %s garden %d route not ready" % [spawner_cell, garden_id])
		return false
	var entry_cell: Vector2i = route.get("entry_cell", INVALID_CELL) as Vector2i
	if entry_cell == INVALID_CELL:
		_log_spawn_failure("spawner %s garden %d has no entry cell" % [spawner_cell, garden_id])
		return false

	if not _is_sane_cell(entry_cell):
		_log_spawn_failure("spawner %s garden %d insane entry_cell %s" % [spawner_cell, garden_id, entry_cell])
		return false

	# Occupied-cell scan: walks the main_chars/monsters/player scene groups every
	# spawn. Grows with active unit count.
	var t_occ: int = Time.get_ticks_usec()
	var occupied: Array[Vector2i] = _occupied_cells()
	var occ_us: int = Time.get_ticks_usec() - t_occ
	if _over_garden_threshold_us(occ_us):
		_warn_garden_task_lag_us("_process_spawners.occupied_cells", occ_us,
			"spawner_cell=%s occupied=%d" % [str(spawner_cell), occupied.size()])

	# Free-cell search: spirals out from the spawner doing per-cell walkable/wall
	# (TileMap) lookups until a free cell is found. Can spike when the spawner is
	# boxed in.
	var t_free: int = Time.get_ticks_usec()
	var spawn_cell: Vector2i = _find_free_cell_near(spawner_cell, occupied)
	var free_us: int = Time.get_ticks_usec() - t_free
	if _over_garden_threshold_us(free_us):
		_warn_garden_task_lag_us("_process_spawners.find_free_cell", free_us,
			"spawner_cell=%s spawn_cell=%s" % [str(spawner_cell), str(spawn_cell)])
	if spawn_cell == INVALID_CELL or not _is_sane_cell(spawn_cell):
		_log_spawn_failure("spawner %s could not find a sane walkable spawn cell (got %s)" % [spawner_cell, spawn_cell])
		return false

	# Instantiate + add_child + group registration of the agent scene.
	var t_inst: int = Time.get_ticks_usec()
	var agent: Node2D = AGENT_SCENE.instantiate() as Node2D
	var parent: Node = parent_for_agents if parent_for_agents else get_tree().current_scene
	parent.add_child(agent)
	agent.global_position = _cell_center(spawn_cell)
	agent.z_index = int(agent.global_position.y)
	agent.add_to_group("monsters")
	var inst_us: int = Time.get_ticks_usec() - t_inst
	if _over_garden_threshold_us(inst_us):
		_warn_garden_task_lag_us("_process_spawners.instantiate_agent", inst_us,
			"spawner_cell=%s spawn_cell=%s" % [str(spawner_cell), str(spawn_cell)])

	if agent_manager and agent_manager.has_method("spawn_agent"):
		# Register the agent with the nav/agent manager (flowfield/pathfinder side).
		var t_reg: int = Time.get_ticks_usec()
		var nav_id: int = int(agent_manager.call("spawn_agent", agent, IDLE_GROUP))
		agent.set("nav_id", nav_id)
		if agent_manager.has_method("set_agent_never_rest"):
			agent_manager.call("set_agent_never_rest", nav_id, true)
		var reg_us: int = Time.get_ticks_usec() - t_reg
		if _over_garden_threshold_us(reg_us):
			_warn_garden_task_lag_us("_process_spawners.register_agent", reg_us,
				"spawner_cell=%s nav_id=%d" % [str(spawner_cell), nav_id])

		# Assign the garden-entry route: runs A* on the walkable map and pushes the
		# resulting path into the agent/flow manager. Usually the heaviest leg.
		var t_assign: int = Time.get_ticks_usec()
		var assigned: bool = _assign_agent_to_garden_entry_path(agent, spawner_cell, garden_id, entry_cell)
		var assign_us: int = Time.get_ticks_usec() - t_assign
		if _over_garden_threshold_us(assign_us):
			_warn_garden_task_lag_us("_process_spawners.assign_route", assign_us,
				"spawner_cell=%s garden=%d entry=%s assigned=%s" % [
					str(spawner_cell), garden_id, str(entry_cell), str(assigned)])
		if not assigned:
			if agent_manager.has_method("unregister_agent"):
				agent_manager.call("unregister_agent", nav_id)
			agent.remove_from_group("monsters")
			agent.queue_free()
			_log_spawn_failure("spawner %s garden %d entry path not ready" % [spawner_cell, garden_id])
			return false
		_spawn_pass_stats["assigned_count"] = int(_spawn_pass_stats.get("assigned_count", 0)) + 1
		_log("spawned monster nav_id=%d spawn_cell=%s entry=%s spawner=%s garden=%d" % [
			nav_id, spawn_cell, entry_cell, spawner_cell, garden_id
		])

	return true

# Phase 1 -> 2: agent reached its assigned garden entry via A*. Compute A* to a
# plant target inside that garden and attach that path.
func _process_astar_in_arrivals() -> void:
	var finished: Array[int] = []
	var entry_ids: Array = _entry_path_agents.keys()
	for raw_nav_id in entry_ids:
		var nav_id: int = int(raw_nav_id)
		if not _entry_path_agents.has(nav_id):
			continue
		var data: Dictionary = _entry_path_agents[nav_id] as Dictionary
		var raw_agent: Variant = data.get("node", null)
		if not is_instance_valid(raw_agent):
			finished.append(nav_id)
			continue
		var agent: Node2D = raw_agent as Node2D
		if agent == null:
			finished.append(nav_id)
			continue
		if _eating_agents.has(nav_id) or _escaping_agents.has(nav_id):
			finished.append(nav_id)
			continue
		if _astar_in_agents.has(nav_id):
			continue
		if not (agent_manager and agent_manager.has_method("agent_path_arrived")):
			continue
		if not bool(agent_manager.call("agent_path_arrived", nav_id)):
			continue
		var spawner_cell: Vector2i = data.get("spawner_cell", INVALID_CELL) as Vector2i
		var garden_id: int = int(data.get("garden_id", 0))
		if not _garden_has_edible_plants(garden_id):
			_entry_path_agents.erase(nav_id)
			_retarget_agent_or_escape(agent, spawner_cell)
			continue
		_entry_path_agents.erase(nav_id)
		_start_astar_in(agent, spawner_cell)
	for nav_id in finished:
		_entry_path_agents.erase(nav_id)
	# _garden_has_edible_plants may have queued stale-empty gardens; this loop
	# iterates monsters, not _gardens, so draining here is safe.
	_drain_pending_empty_gardens()

func _start_astar_in(agent: Node2D, spawner_cell: Vector2i) -> void:
	var nav_id: int = int(agent.get("nav_id"))
	var agent_cell: Vector2i = floorz.local_to_map(floorz.to_local(agent.global_position))
	var garden_id: int = int(agent.get_meta("garden_id")) if agent.has_meta("garden_id") else 0
	if not _garden_has_edible_plants(garden_id):
		_retarget_agent_or_escape(agent, spawner_cell)
		return
	var target_plant_cell: Vector2i = _resolve_plant_target_for_agent_in_garden(agent_cell, garden_id)
	if target_plant_cell == INVALID_CELL:
		_retarget_agent_or_escape(agent, spawner_cell)
		return
	var path_cells: PackedVector2Array = _find_path_in_zone(agent_cell, target_plant_cell, garden_id)
	if path_cells.is_empty():
		_retarget_agent_or_escape(agent, spawner_cell)
		return
	if agent_manager and agent_manager.has_method("detach_agent_flow"):
		agent_manager.call("detach_agent_flow", nav_id)
	var path_world: PackedVector2Array = _path_cells_to_world(path_cells)
	if agent_manager and agent_manager.has_method("assign_agent_path"):
		agent_manager.call("assign_agent_path", nav_id, path_world)
	_entry_path_agents.erase(nav_id)
	_set_astar_in_agent(nav_id, {
		"node": agent,
		"plant_cell": target_plant_cell,
		"spawner_cell": spawner_cell,
		"garden_id": garden_id,
		"path_world": path_world
	})
	if agent.has_method("start_astar_in"):
		agent.call("start_astar_in")

# Phase 2 -> 3: astar_in path complete. Verify plant still exists; consume it.
func _process_plant_arrivals() -> void:
	var finished: Array[int] = []
	var astar_ids: Array = _astar_in_agents.keys()
	for raw_nav_id in astar_ids:
		var nav_id: int = int(raw_nav_id)
		if not _astar_in_agents.has(nav_id):
			continue
		var data: Dictionary = _astar_in_agents[nav_id] as Dictionary
		var raw_agent: Variant = data.get("node", null)
		if not is_instance_valid(raw_agent):
			finished.append(nav_id)
			continue
		var agent: Node2D = raw_agent as Node2D
		if agent == null:
			finished.append(nav_id)
			continue
		if not (agent_manager and agent_manager.has_method("agent_path_arrived")):
			continue
		if not bool(agent_manager.call("agent_path_arrived", nav_id)):
			continue
		var plant_cell: Vector2i = data.get("plant_cell", INVALID_CELL) as Vector2i
		var spawner_cell: Vector2i = data.get("spawner_cell", INVALID_CELL) as Vector2i
		if agent.has_method("stop_astar_in"):
			agent.call("stop_astar_in")
		if plant_cell == INVALID_CELL:
			finished.append(nav_id)
			continue
		if plant_manager and plant_manager.has_method("has_plant") and not bool(plant_manager.call("has_plant", plant_cell)):
			_erase_astar_in_agent(nav_id)
			_retarget_agent_or_escape(agent, spawner_cell)
			continue
		_erase_astar_in_agent(nav_id)
		_consume_plant(agent, spawner_cell, plant_cell)
	for nav_id in finished:
		_erase_astar_in_agent(nav_id)

func _retarget_agents_for_garden_topology_change(changed_cell: Vector2i) -> void:
	var astar_ids: Array = _astar_in_agents.keys()
	for raw_nav_id in astar_ids:
		var nav_id: int = int(raw_nav_id)
		if not _astar_in_agents.has(nav_id):
			continue
		var data: Dictionary = _astar_in_agents[nav_id] as Dictionary
		var plant_cell: Vector2i = data.get("plant_cell", INVALID_CELL) as Vector2i
		var garden_id: int = int(data.get("garden_id", 0))
		if plant_cell != changed_cell and not _garden_target_is_stale(garden_id):
			continue
		_clear_stale_garden_path(nav_id, data)

	var entry_ids: Array = _entry_path_agents.keys()
	for raw_nav_id in entry_ids:
		var nav_id: int = int(raw_nav_id)
		if not _entry_path_agents.has(nav_id):
			continue
		var data: Dictionary = _entry_path_agents[nav_id] as Dictionary
		var garden_id: int = int(data.get("garden_id", 0))
		if not _garden_target_is_stale(garden_id):
			continue
		_clear_stale_garden_path(nav_id, data)
	_drain_pending_empty_gardens()

func _garden_target_is_stale(garden_id: int) -> bool:
	if garden_id <= 0:
		return true
	if not _gardens.has(garden_id):
		return true
	return not _garden_has_edible_plants(garden_id)

func _clear_stale_garden_path(nav_id: int, data: Dictionary) -> void:
	_entry_path_agents.erase(nav_id)
	_erase_astar_in_agent(nav_id)
	if agent_manager and agent_manager.has_method("detach_agent_path"):
		agent_manager.call("detach_agent_path", nav_id)
	var raw_agent: Variant = data.get("node", null)
	if not is_instance_valid(raw_agent):
		return
	var agent: Node2D = raw_agent as Node2D
	if agent == null:
		return
	if agent.has_method("stop_astar_in"):
		agent.call("stop_astar_in")
	var spawner_cell: Vector2i = data.get("spawner_cell", INVALID_CELL) as Vector2i
	if spawner_cell == INVALID_CELL and agent.has_meta("spawner_cell"):
		spawner_cell = agent.get_meta("spawner_cell") as Vector2i
	_retarget_agent_or_escape(agent, spawner_cell)

# --- _astar_in_agents mutation funnel + target-plant reverse index --------------
# All inserts into / erasures from _astar_in_agents go through these two helpers so
# _astar_in_agents_by_target_plant and _astar_in_target_by_nav_id stay in lock-step.
func _set_astar_in_agent(nav_id: int, data: Dictionary) -> void:
	_astar_in_agents[nav_id] = data
	var target_cell: Vector2i = data.get("plant_cell", INVALID_CELL) as Vector2i
	_register_astar_in_target(nav_id, target_cell)

func _erase_astar_in_agent(nav_id: int) -> void:
	_astar_in_agents.erase(nav_id)
	_unregister_astar_in_target(nav_id)

func _register_astar_in_target(nav_id: int, target_cell: Vector2i) -> void:
	_unregister_astar_in_target(nav_id)
	if target_cell == INVALID_CELL:
		return
	_astar_in_target_by_nav_id[nav_id] = target_cell
	if not _astar_in_agents_by_target_plant.has(target_cell):
		_astar_in_agents_by_target_plant[target_cell] = {}
	var bucket: Dictionary = _astar_in_agents_by_target_plant[target_cell] as Dictionary
	bucket[nav_id] = true

func _unregister_astar_in_target(nav_id: int) -> void:
	if not _astar_in_target_by_nav_id.has(nav_id):
		return
	var target_cell: Vector2i = _astar_in_target_by_nav_id[nav_id] as Vector2i
	_astar_in_target_by_nav_id.erase(nav_id)
	if not _astar_in_agents_by_target_plant.has(target_cell):
		return
	var bucket: Dictionary = _astar_in_agents_by_target_plant[target_cell] as Dictionary
	bucket.erase(nav_id)
	if bucket.is_empty():
		_astar_in_agents_by_target_plant.erase(target_cell)

# NARROW retarget for content-only plant removal. Only handles agents whose A*-in
# target was the exact removed plant; it does NOT broad-retarget the garden, does
# NOT rebuild routes, and does NOT recompute entry points. _entry_path_agents is
# deliberately left alone (the garden is still alive with other plants, or it
# became empty — and the empty case is handled separately by
# _handle_garden_became_empty). The eater that just consumed the plant is already
# in _eating_agents (not _astar_in_agents), so it is never disturbed here.
func _retarget_agents_targeting_removed_plant_only(cell: Vector2i, garden_id: int) -> void:
	_last_plant_retarget_astar_in = _astar_in_agents.size()
	_last_plant_retarget_bucket = 0
	_last_plant_retarget_affected = 0
	_last_plant_retarget_queued = 0
	_last_plant_retarget_stale = 0
	_last_plant_retarget_already_queued = 0
	# Side-effect call: _garden_has_edible_plants flags a now-empty garden into the
	# pending-empty set, which _drain_pending_empty_gardens() (at the end of this func)
	# acts on. The boolean result is no longer needed for branching — every affected
	# agent is deferred to the budgeted queue regardless — but the call must stay.
	if garden_id > 0:
		_garden_has_edible_plants(garden_id)
	# Reverse index lookup: only the agents heading for THIS exact plant, not a scan
	# over every A*-in agent. Usually 0-2 entries. Snapshot the bucket keys first
	# because _retarget_agent_or_escape / queueing mutate the index underneath us.
	if _astar_in_agents_by_target_plant.has(cell):
		var bucket: Dictionary = _astar_in_agents_by_target_plant[cell] as Dictionary
		var nav_ids: Array = bucket.keys()
		_last_plant_retarget_bucket = nav_ids.size()
		for raw_nav_id in nav_ids:
			var nav_id: int = int(raw_nav_id)
			# --- Strict validation. A bucket entry is only "affected" if the live
			# record agrees on every axis. Any disagreement is stale: unregister it so
			# the same dirty entry can never be counted twice across removals. ---
			if not _astar_in_agents.has(nav_id):
				# No longer in A*-in (already retargeted/ate/escaped/freed elsewhere).
				_unregister_astar_in_target(nav_id)
				_last_plant_retarget_stale += 1
				continue
			if (_astar_in_target_by_nav_id.get(nav_id, INVALID_CELL) as Vector2i) != cell:
				# Reverse map no longer points this nav_id at `cell` — the bucket entry
				# is a leftover. Drop it; the nav_id (if still A*-in) is correctly
				# bucketed under its real target by _astar_in_target_by_nav_id.
				bucket.erase(nav_id)
				if bucket.is_empty():
					_astar_in_agents_by_target_plant.erase(cell)
				_last_plant_retarget_stale += 1
				continue
			var data: Dictionary = _astar_in_agents[nav_id] as Dictionary
			var plant_cell: Vector2i = data.get("plant_cell", INVALID_CELL) as Vector2i
			if plant_cell != cell:
				# Live record disagrees with the index: trust the record, re-sync the
				# index to it, and treat this bucket entry as stale.
				_register_astar_in_target(nav_id, plant_cell)
				_last_plant_retarget_stale += 1
				continue
			var raw_agent: Variant = data.get("node", null)
			if not is_instance_valid(raw_agent):
				# Agent freed without going through the funnel: scrub and skip.
				_erase_astar_in_agent(nav_id)
				_last_plant_retarget_stale += 1
				continue
			var agent: Node2D = raw_agent as Node2D
			if agent == null:
				_erase_astar_in_agent(nav_id)
				_last_plant_retarget_stale += 1
				continue
			# Validated: this agent is genuinely A*-in toward the removed plant.
			_last_plant_retarget_affected += 1
			var spawner_cell: Vector2i = data.get("spawner_cell", INVALID_CELL) as Vector2i
			# Detach the stale A*-in path and forget the phase before reassigning.
			if agent_manager and agent_manager.has_method("detach_agent_path"):
				agent_manager.call("detach_agent_path", nav_id)
			_erase_astar_in_agent(nav_id)
			if agent.has_method("stop_astar_in"):
				agent.call("stop_astar_in")
			if spawner_cell == INVALID_CELL and agent.has_meta("spawner_cell"):
				spawner_cell = agent.get_meta("spawner_cell") as Vector2i
			# Always defer through the budgeted queue. Per-agent retarget is "cheap" only
			# in isolation: _retarget_agent_or_escape runs a radius scan + per-candidate
			# path validation (~ms each). When a single plant removal frees a whole bucket
			# (e.g. 5 agents all heading for the same plant), retargeting them all
			# synchronously here spikes the frame to 15-20ms. The budgeted queue spreads
			# that same work across frames at garden_retarget_budget_ms/frame. Whether the
			# garden still has edible plants only affects what the queued retarget resolves
			# to (a fresh plant vs. an escape) — not whether it must run this frame.
			if _queue_agent_for_garden_retarget(nav_id, agent, "retarget", spawner_cell, garden_id):
				_last_plant_retarget_queued += 1
			else:
				_last_plant_retarget_already_queued += 1
	# Optional consistency check: replay the old full scan and warn on any mismatch.
	# OFF by default — it reintroduces the very O(all A*-in) cost the index removes.
	if _debug_check_retarget_index:
		_assert_retarget_index_matches_scan(cell)
	# A stale-empty garden may have been flagged by _garden_has_edible_plants above;
	# this function does not iterate _gardens, so draining now is safe.
	_drain_pending_empty_gardens()

# Debug-only: confirm the reverse index would have found exactly the agents the old
# full scan would have. Runs only when _debug_check_retarget_index is set. NOTE: this
# is called AFTER the affected agents have already been erased, so the live scan
# should find none of them; we instead verify no A*-in agent still claims `cell`.
func _assert_retarget_index_matches_scan(cell: Vector2i) -> void:
	var leftover: int = 0
	for raw_nav_id in _astar_in_agents.keys():
		var nav_id: int = int(raw_nav_id)
		var data: Dictionary = _astar_in_agents[nav_id] as Dictionary
		if (data.get("plant_cell", INVALID_CELL) as Vector2i) == cell:
			leftover += 1
	if leftover > 0:
		push_warning("debug_garden_lag:retarget_index_mismatch plant=%s leftover_astar_in_targeting_cell=%d (index missed them)" % [str(cell), leftover])

func _consume_plant(eater: Node2D, _spawner_cell: Vector2i, plant_cell: Vector2i) -> void:
	var consume_us: int = Time.get_ticks_usec()
	_start_agent_eating(eater, _eating_time, plant_cell)
	# plant_manager.remove_plant() fires _on_plant_removed synchronously (garden
	# content update + narrow retarget / empty handling), so it is the prime suspect
	# for an eat-triggered spike. Time it on its own.
	if plant_manager and plant_manager.has_method("remove_plant"):
		var remove_us: int = Time.get_ticks_usec()
		plant_manager.call("remove_plant", plant_cell, true)
		_warn_garden_task_lag_us("_consume_plant.remove_plant", Time.get_ticks_usec() - remove_us,
			"plant=%s" % str(plant_cell))
	elif plantz:
		plantz.erase_cell(plant_cell)
		_flush_plant_layer_visuals()
	if plantz and plantz.get_cell_source_id(plant_cell) >= 0:
		plantz.erase_cell(plant_cell)
		_flush_plant_layer_visuals()
		call_deferred("_flush_plant_layer_visuals")
	_warn_garden_task_lag_us("_consume_plant", Time.get_ticks_usec() - consume_us,
		"plant=%s" % str(plant_cell))

func _flush_plant_layer_visuals() -> void:
	if not plantz:
		return
	if _no_plants_remaining():
		plantz.clear()
	plantz.update_internals()
	plantz.queue_redraw()

func _process_eating_agents(delta: float) -> void:
	var finished: Array[int] = []
	var eating_ids: Array = _eating_agents.keys()
	for raw_nav_id in eating_ids:
		var nav_id: int = int(raw_nav_id)
		if not _eating_agents.has(nav_id):
			continue
		var data: Dictionary = _eating_agents[nav_id] as Dictionary
		var timer: float = float(data.get("timer", 0.0)) - delta
		data["timer"] = timer
		_eating_agents[nav_id] = data
		if timer <= 0.0:
			finished.append(nav_id)

	for nav_id in finished:
		var data: Dictionary = _eating_agents.get(nav_id, {}) as Dictionary
		_erase_eating_agent(nav_id)
		var raw_agent: Variant = data.get("node", null)
		if is_instance_valid(raw_agent):
			var agent: Node2D = raw_agent as Node2D
			if agent == null:
				continue
			if agent.has_method("stop_eating"):
				agent.call("stop_eating")
			# Direct wallexit-FF escape is the ONLY post-eating escape path. Every real
			# exit wall already has a flow field covering the whole walkable map (floor
			# minus walls; plant/garden cells are normal walkable cells), so a finished
			# eater attaches straight to the nearest reachable escape FF — no garden-exit
			# selection, no per-agent A* out of the garden.
			if _assign_agent_to_escape(agent):
				eat_exit_direct_ff_success += 1
			else:
				eat_exit_direct_ff_failed += 1
				# Should be rare: a walkable plant cell with no covering exit-wall FF
				# means FF coverage/walkability is wrong and must be fixed there, not
				# papered over with an A*-out fallback. Park the agent safely (queue
				# helper detaches stale nav and sets waiting_new_status) and warn.
				var fb_cell: Vector2i = floorz.local_to_map(floorz.to_local(agent.global_position)) if floorz else INVALID_CELL
				push_warning("direct_wallexit_ff_escape_failed nav_id=%d cell=%s" % [nav_id, fb_cell])
				var fb_spawner: Vector2i = agent.get_meta("spawner_cell") as Vector2i if agent.has_meta("spawner_cell") else INVALID_CELL
				var fb_garden: int = int(agent.get_meta("garden_id")) if agent.has_meta("garden_id") else 0
				_queue_agent_for_garden_retarget(nav_id, agent, "escape", fb_spawner, fb_garden)

func _erase_eating_agent(nav_id: int) -> void:
	_eating_agents.erase(nav_id)

func _start_agent_eating(agent: Node2D, seconds: float, plant_cell: Vector2i = INVALID_CELL) -> void:
	var nav_id: int = int(agent.get("nav_id"))
	# Carry the garden/spawner/plant context so an empty-garden event can find this
	# eater and queue it for escape without a full rebuild (see _agent_referenced_
	# garden_id / _handle_garden_became_empty).
	var garden_id: int = int(agent.get_meta("garden_id")) if agent.has_meta("garden_id") else 0
	var spawner_cell: Vector2i = agent.get_meta("spawner_cell") as Vector2i if agent.has_meta("spawner_cell") else INVALID_CELL
	_eating_agents[nav_id] = {
		"node": agent,
		"timer": seconds,
		"garden_id": garden_id,
		"spawner_cell": spawner_cell,
		"plant_cell": plant_cell
	}
	if agent_manager and agent_manager.has_method("detach_agent_flow"):
		agent_manager.call("detach_agent_flow", nav_id)
	if agent_manager and agent_manager.has_method("detach_agent_path"):
		agent_manager.call("detach_agent_path", nav_id)
	_entry_path_agents.erase(nav_id)
	_erase_astar_in_agent(nav_id)
	if agent.has_method("start_eating"):
		agent.call("start_eating", seconds)

func _start_escape_for_all_monsters() -> void:
	for node in get_tree().get_nodes_in_group("monsters"):
		if node is Node2D:
			var agent: Node2D = node
			var nav_id: int = int(agent.get("nav_id"))
			if _escaping_agents.has(nav_id) or _eating_agents.has(nav_id):
				continue
			_assign_agent_to_escape(agent)

# Returns true only when an escape group/path was actually assigned (i.e.
# _attach_agent_to_escape ran). Every early return is a failure (false) so the
# budgeted queue can keep the agent in "waiting_new_status" and requeue it instead
# of stranding it with no nav state.
func _assign_agent_to_escape(agent: Node2D) -> bool:
	if not agent_manager or not agent_manager.has_method("assign_agent"):
		return false
	# Prefer the nearest reachable per-exit-wall escape (chosen by walkable route
	# cost from the monster), so monsters leave through the closest wall exit.
	var exit_escape: Dictionary = _nearest_reachable_exit_escape(agent.global_position)
	if not exit_escape.is_empty():
		var exit_group: int = int(exit_escape.get("escape_group", -1))
		var exit_target: Vector2i = exit_escape.get("escape_target_cell", INVALID_CELL) as Vector2i
		if exit_group > IDLE_GROUP and exit_target != INVALID_CELL:
			return _attach_agent_to_escape(agent, exit_group, exit_target)

	# Fallback: the per-spawner escape (single shared exit for that spawner).
	var spawner_cell: Vector2i = INVALID_CELL
	if agent.has_meta("spawner_cell"):
		var pre_linked: Vector2i = agent.get_meta("spawner_cell") as Vector2i
		if _spawner_routes.has(pre_linked):
			spawner_cell = pre_linked
	if spawner_cell == INVALID_CELL:
		var from_cell: Vector2i = floorz.local_to_map(floorz.to_local(agent.global_position))
		spawner_cell = _nearest_spawner_cell(from_cell)
	if spawner_cell == INVALID_CELL or not _spawner_routes.has(spawner_cell):
		return false
	var route: Dictionary = _spawner_routes[spawner_cell] as Dictionary
	if not bool(route.get("escape_ready", false)):
		return false
	var escape_group: int = int(route.get("escape_group", -1))
	if escape_group <= IDLE_GROUP:
		return false
	var escape_target_cell: Vector2i = route.get("escape_wall_target_cell", spawner_cell) as Vector2i
	return _attach_agent_to_escape(agent, escape_group, escape_target_cell, spawner_cell)

# Returns true once the agent has been switched to the escape flow group. Only
# fails (false) if agent_manager is missing assign_agent — i.e. nav is unusable.
func _attach_agent_to_escape(agent: Node2D, escape_group: int, escape_target_cell: Vector2i, spawner_cell: Vector2i = INVALID_CELL) -> bool:
	if not agent_manager or not agent_manager.has_method("assign_agent"):
		return false
	var nav_id: int = int(agent.get("nav_id"))
	# Ensure path-follow is cleared before switching to FF group.
	if agent_manager.has_method("detach_agent_path"):
		agent_manager.call("detach_agent_path", nav_id)
	agent_manager.call("assign_agent", agent, escape_group)
	_entry_path_agents.erase(nav_id)
	_erase_astar_in_agent(nav_id)
	_erase_eating_agent(nav_id)
	if agent_manager.has_method("set_agent_never_rest"):
		agent_manager.call("set_agent_never_rest", nav_id, true)
	if spawner_cell != INVALID_CELL:
		agent.set_meta("spawner_cell", spawner_cell)
	_escaping_agents[nav_id] = {
		"node": agent,
		"target_cell": escape_target_cell,
		"spawner_cell": spawner_cell
	}
	if agent.has_method("stop_eating"):
		agent.call("stop_eating")
	if agent.has_method("start_escape"):
		agent.call("start_escape")
	return true

func _process_escape_arrivals() -> void:
	var arrived: Array[int] = []
	var escaping_ids: Array = _escaping_agents.keys()
	for raw_nav_id in escaping_ids:
		var nav_id: int = int(raw_nav_id)
		if not _escaping_agents.has(nav_id):
			continue
		var data: Dictionary = _escaping_agents[nav_id] as Dictionary
		var raw_agent: Variant = data.get("node", null)
		if not is_instance_valid(raw_agent):
			arrived.append(nav_id)
			continue
		var agent: Node2D = raw_agent as Node2D
		if agent == null:
			arrived.append(nav_id)
			continue
		var target_cell: Vector2i = data.get("target_cell", INVALID_CELL) as Vector2i
		if target_cell != INVALID_CELL and _agent_within_tiles(agent, target_cell, 1):
			_remove_escaped_monster(agent)
			arrived.append(nav_id)

	for nav_id in arrived:
		_escaping_agents.erase(nav_id)
		_erase_eating_agent(nav_id)

func _remove_escaped_monster(agent: Node2D) -> void:
	var nav_id: int = int(agent.get("nav_id"))
	if agent_manager and agent_manager.has_method("unregister_agent"):
		agent_manager.call("unregister_agent", nav_id)
	_entry_path_agents.erase(nav_id)
	if agent.has_method("stop_escape"):
		agent.call("stop_escape")
	agent.remove_from_group("monsters")
	agent.queue_free()

func _nearest_spawner_cell(from_cell: Vector2i) -> Vector2i:
	var best_cell: Vector2i = INVALID_CELL
	var best_dist_sq: int = 2147483647
	for raw_spawner_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_spawner_cell
		var d: Vector2i = spawner_cell - from_cell
		var dist_sq: int = d.x * d.x + d.y * d.y
		if dist_sq < best_dist_sq:
			best_dist_sq = dist_sq
			best_cell = spawner_cell
	return best_cell

func _agent_reached_cell(agent: Node2D, cell: Vector2i) -> bool:
	var agent_cell: Vector2i = floorz.local_to_map(floorz.to_local(agent.global_position))
	if agent_cell == cell:
		return true
	var tile_size: Vector2 = Vector2(32, 32)
	if floorz and floorz.tile_set:
		var raw_tile_size: Vector2i = floorz.tile_set.get_tile_size()
		tile_size = Vector2(float(raw_tile_size.x), float(raw_tile_size.y))
	return agent.global_position.distance_to(_cell_center(cell)) <= max(tile_size.x, tile_size.y) * 0.5

func _agent_within_tiles(agent: Node2D, cell: Vector2i, tiles: int) -> bool:
	if cell == INVALID_CELL:
		return false
	var agent_cell: Vector2i = floorz.local_to_map(floorz.to_local(agent.global_position))
	var d: Vector2i = agent_cell - cell
	return abs(d.x) <= tiles and abs(d.y) <= tiles

func _occupied_cells() -> Array[Vector2i]:
	var occupied: Array[Vector2i] = []
	for group_name in ["main_chars", "monsters", "player"]:
		for node in get_tree().get_nodes_in_group(group_name):
			if node is Node2D:
				var unit: Node2D = node
				occupied.append(floorz.local_to_map(floorz.to_local(unit.global_position)))
	return occupied

func _find_free_cell_near(start_cell: Vector2i, occupied: Array[Vector2i], max_radius: int = 8) -> Vector2i:
	if start_cell not in occupied and _is_walkable(start_cell):
		return start_cell
	for r in range(1, max_radius + 1):
		for dx in range(-r, r + 1):
			for dy in range(-r, r + 1):
				var cell: Vector2i = start_cell + Vector2i(dx, dy)
				if cell not in occupied and _is_walkable(cell):
					return cell
	return INVALID_CELL

func _find_walkable_cell_near(start_cell: Vector2i, max_radius: int = 8) -> Vector2i:
	if _is_walkable(start_cell):
		return start_cell
	for r in range(1, max_radius + 1):
		for dx in range(-r, r + 1):
			for dy in range(-r, r + 1):
				var cell: Vector2i = start_cell + Vector2i(dx, dy)
				if _is_walkable(cell):
					return cell
	return INVALID_CELL

func _is_walkable(cell: Vector2i) -> bool:
	return _has_floor(cell) and not _has_wall(cell)

func _rebuild_walkable_map_cache() -> void:
	_walkable_map_tiles.clear()
	if floorz == null:
		return
	for raw_cell in floorz.get_used_cells():
		var cell: Vector2i = raw_cell
		if _is_walkable(cell):
			_walkable_map_tiles[cell] = true

func _has_floor(cell: Vector2i) -> bool:
	return floorz != null and floorz.get_cell_tile_data(cell) != null

func _has_wall(cell: Vector2i) -> bool:
	return wallz != null and wallz.get_cell_tile_data(cell) != null

func _cell_center(cell: Vector2i) -> Vector2:
	return floorz.to_global(floorz.map_to_local(cell))

func _atlas_key(atlas: Vector2i) -> String:
	return "%d,%d" % [atlas.x, atlas.y]

func _tile_layer_signature(layer: TileMapLayer) -> int:
	if not layer:
		return 0
	var signature: int = 17
	for raw_cell in layer.get_used_cells():
		var cell: Vector2i = raw_cell
		var atlas: Vector2i = layer.get_cell_atlas_coords(cell)
		signature += int(cell.x * 73856093 + cell.y * 19349663)
		signature += int(atlas.x * 83492791 + atlas.y * 2654435761)
	return signature

# ---------------------------------------------------------------------------
# Plant zone.
# ---------------------------------------------------------------------------
func _build_plant_zone() -> void:
	if _plant_zone_built:
		return
	_build_gardens_from_plants()
	_validate_dirty_gardens()

func _rebuild_plant_zone_from_layer() -> void:
	# Full topology rebuild (plant added, walls changed, etc.). Each phase is timed
	# separately so a rebuild spike points at clustering vs geometry vs route cache.
	var rebuild_us: int = Time.get_ticks_usec()
	var t: int = Time.get_ticks_usec()
	_build_gardens_from_plants()
	_warn_garden_task_lag_us("_build_gardens_from_plants", Time.get_ticks_usec() - t,
		"gardens=%d" % _gardens.size())
	t = Time.get_ticks_usec()
	_validate_dirty_gardens()
	_warn_garden_task_lag_us("_validate_dirty_gardens", Time.get_ticks_usec() - t,
		"gardens=%d" % _gardens.size())
	t = Time.get_ticks_usec()
	_rebuild_spawner_garden_route_cache()
	_warn_garden_task_lag_us("_rebuild_spawner_garden_route_cache", Time.get_ticks_usec() - t,
		"spawners=%d" % _spawner_garden_routes.size())
	# Garden ids/topology just changed: cheaply detect agents now pointing at a
	# deleted/empty garden, park them in "waiting_new_status", and queue them for
	# budgeted retargeting over the next frames. No pathfinding happens here.
	t = Time.get_ticks_usec()
	_queue_agents_after_garden_rebuild()
	_warn_garden_task_lag_us("_queue_agents_after_garden_rebuild", Time.get_ticks_usec() - t,
		"retarget_queue=%d" % _garden_retarget_queue.size())
	_warn_garden_task_lag_us("_rebuild_plant_zone_from_layer", Time.get_ticks_usec() - rebuild_us,
		"gardens=%d" % _gardens.size())

func _build_gardens_from_plants() -> void:
	if _gardens_iter_depth > 0:
		push_warning("GARDEN-CRASH-GUARD: full rebuild requested mid-iteration (depth=%d)!" % _gardens_iter_depth)
	_gardens.clear()
	_garden_by_plant_cell.clear()
	_dirty_gardens.clear()
	_pending_empty_gardens.clear()
	_clear_garden_entry_resolve_cache("build_gardens")
	# Do NOT reset _next_garden_id: ids must stay monotonic across rebuilds so a new
	# garden can never reuse a previous garden's id (which would let a stale route
	# falsely match). Bump the epoch so every route from a prior rebuild is stale.
	_gardens_epoch += 1
	if plant_manager == null or not plant_manager.has_method("get_plant_cells"):
		_rebuild_plant_zone_compatibility_cache()
		_plant_zone_built = true
		return
	var plant_cells_from_manager: Array = plant_manager.call("get_plant_cells") as Array
	_cluster_plants_by_walkable_reachability(plant_cells_from_manager)
	_plant_zone_built = true

# Wall-aware clustering. Plants share a garden only if they are walkably
# connected within GARDEN_LINK_DISTANCE. A bounded BFS over walkable cells runs
# once per unassigned seed plant; plants it reaches join the seed's garden and
# are themselves re-seeded so a chain of close, walkably-connected plants forms
# one garden. Walls (non-walkable cells) are never traversed, so they split
# gardens automatically. This is the single cached rebuild used on dirty events.
func _cluster_plants_by_walkable_reachability(plant_cells_from_manager: Array) -> void:
	var unassigned: Dictionary = {}  # Vector2i -> true
	for raw_cell in plant_cells_from_manager:
		var cell: Vector2i = raw_cell
		unassigned[cell] = true

	while not unassigned.is_empty():
		var seed_cell: Vector2i = unassigned.keys()[0] as Vector2i
		var garden_id: int = _create_garden()
		var garden: Dictionary = _gardens[garden_id] as Dictionary
		var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary

		# Plants pending re-seed (BFS bound is measured from each of these).
		var frontier_plants: Array[Vector2i] = [seed_cell]
		unassigned.erase(seed_cell)
		plant_cells[seed_cell] = true
		_garden_by_plant_cell[seed_cell] = garden_id

		while not frontier_plants.is_empty():
			var from_plant: Vector2i = frontier_plants.pop_back()
			var reached: Array[Vector2i] = _bounded_walkable_plant_search(from_plant, unassigned)
			for reached_cell in reached:
				unassigned.erase(reached_cell)
				plant_cells[reached_cell] = true
				_garden_by_plant_cell[reached_cell] = garden_id
				frontier_plants.append(reached_cell)

		garden["plant_cells"] = plant_cells
		garden["edible_count"] = plant_cells.size()
		garden["targetable"] = false
		_gardens[garden_id] = garden
		_mark_garden_dirty(garden_id, false)

# Bounded BFS through walkable cells from a seed plant cell. Returns every cell in
# `unassigned` reachable within GARDEN_LINK_DISTANCE walkable steps. The seed cell
# itself is treated as the start even though plant cells must be walkable to be
# eaten; only walkable cells are expanded so walls cannot be crossed.
func _bounded_walkable_plant_search(seed_cell: Vector2i, unassigned: Dictionary) -> Array[Vector2i]:
	var found: Array[Vector2i] = []
	var visited: Dictionary = {seed_cell: 0}
	var queue: Array[Vector2i] = [seed_cell]
	var head: int = 0
	while head < queue.size():
		var cell: Vector2i = queue[head]
		head += 1
		var dist: int = int(visited[cell])
		if dist >= GARDEN_LINK_DISTANCE:
			continue
		for dy in range(-1, 2):
			for dx in range(-1, 2):
				if dx == 0 and dy == 0:
					continue
				var neighbor: Vector2i = cell + Vector2i(dx, dy)
				if visited.has(neighbor):
					continue
				if not _is_walkable(neighbor):
					continue
				# Match the pathfinder: no diagonal corner-cutting through walls.
				# A diagonal step is only valid if both orthogonal neighbors are
				# walkable, otherwise two plants tucked behind a wall corner would
				# look connected here but be unreachable to a monster.
				if dx != 0 and dy != 0:
					if not _is_walkable(cell + Vector2i(dx, 0)) or not _is_walkable(cell + Vector2i(0, dy)):
						continue
				visited[neighbor] = dist + 1
				queue.append(neighbor)
				if unassigned.has(neighbor):
					found.append(neighbor)
	return found

# A new plant invalidates clustering near it (it may bridge or seed a garden).
# Plant counts are small, so a single cached rebuild is the clean, correct path.
func _add_plant_to_gardens(cell: Vector2i) -> void:
	if _garden_by_plant_cell.has(cell):
		return
	_rebuild_plant_zone_from_layer()

# Canonical runtime plant-removal mutation. CONTENT-ONLY: it edits the garden's
# plant set and derived counts and nothing else. It deliberately does NOT touch
# zone_tiles / margin_tiles / entry_cells / reachable, and never triggers a full
# rebuild, geometry recompute, or dirty-garden validation. Garden doors stay
# stable while monsters eat plants. Returns a small status dictionary so the
# caller can decide how (and whether) to retarget agents — see _on_plant_removed.
#
# Accepted compromise: removing a plant never splits a garden. If the removed
# plant was the bridge between two walkable clusters, the survivors stay in the
# same historical garden (same id, same entry cells) until the next FULL topology
# rebuild. This is intentional: stable entry points + no per-eat rebuild cost.
func _remove_plant_from_garden_content_only(cell: Vector2i) -> Dictionary:
	if not _garden_by_plant_cell.has(cell):
		return {
			"garden_id": 0,
			"was_removed": false,
			"became_empty": false,
			"remaining_count": 0
		}
	var garden_id: int = int(_garden_by_plant_cell[cell])
	_garden_by_plant_cell.erase(cell)
	if not _gardens.has(garden_id):
		# Mapping pointed at a garden that no longer exists. Treat it as removed and
		# empty so the caller still gives bound agents a fresh target.
		return {
			"garden_id": garden_id,
			"was_removed": true,
			"became_empty": true,
			"remaining_count": 0
		}
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
	plant_cells.erase(cell)
	var remaining_count: int = plant_cells.size()
	# Content-only updates. zone_tiles / margin_tiles / entry_cells / reachable are
	# intentionally left untouched so the garden keeps its stable doors.
	garden["plant_cells"] = plant_cells
	garden["edible_count"] = remaining_count
	if remaining_count == 0:
		garden["targetable"] = false
	else:
		garden["targetable"] = bool(garden.get("reachable", false))
	_gardens[garden_id] = garden
	# When the garden just went empty we DON'T erase it here: the caller must first
	# queue the agents bound to it (it still needs the garden's data) and then call
	# _handle_garden_became_empty(), which releases routes and erases the garden.
	return {
		"garden_id": garden_id,
		"was_removed": true,
		"became_empty": remaining_count == 0,
		"remaining_count": remaining_count
	}

# TEMP DEBUG (garden crash hunt) -------------------------------------------
# Centralized garden erase. Empty gardens are allowed to disappear immediately;
# other mid-iteration erases still log because they are harder to reason about.
func _erase_garden(garden_id: int, reason: String) -> void:
	if _gardens_iter_depth > 0 and reason != "mark_empty":
		push_warning("GARDEN-CRASH-GUARD: _gardens erased during iteration! id=%d reason=%s depth=%d size_before=%d" % [
			garden_id, reason, _gardens_iter_depth, _gardens.size()
		])
	if _garden_debug_logs:
		_log("garden erase id=%d reason=%s gardens_now=%d" % [garden_id, reason, _gardens.size() - 1])
	_pending_empty_gardens.erase(garden_id)
	_gardens.erase(garden_id)
	_dirty_gardens.erase(garden_id)
	if _plant_zone_built:
		_rebuild_plant_zone_compatibility_cache()
	if _zone_overlay:
		_zone_overlay.queue_redraw()

# TEMP DEBUG (lost-agent / OUT OF BOUNDS hunt): a cell is "sane" only if it is a
# real, finite, in-a-reasonable-range tile. A bad cell (INVALID_CELL sentinel,
# max_cell sentinel, or anything absurd) fed to _cell_center yields a huge finite
# world pos; assigning that as a flow goal or an agent position makes the agent
# map to an out-of-bounds cell and go "lost" forever. Reject + log instead.
const _SANE_CELL_LIMIT: int = 100000
func _is_sane_cell(cell: Vector2i) -> bool:
	if cell == INVALID_CELL:
		return false
	if abs(cell.x) > _SANE_CELL_LIMIT or abs(cell.y) > _SANE_CELL_LIMIT:
		return false
	return true
# --------------------------------------------------------------------------

func _create_garden() -> int:
	var garden_id: int = _next_garden_id
	_next_garden_id += 1
	_gardens[garden_id] = {
		"id": garden_id,
		"epoch": _gardens_epoch,
		"plant_cells": {},
		"zone_tiles": {},
		"margin_tiles": {},
		"entry_cells": [],
		"edible_count": 0,
		"targetable": false,
		"dirty": true,
		"reachable": false,
		"version": 0
	}
	_dirty_gardens[garden_id] = true
	return garden_id

func _mark_garden_dirty(garden_id: int, invalidate_routes: bool) -> void:
	if not _gardens.has(garden_id):
		return
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	garden["dirty"] = true
	if invalidate_routes:
		garden["reachable"] = false
		garden["targetable"] = false
		garden["version"] = int(garden.get("version", 0)) + 1
	_gardens[garden_id] = garden
	_dirty_gardens[garden_id] = true

func _validate_dirty_gardens() -> void:
	if _dirty_gardens.is_empty():
		_rebuild_plant_zone_compatibility_cache()
		return
	var dirty_ids: Array = _dirty_gardens.keys()
	_dirty_gardens.clear()
	# Dirty gardens get their geometry (incl. entry_cells) recomputed below, which
	# can change scored entry selection, so the memoized resolution is stale.
	_clear_garden_entry_resolve_cache("validate_dirty_gardens")
	for raw_garden_id in dirty_ids:
		var garden_id: int = int(raw_garden_id)
		if not _gardens.has(garden_id):
			continue
		var garden: Dictionary = _gardens[garden_id] as Dictionary
		var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
		if plant_cells.is_empty():
			_release_garden_routes(garden_id)
			_erase_garden(garden_id, "validate_empty")
			continue
		_recompute_garden_geometry(garden_id)
	# No proximity-based merge step: garden identity comes from walkable BFS
	# clustering in _build_gardens_from_plants. Merging by margin/zone-tile
	# adjacency here would re-join gardens separated by a thin wall (their
	# wall-skipping margin tiles can meet around a corner), which is exactly the
	# bug this change fixes. Geometry below is per-cluster only.
	# A sealed enclosure has walkable interior tiles, so entry_cells alone is not
	# enough to call it reachable. Flood from spawners once and gate every garden
	# on whether an entry cell is reachable from a spawner.
	_recompute_spawner_reachable_cells()
	_gardens_iter_depth += 1
	var total_entry_points: int = 0
	for raw_garden_id in _gardens.keys():
		var gid: int = int(raw_garden_id)
		_apply_spawner_reachability(gid)
		total_entry_points += (_gardens[gid] as Dictionary).get("entry_cells", []).size()
	_gardens_iter_depth -= 1
	_rebuild_plant_zone_compatibility_cache()
	_plant_zone_built = true
	if _zone_overlay:
		_zone_overlay.queue_redraw()
	if _is_verbose():
		print("BuildingManager: %d gardens recomputed with %d entry points" % [_gardens.size(), total_entry_points])

# Garden geometry is navigation-aware, not box-geometry. A bounded walkable BFS
# from the plant cells (same 8-conn, no-corner-cut rules as the pathfinder/cluster
# BFS) defines the interior `zone_tiles`, so a thin wall or corner can never leak a
# zone tile to the far side of a wall (fix: the old Chebyshev margin box only
# skipped cells that *were* walls). Access cells (`entry_cells`) are the INTERIOR
# cells that border the outside through a valid no-corner-cut transition — they are
# in zone_tiles so the monster's flow field can settle on one (an outside goal at a
# 1-tile chokepoint makes agents oscillate, status "flow osc"). Access cells are
# non-exclusive and may overlap spawners/exits/markers; only non-walkability rejects.
func _recompute_garden_geometry(garden_id: int) -> void:
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary

	# Interior: walkable cells reachable from any plant within PLANT_ZONE_MARGIN
	# walkable steps. Plant cells seed the BFS and are always part of the interior.
	var zone_tiles: Dictionary = {}  # Vector2i -> true (interior, incl. plant cells)
	var dist: Dictionary = {}  # Vector2i -> walkable steps from nearest plant
	var queue: Array[Vector2i] = []
	var head: int = 0
	for raw_cell in plant_cells.keys():
		var plant_cell: Vector2i = raw_cell
		zone_tiles[plant_cell] = true
		dist[plant_cell] = 0
		queue.append(plant_cell)

	# Access detection: an access transition is a walkable interior cell that has a
	# valid step to a walkable cell *outside* the bounded interior. We record the
	# INSIDE cell of each such transition as the entry cell, not the outside cell:
	# the monster's flow field aims here and it must be a tile the agent can settle
	# on (surrounded by interior), otherwise it oscillates against the wall/gap at a
	# one-tile chokepoint and never hands off to A*. The inside cell is in
	# zone_tiles, so A* in/out, arrival, and pathing all work without snapping.
	var entry_inside: Dictionary = {}  # Vector2i -> true (interior cells that touch outside)

	while head < queue.size():
		var cell: Vector2i = queue[head]
		head += 1
		var cell_dist: int = int(dist[cell])
		for dy in range(-1, 2):
			for dx in range(-1, 2):
				if dx == 0 and dy == 0:
					continue
				var neighbor: Vector2i = cell + Vector2i(dx, dy)
				if not _is_walkable(neighbor):
					continue
				# No diagonal corner-cutting through walls (matches the pathfinder),
				# so a transition is only valid when a monster could really take it.
				if dx != 0 and dy != 0:
					if not _is_walkable(cell + Vector2i(dx, 0)) or not _is_walkable(cell + Vector2i(0, dy)):
						continue
				if zone_tiles.has(neighbor):
					continue
				var next_dist: int = cell_dist + 1
				if next_dist <= PLANT_ZONE_MARGIN:
					# Still inside the bounded interior.
					if not dist.has(neighbor) or next_dist < int(dist[neighbor]):
						dist[neighbor] = next_dist
						zone_tiles[neighbor] = true
						queue.append(neighbor)
				else:
					# `cell` (interior) has a valid transition to `neighbor`, a
					# walkable cell beyond the interior: `cell` is an access cell.
					entry_inside[cell] = true

	# margin_tiles keeps its prior meaning for the overlay/compat cache: interior
	# tiles that are not plant cells. Entry cells are the interior access cells
	# (cells that border the outside through a valid transition); the flow field
	# and arrival target these.
	var margin_tiles: Dictionary = {}
	for raw_cell in zone_tiles.keys():
		var zone_cell: Vector2i = raw_cell
		if not plant_cells.has(zone_cell):
			margin_tiles[zone_cell] = true
	var entry_cells: Array[Vector2i] = []
	for raw_cell in entry_inside.keys():
		var access_cell: Vector2i = raw_cell
		entry_cells.append(access_cell)

	garden["zone_tiles"] = zone_tiles
	garden["margin_tiles"] = margin_tiles
	garden["entry_cells"] = entry_cells
	# Provisional: refined by _apply_spawner_reachability once the spawner flood
	# is available. A garden with no walkable access tile can never be reachable.
	garden["reachable"] = not entry_cells.is_empty()
	garden["edible_count"] = plant_cells.size()
	garden["targetable"] = plant_cells.size() > 0 and not entry_cells.is_empty()
	garden["dirty"] = false
	_gardens[garden_id] = garden

# Single source flood-fill from every spawner cell over the walkable map (same
# walkability + diagonal corner rules as the pathfinder). Bounded by the floor
# tilemap because expansion requires _has_floor. Runs once per garden rebuild.
func _recompute_spawner_reachable_cells() -> void:
	_spawner_reachable_cells.clear()
	if _spawners.is_empty():
		return
	var queue: Array[Vector2i] = []
	var head: int = 0
	for raw_spawner_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_spawner_cell
		# Start from the spawner's walkable footprint; spawners may sit on a
		# non-walkable special tile, so seed from walkable neighbors too.
		for dy in range(-1, 2):
			for dx in range(-1, 2):
				var myseed: Vector2i = spawner_cell + Vector2i(dx, dy)
				if _spawner_reachable_cells.has(myseed):
					continue
				if not _is_walkable(myseed):
					continue
				_spawner_reachable_cells[myseed] = true
				queue.append(myseed)
	while head < queue.size():
		var cell: Vector2i = queue[head]
		head += 1
		for dy in range(-1, 2):
			for dx in range(-1, 2):
				if dx == 0 and dy == 0:
					continue
				var neighbor: Vector2i = cell + Vector2i(dx, dy)
				if _spawner_reachable_cells.has(neighbor):
					continue
				if not _is_walkable(neighbor):
					continue
				if dx != 0 and dy != 0:
					if not _is_walkable(cell + Vector2i(dx, 0)) or not _is_walkable(cell + Vector2i(0, dy)):
						continue
				_spawner_reachable_cells[neighbor] = true
				queue.append(neighbor)

# A garden is reachable only if one of its walkable entry cells is in the spawner
# flood. Sealed enclosures (no entry cell connects out to a spawner) become
# unreachable and non-targetable, so outside monsters ignore them.
func _apply_spawner_reachability(garden_id: int) -> void:
	if not _gardens.has(garden_id):
		return
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var entry_cells: Array = garden.get("entry_cells", []) as Array
	# With no spawners, fall back to "has entry cell" so editor/preview still
	# shows gardens instead of marking everything unreachable.
	var reachable: bool = false
	if _spawners.is_empty():
		reachable = not entry_cells.is_empty()
	else:
		for raw_cell in entry_cells:
			var entry_cell: Vector2i = raw_cell
			if _spawner_reachable_cells.has(entry_cell):
				reachable = true
				break
	garden["reachable"] = reachable
	var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
	garden["targetable"] = reachable and plant_cells.size() > 0
	_gardens[garden_id] = garden

func _rebuild_plant_zone_compatibility_cache() -> void:
	_plant_zone_tiles.clear()
	_plant_zone_margin_tiles.clear()
	for raw_garden in _gardens.values():
		var garden: Dictionary = raw_garden as Dictionary
		var zone_tiles: Dictionary = garden.get("zone_tiles", {}) as Dictionary
		var margin_tiles: Dictionary = garden.get("margin_tiles", {}) as Dictionary
		var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
		for raw_cell in zone_tiles.keys():
			var zone_cell: Vector2i = raw_cell
			_plant_zone_tiles[zone_cell] = true
		for raw_cell in margin_tiles.keys():
			var margin_cell: Vector2i = raw_cell
			_plant_zone_margin_tiles[margin_cell] = true
		if bool(garden.get("dirty", false)):
			for raw_cell in plant_cells.keys():
				var plant_cell: Vector2i = raw_cell
				_plant_zone_tiles[plant_cell] = true

# Snapshot both key sets: _release_spawner_garden_route erases from `routes` (inner)
# and can erase from _spawner_garden_routes (outer) when a spawner's routes empty.
# Iterating live .keys() while erasing is the Dictionary-mutation-during-iteration
# that can silently crash; .duplicate() decouples the iteration from the mutation.
func _rebuild_spawner_garden_route_cache() -> void:
	# Routes are rebuilt against current entries; drop the memoized entry resolution
	# so retargets after this re-score against the refreshed topology.
	_clear_garden_entry_resolve_cache("rebuild_route_cache")
	for raw_spawner_cell in _spawner_garden_routes.keys().duplicate():
		var spawner_cell: Vector2i = raw_spawner_cell
		if not _spawner_garden_routes.has(spawner_cell):
			continue
		var routes: Dictionary = _spawner_garden_routes[spawner_cell] as Dictionary
		for raw_garden_id in routes.keys().duplicate():
			var garden_id: int = int(raw_garden_id)
			if not routes.has(garden_id):
				continue
			var route: Dictionary = routes[garden_id] as Dictionary
			if not _garden_route_is_current(route, garden_id):
				_release_spawner_garden_route(spawner_cell, garden_id)

func _release_garden_routes(garden_id: int) -> void:
	# Snapshot: _release_spawner_garden_route can erase from _spawner_garden_routes.
	for raw_spawner_cell in _spawner_garden_routes.keys().duplicate():
		var spawner_cell: Vector2i = raw_spawner_cell
		_release_spawner_garden_route(spawner_cell, garden_id)

func _release_spawner_garden_route(spawner_cell: Vector2i, garden_id: int) -> void:
	if not _spawner_garden_routes.has(spawner_cell):
		return
	var routes: Dictionary = _spawner_garden_routes[spawner_cell] as Dictionary
	if not routes.has(garden_id):
		return
	var route: Dictionary = routes[garden_id] as Dictionary
	var plant_group: int = int(route.get("plant_group", -1))
	if plant_group > IDLE_GROUP and agent_manager and agent_manager.has_method("dissolve_group"):
		agent_manager.call("dissolve_group", plant_group)
	routes.erase(garden_id)
	if routes.is_empty():
		_spawner_garden_routes.erase(spawner_cell)
	else:
		_spawner_garden_routes[spawner_cell] = routes

func _garden_route_is_current(route: Dictionary, garden_id: int) -> bool:
	if not _gardens.has(garden_id):
		return false
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	if not bool(garden.get("reachable", false)):
		return false
	# Epoch first: a route from a previous full rebuild can never be current even if
	# its (id, version) coincidentally matches a new garden. This is what stops
	# night-2 agents from flowing to a deleted night-1 garden's entry tile.
	if int(route.get("garden_epoch", -1)) != int(garden.get("epoch", -2)):
		return false
	return int(route.get("garden_version", -1)) == int(garden.get("version", 0))

func _select_garden_for_spawner(spawner_cell: Vector2i) -> int:
	var best_garden_id: int = 0
	var best_dist: int = 2147483647
	_gardens_iter_depth += 1
	for raw_garden_id in _gardens.keys():
		var garden_id: int = int(raw_garden_id)
		var garden: Dictionary = _gardens[garden_id] as Dictionary
		if not bool(garden.get("targetable", false)):
			continue
		if not _garden_has_edible_plants(garden_id):
			continue
		var entry_cell: Vector2i = _nearest_garden_entry(garden_id, spawner_cell)
		if entry_cell == INVALID_CELL:
			continue
		var delta: Vector2i = entry_cell - spawner_cell
		var manhattan: int = abs(delta.x) + abs(delta.y)
		if manhattan < best_dist:
			best_dist = manhattan
			best_garden_id = garden_id
	_gardens_iter_depth -= 1
	_drain_pending_empty_gardens()
	# The chosen garden may have just been drained as empty; fall through to 0.
	if best_garden_id > 0 and not _gardens.has(best_garden_id):
		return 0
	return best_garden_id

func _select_spawner_garden_for_agent(from_cell: Vector2i) -> Dictionary:
	var best_pair: Dictionary = {}
	var best_dist: int = 2147483647
	# Reset the per-resolve cache tallies; each _nearest_garden_entry below adds in.
	_garden_entry_resolve_hits = 0
	_garden_entry_resolve_misses = 0
	_gardens_iter_depth += 1
	for raw_spawner_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_spawner_cell
		if not _spawner_routes.has(spawner_cell):
			continue
		for raw_garden_id in _gardens.keys():
			var garden_id: int = int(raw_garden_id)
			var garden: Dictionary = _gardens[garden_id] as Dictionary
			if not bool(garden.get("targetable", false)):
				continue
			if not _garden_has_edible_plants(garden_id):
				continue
			var entry_cell: Vector2i = _nearest_garden_entry(garden_id, spawner_cell)
			if _garden_entry_resolve_cache_hit:
				_garden_entry_resolve_hits += 1
			else:
				_garden_entry_resolve_misses += 1
			if entry_cell == INVALID_CELL:
				continue
			var delta: Vector2i = entry_cell - from_cell
			var manhattan: int = abs(delta.x) + abs(delta.y)
			if manhattan < best_dist:
				best_dist = manhattan
				best_pair = {
					"spawner_cell": spawner_cell,
					"garden_id": garden_id
				}
	_gardens_iter_depth -= 1
	_drain_pending_empty_gardens()
	# The chosen garden may have just been drained as empty; drop the stale pair.
	if not best_pair.is_empty() and not _gardens.has(int(best_pair.get("garden_id", 0))):
		return {}
	return best_pair

func _select_spawner_for_garden_from_cell(garden_id: int, from_cell: Vector2i, fallback_spawner_cell: Vector2i) -> Vector2i:
	var best_spawner_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for raw_spawner_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_spawner_cell
		if not _spawner_routes.has(spawner_cell):
			continue
		var entry_cell: Vector2i = _nearest_garden_entry(garden_id, spawner_cell)
		if entry_cell == INVALID_CELL:
			continue
		var delta: Vector2i = entry_cell - from_cell
		var manhattan: int = abs(delta.x) + abs(delta.y)
		if manhattan < best_dist:
			best_dist = manhattan
			best_spawner_cell = spawner_cell
	if best_spawner_cell == INVALID_CELL and fallback_spawner_cell != INVALID_CELL and _spawner_routes.has(fallback_spawner_cell):
		if _nearest_garden_entry(garden_id, fallback_spawner_cell) != INVALID_CELL:
			best_spawner_cell = fallback_spawner_cell
	return best_spawner_cell

func _find_local_retarget_plant(from_cell: Vector2i) -> Dictionary:
	# Start fresh so the parent breakdown never reads a stale plant/path profile when
	# this returns early (or isn't reached at all this retarget).
	_last_find_local_retarget_profile = {}
	if empty_garden_local_retarget_radius <= 0:
		return {}
	if plant_manager == null or not plant_manager.has_method("has_plant"):
		return {}
	# This scans a radius around from_cell and runs _find_path_in_zone per candidate,
	# so it can spike when the radius is large or many candidates path. The path checks
	# are the prime suspect, so we aggregate counts (NO per-candidate arrays/logs) and
	# the total time spent in path checks, and warn on those separately. A single
	# per-candidate path check is logged only if it alone exceeds the threshold.
	# This is the only place that loops _find_path_in_zone during a retarget, so reset
	# its accumulator here; each path query below adds into it for the parent breakdown.
	_reset_find_path_in_zone_accum()
	var local_us: int = Time.get_ticks_usec()
	var radius: int = maxi(0, empty_garden_local_retarget_radius)
	var best_target: Dictionary = {}
	var best_path_len: int = 2147483647
	var best_dist: int = 2147483647
	# Aggregate counters only — cheap ints, no growing collections.
	var cells_scanned: int = 0          # cells visited inside the manhattan disc
	var plant_candidates: int = 0       # cells that actually held a plant
	var rejected_no_garden: int = 0     # plant cell not mapped to a garden
	var rejected_not_edible: int = 0    # garden has no edible plants
	var path_checks: int = 0            # _find_path_in_zone calls made
	var path_failures: int = 0          # path checks that returned empty
	var path_checks_us: int = 0         # total time spent in path checks
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			var manhattan: int = abs(dx) + abs(dy)
			if manhattan > radius:
				continue
			cells_scanned += 1
			var plant_cell: Vector2i = from_cell + Vector2i(dx, dy)
			if not bool(plant_manager.call("has_plant", plant_cell)):
				continue
			plant_candidates += 1
			if not _garden_by_plant_cell.has(plant_cell):
				rejected_no_garden += 1
				continue
			var garden_id: int = int(_garden_by_plant_cell[plant_cell])
			if not _garden_has_edible_plants(garden_id):
				rejected_not_edible += 1
				continue
			# Per-candidate path check. Time each one so a single dominating check is
			# attributable; only log the individual check when it alone spikes.
			var check_us: int = Time.get_ticks_usec()
			var path_cells: PackedVector2Array = _find_path_in_zone(from_cell, plant_cell, garden_id)
			var this_check_us: int = Time.get_ticks_usec() - check_us
			path_checks += 1
			path_checks_us += this_check_us
			if _over_garden_threshold_us(this_check_us):
				_warn_garden_task_lag_us("_find_local_retarget_plant.path_check", this_check_us,
					"from=%s to=%s garden=%d len=%d" % [str(from_cell), str(plant_cell), garden_id, path_cells.size()])
			if path_cells.is_empty():
				path_failures += 1
				continue
			var path_len: int = path_cells.size()
			if path_len < best_path_len or (path_len == best_path_len and manhattan < best_dist):
				best_path_len = path_len
				best_dist = manhattan
				best_target = {
					"plant_cell": plant_cell,
					"garden_id": garden_id,
					"path_cells": path_cells
				}
	# _garden_has_edible_plants may have queued stale-empty gardens; this search
	# does not iterate _gardens, so draining here is safe.
	_drain_pending_empty_gardens()
	var total_us: int = Time.get_ticks_usec() - local_us
	var found: bool = not best_target.is_empty()
	# Stash the aggregate profile for the parent breakdown (cheap int writes; read by
	# _try_local_retarget_agent and the consolidated _retarget_agent_or_escape line).
	_last_find_local_retarget_profile = {
		"radius": radius,
		"cells_checked": cells_scanned,
		"candidates_found": plant_candidates,
		"rejected_wrong_garden": rejected_no_garden,
		"rejected_not_edible": rejected_not_edible,
		"path_checks": path_checks,
		"path_failures": path_failures,
		"path_checks_total_us": path_checks_us,
		"total_us": total_us,
		"success": found,
	}
	# Aggregate path-check total: when this dominates, the cost is the repeated
	# _find_path_in_zone calls rather than the candidate scan itself. Both summary
	# warnings build their context only on a real spike (this runs in a tight retarget
	# loop, so unconditional formatting would be the wrong kind of overhead).
	if _over_garden_threshold_us(path_checks_us):
		_warn_garden_task_lag_us("_find_local_retarget_plant.path_checks_total", path_checks_us,
			"path_checks=%d failures=%d" % [path_checks, path_failures])
	if _over_garden_threshold_us(total_us):
		push_warning("debug_garden_lag_breakdown:_find_local_retarget_plant total=%.1fms threshold=%dms from=%s radius=%d cells_checked=%d candidates=%d wrong_garden=%d not_edible=%d path_checks=%d path_fail=%d path_checks_total=%.1fms success=%s" % [
			float(total_us) / 1000.0, int(_garden_lag_threshold_ms()), str(from_cell),
			radius, cells_scanned, plant_candidates,
			rejected_no_garden, rejected_not_edible, path_checks, path_failures,
			float(path_checks_us) / 1000.0, str(found)
		])
	if not best_target.is_empty() and not _gardens.has(int(best_target.get("garden_id", 0))):
		return {}
	return best_target

# Fills _last_local_retarget_profile at every exit so the parent breakdown can show
# the local-retarget split (candidate search vs. path validation vs. assignment, plus
# candidate/path-check counts) even when this whole call is below threshold. The
# per-section .candidate_search / .assignment warnings are kept for the case where one
# section alone spikes; this function also emits its own consolidated breakdown line
# when its total exceeds threshold.
# Sub-sections:
#   candidate_search - radius scan + plant/garden filtering (search minus path checks)
#   path_validation  - the per-candidate _find_path_in_zone calls
#   assignment       - detach + assign_agent_path + phase-dict bookkeeping
func _try_local_retarget_agent(agent: Node2D, from_cell: Vector2i, spawner_cell: Vector2i) -> bool:
	var total_us: int = Time.get_ticks_usec()
	var nav_id_dbg: int = int(agent.get("nav_id"))
	_last_local_retarget_profile = {
		"candidates": 0,
		"path_checks": 0,
		"candidate_search_us": 0,
		"path_validation_us": 0,
		"assignment_us": 0,
		"success": false,
	}
	var search_us: int = Time.get_ticks_usec()
	var target: Dictionary = _find_local_retarget_plant(from_cell)
	var search_elapsed: int = Time.get_ticks_usec() - search_us
	# Split the search time: path validation (the find_path calls) vs. the rest of the
	# scan. Counts/path-check time come from the plant-search profile filled just above.
	var fl: Dictionary = _last_find_local_retarget_profile
	var path_validation_us: int = int(fl.get("path_checks_total_us", 0))
	_last_local_retarget_profile["candidates"] = int(fl.get("candidates_found", 0))
	_last_local_retarget_profile["path_checks"] = int(fl.get("path_checks", 0))
	_last_local_retarget_profile["path_validation_us"] = path_validation_us
	_last_local_retarget_profile["candidate_search_us"] = maxi(0, search_elapsed - path_validation_us)
	_warn_garden_task_lag_us("_try_local_retarget_agent.candidate_search", search_elapsed,
		"nav_id=%d from=%s found=%s" % [nav_id_dbg, str(from_cell), str(not target.is_empty())])
	if target.is_empty():
		_finish_local_retarget_profile(nav_id_dbg, from_cell, total_us, false)
		return false
	var plant_cell: Vector2i = target.get("plant_cell", INVALID_CELL) as Vector2i
	var garden_id: int = int(target.get("garden_id", 0))
	var path_cells: PackedVector2Array = target.get("path_cells", PackedVector2Array()) as PackedVector2Array
	if plant_cell == INVALID_CELL or garden_id <= 0 or path_cells.is_empty():
		_finish_local_retarget_profile(nav_id_dbg, from_cell, total_us, false)
		return false
	var route_spawner_cell: Vector2i = _select_spawner_for_garden_from_cell(garden_id, from_cell, spawner_cell)
	if route_spawner_cell == INVALID_CELL:
		_finish_local_retarget_profile(nav_id_dbg, from_cell, total_us, false)
		return false
	var assign_us: int = Time.get_ticks_usec()
	var nav_id: int = int(agent.get("nav_id"))
	if agent_manager and agent_manager.has_method("detach_agent_flow"):
		agent_manager.call("detach_agent_flow", nav_id)
	var path_world: PackedVector2Array = _path_cells_to_world(path_cells)
	if agent_manager and agent_manager.has_method("assign_agent_path"):
		agent_manager.call("assign_agent_path", nav_id, path_world)
	_entry_path_agents.erase(nav_id)
	_set_astar_in_agent(nav_id, {
		"node": agent,
		"plant_cell": plant_cell,
		"spawner_cell": route_spawner_cell,
		"garden_id": garden_id,
		"path_world": path_world
	})
	agent.set_meta("spawner_cell", route_spawner_cell)
	agent.set_meta("garden_id", garden_id)
	# Record the entry tile once it is known valid so the in-garden entry is tracked.
	var in_entry_cell: Vector2i = _nearest_garden_entry(garden_id, route_spawner_cell)
	if in_entry_cell != INVALID_CELL:
		agent.set_meta("garden_entry_cell", in_entry_cell)
	if agent.has_method("start_astar_in"):
		agent.call("start_astar_in")
	var assignment_elapsed: int = Time.get_ticks_usec() - assign_us
	_last_local_retarget_profile["assignment_us"] = assignment_elapsed
	_warn_garden_task_lag_us("_try_local_retarget_agent.assignment", assignment_elapsed,
		"nav_id=%d garden=%d plant=%s path_len=%d" % [nav_id, garden_id, str(plant_cell), path_cells.size()])
	_finish_local_retarget_profile(nav_id_dbg, from_cell, total_us, true)
	return true

# Stamp the local-retarget total + success and emit a consolidated breakdown line when
# this attempt alone exceeds threshold. (The parent reads _last_local_retarget_profile
# directly for its own line, so this is only for the local-spike case.)
func _finish_local_retarget_profile(nav_id: int, from_cell: Vector2i, total_start_us: int, success: bool) -> void:
	var total_us: int = Time.get_ticks_usec() - total_start_us
	_last_local_retarget_profile["success"] = success
	_last_local_retarget_profile["total_us"] = total_us
	if not _over_garden_threshold_us(total_us):
		return
	var p: Dictionary = _last_local_retarget_profile
	push_warning("debug_garden_lag_breakdown:_try_local_retarget_agent total=%.1fms nav_id=%d from=%s success=%s candidates=%d path_checks=%d candidate_search=%.1fms path_validation=%.1fms assign=%.1fms" % [
		float(total_us) / 1000.0, nav_id, str(from_cell), str(success),
		int(p.get("candidates", 0)), int(p.get("path_checks", 0)),
		float(p.get("candidate_search_us", 0)) / 1000.0,
		float(p.get("path_validation_us", 0)) / 1000.0,
		float(p.get("assignment_us", 0)) / 1000.0,
	])

func _assign_agent_to_garden_entry_path(agent: Node2D, spawner_cell: Vector2i, garden_id: int, entry_cell: Vector2i) -> bool:
	if not is_instance_valid(agent):
		return false
	if entry_cell == INVALID_CELL or not _is_sane_cell(entry_cell):
		return false
	if agent_manager == null or not agent_manager.has_method("assign_agent_path"):
		return false
	var nav_id: int = int(agent.get("nav_id"))
	var from_cell: Vector2i = floorz.local_to_map(floorz.to_local(agent.global_position))
	var path_cells: PackedVector2Array = _find_path_on_walkable_map(from_cell, entry_cell)
	if path_cells.is_empty():
		return false
	if agent_manager.has_method("detach_agent_flow"):
		agent_manager.call("detach_agent_flow", nav_id)
	if agent_manager.has_method("detach_agent_path"):
		agent_manager.call("detach_agent_path", nav_id)
	var path_world: PackedVector2Array = _path_cells_to_world(path_cells)
	agent_manager.call("assign_agent_path", nav_id, path_world)
	_entry_path_agents[nav_id] = {
		"node": agent,
		"spawner_cell": spawner_cell,
		"garden_id": garden_id,
		"entry_cell": entry_cell,
		"path_world": path_world
	}
	_erase_astar_in_agent(nav_id)
	_escaping_agents.erase(nav_id)
	agent.set_meta("spawner_cell", spawner_cell)
	agent.set_meta("garden_id", garden_id)
	agent.set_meta("garden_entry_cell", entry_cell)
	# Heading toward the garden, not yet eaten: "flow in". The inside-garden A* leg
	# transitions to "astar in" in _start_astar_in once the entry is reached.
	if agent.has_method("start_flow_in"):
		agent.call("start_flow_in")
	return true

func _get_or_create_spawner_garden_route(spawner_cell: Vector2i, garden_id: int) -> Dictionary:
	if not _spawner_garden_routes.has(spawner_cell):
		_spawner_garden_routes[spawner_cell] = {}
	var routes: Dictionary = _spawner_garden_routes[spawner_cell] as Dictionary
	var existing_route: Dictionary = routes.get(garden_id, {}) as Dictionary
	if bool(existing_route.get("ready", false)) and _garden_route_is_current(existing_route, garden_id):
		_route_cache_hits += 1
		return existing_route
	# Cache miss: recompute the route (nearest garden entry + sanity checks) below.
	_route_cache_misses += 1
	if not _gardens.has(garden_id):
		return {"ready": false}
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var entry_cell: Vector2i = _nearest_garden_entry(garden_id, spawner_cell)
	if entry_cell == INVALID_CELL:
		return {"ready": false}
	if not _is_sane_cell(entry_cell):
		push_warning("LOST-AGENT-GUARD: garden %d gave insane entry_cell %s for spawner %s; route refused" % [
			garden_id, entry_cell, spawner_cell
		])
		return {"ready": false}
	var entry_world: Vector2 = _cell_center(entry_cell)
	if not _is_finite_world(entry_world):
		push_warning("LOST-AGENT-GUARD: insane entry_world %s (cell %s) for spawner %s garden %d; route refused" % [
			entry_world, entry_cell, spawner_cell, garden_id
		])
		return {"ready": false}
	var route: Dictionary = {
		"entry_cell": entry_cell,
		"entry_world": entry_world,
		"ready": true,
		"garden_version": int(garden.get("version", 0)),
		"garden_epoch": int(garden.get("epoch", -1))
	}
	routes[garden_id] = route
	_spawner_garden_routes[spawner_cell] = routes
	return route

# Returns true once the agent has a real new nav state (a garden entry path, or a
# successfully assigned escape). Returns false only when neither a garden route nor
# an escape could be assigned, so the budgeted queue can requeue it. Every escape
# fallback below propagates _assign_agent_to_escape's own success/failure.
#
# Parent-triggered breakdown: _impl accumulates every inner section's time into a
# fresh _last_retarget_profile (cheap int writes, no per-section warnings). Here, when
# the total exceeds threshold, we emit ONE "debug_garden_lag_breakdown" line with the
# full section split — so a 16-18ms total whose cost is spread across several
# sub-threshold sections is still fully explained on a single line.
func _retarget_agent_or_escape(agent: Node2D, spawner_cell: Vector2i) -> bool:
	if not is_instance_valid(agent):
		return false
	var retarget_us: int = Time.get_ticks_usec()
	var nav_id_dbg: int = int(agent.get("nav_id"))
	var assigned: bool = _retarget_agent_or_escape_impl(agent, spawner_cell)
	var total_us: int = Time.get_ticks_usec() - retarget_us
	if _over_garden_threshold_us(total_us):
		_emit_retarget_breakdown(nav_id_dbg, assigned, total_us)
	return assigned

# Build and push the single consolidated breakdown line. Reads the section timings
# accumulated by _impl (_last_retarget_profile) plus the local-retarget and path-zone
# profiles filled by the child functions. Only called when over threshold, so the
# (larger) string is built only on a real spike.
func _emit_retarget_breakdown(nav_id: int, assigned: bool, total_us: int) -> void:
	var p: Dictionary = _last_retarget_profile
	var lr: Dictionary = _last_local_retarget_profile
	var fpz: Dictionary = _find_path_in_zone_accum
	var entry_cache_misses: int = int(p.get("entry_cache_misses", 0))
	var msg: String = "nav_id=%d assigned=%s reason=%s lookup=%.1fms resolve=%.1fms local_retarget=%.1fms escape=%.1fms assign=%.1fms entry_cache_hit=%s entry_cache_hits=%d entry_cache_misses=%d entry_cache_size=%d" % [
		nav_id, str(assigned), str(p.get("reason", "")),
		float(p.get("lookup_us", 0)) / 1000.0,
		float(p.get("resolve_us", 0)) / 1000.0,
		float(p.get("local_retarget_us", 0)) / 1000.0,
		float(p.get("escape_us", 0)) / 1000.0,
		float(p.get("assign_us", 0)) / 1000.0,
		str(entry_cache_misses == 0),
		int(p.get("entry_cache_hits", 0)),
		entry_cache_misses,
		int(p.get("entry_cache_size", 0)),
	]
	# Local-retarget detail (filled only when the local attempt actually ran).
	if not lr.is_empty():
		msg += " local_candidates=%d local_path_checks=%d local_search=%.1fms local_path_validation=%.1fms local_assign=%.1fms local_success=%s" % [
			int(lr.get("candidates", 0)), int(lr.get("path_checks", 0)),
			float(lr.get("candidate_search_us", 0)) / 1000.0,
			float(lr.get("path_validation_us", 0)) / 1000.0,
			float(lr.get("assignment_us", 0)) / 1000.0,
			str(lr.get("success", false)),
		]
	# Path-in-zone aggregate (across every _find_path_in_zone call this retarget).
	if int(fpz.get("call_count", 0)) > 0:
		msg += " path_calls=%d path_total=%.1fms path_sync=%.1fms path_blockers=%.1fms path_find=%.1fms max_path=%.1fms max_path_from=%s max_path_to=%s max_zone_tiles=%d" % [
			int(fpz.get("call_count", 0)),
			float(fpz.get("total_us", 0)) / 1000.0,
			float(fpz.get("sync_zone_total_us", 0)) / 1000.0,
			float(fpz.get("blocker_total_us", 0)) / 1000.0,
			float(fpz.get("find_path_total_us", 0)) / 1000.0,
			float(fpz.get("max_single_call_us", 0)) / 1000.0,
			str(fpz.get("max_single_call_from", INVALID_CELL)),
			str(fpz.get("max_single_call_to", INVALID_CELL)),
			int(fpz.get("max_zone_tiles", 0)),
		]
	var threshold_ms: float = _garden_lag_threshold_ms()
	push_warning("debug_garden_lag_breakdown:_retarget_agent_or_escape total=%.1fms threshold=%dms %s" % [
		float(total_us) / 1000.0, int(threshold_ms), msg
	])

# Reset all retarget profiling accumulators at the start of a retarget. Cheap; keeps a
# stale profile from a previous (possibly different code path) retarget out of the next
# breakdown line.
func _reset_retarget_profile() -> void:
	_last_retarget_profile = {
		"reason": "",
		"lookup_us": 0,
		"resolve_us": 0,
		"local_retarget_us": 0,
		"escape_us": 0,
		"assign_us": 0,
		"entry_cache_hits": 0,
		"entry_cache_misses": 0,
		"entry_cache_size": 0,
	}
	_last_local_retarget_profile = {}
	_last_find_local_retarget_profile = {}
	_reset_find_path_in_zone_accum()

# The path-zone accumulator is reset at the start of the local plant search (the only
# place that loops _find_path_in_zone during retarget) so its aggregate reflects just
# that retarget's path queries.
func _reset_find_path_in_zone_accum() -> void:
	_find_path_in_zone_accum = {
		"call_count": 0,
		"total_us": 0,
		"sync_zone_total_us": 0,
		"blocker_total_us": 0,
		"find_path_total_us": 0,
		"max_single_call_us": 0,
		"max_single_call_from": INVALID_CELL,
		"max_single_call_to": INVALID_CELL,
		"max_zone_tiles": 0,
	}

# Sub-detectors (all gated on debug_gardens_lag_ms via _warn_garden_task_lag_us) are
# kept for the case where ONE section alone spikes. The accumulated section timings in
# _last_retarget_profile are what feed the consolidated parent breakdown above.
#   .validity       - is_instance_valid + no_plants_remaining gate + from_cell resolve
#   .local_retarget - _try_local_retarget_agent (radius scan + per-candidate paths)
#   .target_resolve - _select_spawner_garden_for_agent + route lookup/entry resolution
#   .escape         - _assign_agent_to_escape fallback (whichever branch reaches it)
#   .final_assign   - _assign_agent_to_garden_entry_path + set_agent_never_rest
func _retarget_agent_or_escape_impl(agent: Node2D, spawner_cell: Vector2i) -> bool:
	_reset_retarget_profile()
	var t_val: int = Time.get_ticks_usec()
	if not is_instance_valid(agent):
		return false
	var nav_id_dbg: int = int(agent.get("nav_id"))
	# Agent validity / target precondition: no plants left anywhere -> straight to escape.
	var no_plants: bool = _no_plants_remaining()
	var from_cell: Vector2i = INVALID_CELL
	if not no_plants:
		from_cell = floorz.local_to_map(floorz.to_local(agent.global_position))
	var lookup_us: int = Time.get_ticks_usec() - t_val
	_last_retarget_profile["lookup_us"] = lookup_us
	_warn_garden_task_lag_us("_retarget_agent_or_escape.validity", lookup_us,
		"nav_id=%d no_plants=%s" % [nav_id_dbg, str(no_plants)])
	if no_plants:
		_last_retarget_profile["reason"] = "no_plants"
		var t_esc0: int = Time.get_ticks_usec()
		var esc0: bool = _assign_agent_to_escape(agent)
		var esc0_us: int = Time.get_ticks_usec() - t_esc0
		_last_retarget_profile["escape_us"] = esc0_us
		_warn_garden_task_lag_us("_retarget_agent_or_escape.escape", esc0_us,
			"nav_id=%d reason=no_plants assigned=%s" % [nav_id_dbg, str(esc0)])
		return esc0

	# Local retarget attempt: radius scan around the agent + per-candidate path checks.
	var local_us: int = Time.get_ticks_usec()
	var local_ok: bool = _try_local_retarget_agent(agent, from_cell, spawner_cell)
	var local_retarget_us: int = Time.get_ticks_usec() - local_us
	_last_retarget_profile["local_retarget_us"] = local_retarget_us
	_warn_garden_task_lag_us("_retarget_agent_or_escape.local_retarget", local_retarget_us,
		"nav_id=%d from=%s ok=%s" % [nav_id_dbg, str(from_cell), str(local_ok)])
	if local_ok:
		_last_retarget_profile["reason"] = "local_retarget"
		return true

	# Current garden / target resolution: pick a (spawner, garden) pair and resolve its
	# entry route. Cheap normally, but timed so a slow _select_spawner_garden_for_agent
	# or route recompute is attributable rather than lumped into the parent total.
	var t_res: int = Time.get_ticks_usec()
	var pair: Dictionary = _select_spawner_garden_for_agent(from_cell)
	# Cache stats for this resolve (set by _select_spawner_garden_for_agent's loop).
	_last_retarget_profile["entry_cache_hits"] = _garden_entry_resolve_hits
	_last_retarget_profile["entry_cache_misses"] = _garden_entry_resolve_misses
	_last_retarget_profile["entry_cache_size"] = _garden_entry_resolve_cache.size()
	if pair.is_empty():
		if spawner_cell == INVALID_CELL:
			spawner_cell = _nearest_spawner_cell(from_cell)
		if spawner_cell != INVALID_CELL and _spawner_routes.has(spawner_cell):
			agent.set_meta("spawner_cell", spawner_cell)
		_last_retarget_profile["resolve_us"] = Time.get_ticks_usec() - t_res
		_warn_garden_task_lag_us("_retarget_agent_or_escape.target_resolve", int(_last_retarget_profile["resolve_us"]),
			"nav_id=%d pair=empty" % nav_id_dbg)
		return _escape_with_detector(agent, nav_id_dbg, "no_pair")
	spawner_cell = pair.get("spawner_cell", INVALID_CELL) as Vector2i
	var garden_id: int = int(pair.get("garden_id", 0))
	if garden_id <= 0:
		_last_retarget_profile["resolve_us"] = Time.get_ticks_usec() - t_res
		_warn_garden_task_lag_us("_retarget_agent_or_escape.target_resolve", int(_last_retarget_profile["resolve_us"]),
			"nav_id=%d garden=0" % nav_id_dbg)
		return _escape_with_detector(agent, nav_id_dbg, "garden<=0")
	var route: Dictionary = _get_or_create_spawner_garden_route(spawner_cell, garden_id)
	if not bool(route.get("ready", false)):
		_last_retarget_profile["resolve_us"] = Time.get_ticks_usec() - t_res
		_warn_garden_task_lag_us("_retarget_agent_or_escape.target_resolve", int(_last_retarget_profile["resolve_us"]),
			"nav_id=%d garden=%d route_not_ready" % [nav_id_dbg, garden_id])
		return _escape_with_detector(agent, nav_id_dbg, "route_not_ready")
	var entry_cell: Vector2i = route.get("entry_cell", INVALID_CELL) as Vector2i
	if entry_cell == INVALID_CELL:
		_last_retarget_profile["resolve_us"] = Time.get_ticks_usec() - t_res
		_warn_garden_task_lag_us("_retarget_agent_or_escape.target_resolve", int(_last_retarget_profile["resolve_us"]),
			"nav_id=%d garden=%d no_entry" % [nav_id_dbg, garden_id])
		return _escape_with_detector(agent, nav_id_dbg, "no_entry")
	var resolve_us: int = Time.get_ticks_usec() - t_res
	_last_retarget_profile["resolve_us"] = resolve_us
	_warn_garden_task_lag_us("_retarget_agent_or_escape.target_resolve", resolve_us,
		"nav_id=%d garden=%d entry=%s" % [nav_id_dbg, garden_id, str(entry_cell)])

	# Final assignment section: build + push the garden-entry path (the A* leg).
	var t_fin: int = Time.get_ticks_usec()
	var assigned: bool = _assign_agent_to_garden_entry_path(agent, spawner_cell, garden_id, entry_cell)
	var fin_us: int = Time.get_ticks_usec() - t_fin
	_last_retarget_profile["assign_us"] = fin_us
	_warn_garden_task_lag_us("_retarget_agent_or_escape.final_assign", fin_us,
		"nav_id=%d garden=%d entry=%s assigned=%s" % [nav_id_dbg, garden_id, str(entry_cell), str(assigned)])
	if not assigned:
		return _escape_with_detector(agent, nav_id_dbg, "entry_path_failed")
	_last_retarget_profile["reason"] = "garden_entry"
	var nav_id: int = int(agent.get("nav_id"))
	if agent_manager.has_method("set_agent_never_rest"):
		agent_manager.call("set_agent_never_rest", nav_id, true)
	return true

# Escape fallback wrapped with its own sub-detector so a slow _assign_agent_to_escape
# is attributed to .escape (with the branch reason) instead of the parent total. Also
# accumulates the escape time + reason into the parent breakdown profile.
func _escape_with_detector(agent: Node2D, nav_id_dbg: int, reason: String) -> bool:
	var t_esc: int = Time.get_ticks_usec()
	var esc: bool = _assign_agent_to_escape(agent)
	var esc_us: int = Time.get_ticks_usec() - t_esc
	_last_retarget_profile["escape_us"] = esc_us
	_last_retarget_profile["reason"] = "escape:" + reason
	_warn_garden_task_lag_us("_retarget_agent_or_escape.escape", esc_us,
		"nav_id=%d reason=%s assigned=%s" % [nav_id_dbg, reason, str(esc)])
	return esc

# ---------------------------------------------------------------------------
# Budgeted retargeting after a garden topology rebuild.
#
# A rebuild clears _gardens and bumps the epoch, so any agent still holding a
# garden_id from before can be referencing a deleted/empty garden. Re-pathing all
# of them in the rebuild frame risks a large spike, so we split the work:
#   1. _queue_agents_after_garden_rebuild() — one-shot, cheap. Detects affected
#      agents, detaches their stale path/flow, parks them in "waiting_new_status",
#      and queues them. NO pathfinding here.
#   2. _process_garden_retarget_queue() — runs each frame, time-budgeted by
#      garden_retarget_budget_ms (with garden_retarget_budget_per_frame as a hard
#      count cap), doing the expensive re-path/escape.
# ---------------------------------------------------------------------------

# Resolve the agent node for a nav_id without scanning the monsters group.
# AgentManagerNative keeps an id -> node map, so find_node_by_agent is O(1).
func _agent_from_nav_id(nav_id: int) -> Node2D:
	if agent_manager and agent_manager.has_method("find_node_by_agent"):
		var node: Variant = agent_manager.call("find_node_by_agent", nav_id)
		if is_instance_valid(node) and node is Node2D:
			return node as Node2D
	return null

# A garden assignment is stale (needs retargeting) when:
#   - the garden no longer exists in _gardens, or
#   - it exists but has no edible plants (matches the route-validity logic used
#     elsewhere). garden_id <= 0 means "no garden assigned" and is never stale.
func _garden_assignment_is_stale(garden_id: int) -> bool:
	if garden_id <= 0:
		return false
	if not _gardens.has(garden_id):
		return true
	if not _garden_has_edible_plants(garden_id):
		return true
	return false

# Cheapest available view of which garden an agent is currently bound to, checked
# in phase priority order (the dictionaries reflect the agent's live phase, the
# meta is the last-known fallback). Returns 0 when no garden is referenced.
func _agent_referenced_garden_id(nav_id: int, agent: Node2D) -> int:
	if _entry_path_agents.has(nav_id):
		return int((_entry_path_agents[nav_id] as Dictionary).get("garden_id", 0))
	if _astar_in_agents.has(nav_id):
		return int((_astar_in_agents[nav_id] as Dictionary).get("garden_id", 0))
	if _eating_agents.has(nav_id):
		var eat_garden: int = int((_eating_agents[nav_id] as Dictionary).get("garden_id", 0))
		if eat_garden > 0:
			return eat_garden
		# garden_id missing/0 on the eating entry: fall through to the meta below.
	if is_instance_valid(agent) and agent.has_meta("garden_id"):
		return int(agent.get_meta("garden_id"))
	return 0

# Shared enqueue path for ALL budgeted retargeting (full rebuild, empty-garden,
# escape-all). Cheaply detaches the agent's stale path/flow, forgets its current
# phase, parks it in "waiting_new_status", and appends one queue item. NO new
# path/flow is computed here — that is deferred to _process_garden_retarget_queue.
# Dedups on _garden_retarget_queued so an agent is never enqueued twice. Keeping
# this in one place guarantees identical queue behaviour across every caller.
# Returns true if the agent was newly enqueued this call, false if it was already
# queued or could not be queued (invalid nav_id/agent). Callers use this to keep
# accurate queued-vs-already-queued bookkeeping.
func _queue_agent_for_garden_retarget(nav_id: int, agent: Node2D, intent: String, spawner_cell: Vector2i, garden_id: int) -> bool:
	if nav_id < 0 or not is_instance_valid(agent):
		return false
	if _garden_retarget_queued.has(nav_id):
		return false
	# Cheaply detach stale path/flow so the agent stops following an invalid route
	# immediately. The real re-route happens later in the budgeted queue.
	if agent_manager and agent_manager.has_method("detach_agent_path"):
		agent_manager.call("detach_agent_path", nav_id)
	if agent_manager and agent_manager.has_method("detach_agent_flow"):
		agent_manager.call("detach_agent_flow", nav_id)
	_entry_path_agents.erase(nav_id)
	_erase_astar_in_agent(nav_id)
	_escaping_agents.erase(nav_id)
	if _eating_agents.has(nav_id):
		_erase_eating_agent(nav_id)
		if agent.has_method("stop_eating"):
			agent.call("stop_eating")
	if agent.has_method("start_waiting_new_status"):
		agent.call("start_waiting_new_status")
	_garden_retarget_queue.append({
		"nav_id": nav_id,
		"intent": intent,
		"spawner_cell": spawner_cell,
		"garden_id": garden_id
	})
	_garden_retarget_queued[nav_id] = true
	return true

# One-shot scan after a FULL garden rebuild. Cheap checks only: detect agents whose
# garden reference is now stale, enqueue each via the shared helper. The expensive
# re-path/escape is deferred to the budgeted queue. Iterates a snapshot of the
# monsters group so the helper's per-agent erases never mutate a live iteration.
func _queue_agents_after_garden_rebuild() -> void:
	for node in get_tree().get_nodes_in_group("monsters"):
		if not (node is Node2D):
			continue
		var agent: Node2D = node
		var nav_id: int = int(agent.get("nav_id"))
		if nav_id < 0:
			continue
		if _garden_retarget_queued.has(nav_id):
			continue
		var garden_id: int = _agent_referenced_garden_id(nav_id, agent)
		if not _garden_assignment_is_stale(garden_id):
			continue
		# Decide intent BEFORE the helper clears the agent's phase dictionaries:
		# agents that were eating should head for the exit, everyone else retargets.
		var intent: String = "retarget"
		if _eating_agents.has(nav_id):
			intent = "escape"
		var spawner_cell: Vector2i = INVALID_CELL
		if agent.has_meta("spawner_cell"):
			spawner_cell = agent.get_meta("spawner_cell") as Vector2i
		_queue_agent_for_garden_retarget(nav_id, agent, intent, spawner_cell, garden_id)
	# _garden_has_edible_plants (via _garden_assignment_is_stale) may have queued
	# stale-empty gardens; this loop iterates monsters, not _gardens, so draining
	# here is safe.
	_drain_pending_empty_gardens()

# Content-only removal emptied a garden. Queue every agent bound to it through the
# existing budgeted queue, then release the garden's routes and erase it. We must
# queue the agents FIRST (or at least before _erase_garden runs), because the
# queue helper reads the agent's phase, and because the affected-agent scan relies
# on the live phase dictionaries that still carry this garden_id. No new path/flow
# is computed here — that is the budgeted queue's job. We do NOT rebuild gardens
# and do NOT recompute entry cells.
func _handle_garden_became_empty(garden_id: int) -> void:
	if garden_id <= 0:
		return
	# Intent per phase: agents heading in (entry/astar_in) look for another garden
	# (retarget); agents already inside leaving/eating head for the exit (escape).
	for raw_nav_id in _entry_path_agents.keys():
		var nav_id: int = int(raw_nav_id)
		if not _entry_path_agents.has(nav_id):
			continue
		if int((_entry_path_agents[nav_id] as Dictionary).get("garden_id", 0)) != garden_id:
			continue
		_queue_affected_empty_garden_agent(nav_id, "retarget", garden_id)
	for raw_nav_id in _astar_in_agents.keys():
		var nav_id: int = int(raw_nav_id)
		if not _astar_in_agents.has(nav_id):
			continue
		if int((_astar_in_agents[nav_id] as Dictionary).get("garden_id", 0)) != garden_id:
			continue
		_queue_affected_empty_garden_agent(nav_id, "retarget", garden_id)
	for raw_nav_id in _eating_agents.keys():
		var nav_id: int = int(raw_nav_id)
		if not _eating_agents.has(nav_id):
			continue
		if int((_eating_agents[nav_id] as Dictionary).get("garden_id", 0)) != garden_id:
			continue
		_queue_affected_empty_garden_agent(nav_id, "escape", garden_id)
	# Meta-only fallback: agents that lost their phase entry but still carry this
	# garden in meta (e.g. mid-transition). Scan the monsters group once.
	for node in get_tree().get_nodes_in_group("monsters"):
		if not (node is Node2D):
			continue
		var agent: Node2D = node
		var nav_id: int = int(agent.get("nav_id"))
		if nav_id < 0 or _garden_retarget_queued.has(nav_id):
			continue
		if not agent.has_meta("garden_id"):
			continue
		if int(agent.get_meta("garden_id")) != garden_id:
			continue
		var spawner_cell: Vector2i = INVALID_CELL
		if agent.has_meta("spawner_cell"):
			spawner_cell = agent.get_meta("spawner_cell") as Vector2i
		_queue_agent_for_garden_retarget(nav_id, agent, "retarget", spawner_cell, garden_id)
	# Now that affected agents are parked/queued, release routes and erase the
	# garden. _mark_garden_empty clears plant_cells, releases routes, and erases.
	_mark_garden_empty(garden_id)

# Helper for _handle_garden_became_empty: resolve the agent node + spawner_cell
# for a queued nav_id and hand it to the shared queue helper. Reads spawner_cell
# from the phase entry if present, else from meta.
func _queue_affected_empty_garden_agent(nav_id: int, intent: String, garden_id: int) -> void:
	if _garden_retarget_queued.has(nav_id):
		return
	var agent: Node2D = _agent_from_nav_id(nav_id)
	if not is_instance_valid(agent):
		# Agent is gone; still drop its stale phase entries so nothing dangles.
		_entry_path_agents.erase(nav_id)
		_erase_astar_in_agent(nav_id)
		_erase_eating_agent(nav_id)
		return
	var spawner_cell: Vector2i = INVALID_CELL
	if _entry_path_agents.has(nav_id):
		spawner_cell = (_entry_path_agents[nav_id] as Dictionary).get("spawner_cell", INVALID_CELL) as Vector2i
	elif _astar_in_agents.has(nav_id):
		spawner_cell = (_astar_in_agents[nav_id] as Dictionary).get("spawner_cell", INVALID_CELL) as Vector2i
	elif _eating_agents.has(nav_id):
		spawner_cell = (_eating_agents[nav_id] as Dictionary).get("spawner_cell", INVALID_CELL) as Vector2i
	if spawner_cell == INVALID_CELL and agent.has_meta("spawner_cell"):
		spawner_cell = agent.get_meta("spawner_cell") as Vector2i
	_queue_agent_for_garden_retarget(nav_id, agent, intent, spawner_cell, garden_id)

# Budgeted "everyone escape" for the no-plants-left case. One scan of the monsters
# group enqueues each valid agent (intent="escape") through the shared queue, so
# the actual escape assignment is spread across frames by the budgeted queue
# instead of being applied synchronously in a single frame.
func _queue_escape_for_all_monsters_budgeted() -> void:
	for node in get_tree().get_nodes_in_group("monsters"):
		if not (node is Node2D):
			continue
		var agent: Node2D = node
		var nav_id: int = int(agent.get("nav_id"))
		if nav_id < 0 or _garden_retarget_queued.has(nav_id):
			continue
		# Already escaping (and not eating): leave it alone, it has a valid exit route.
		if _escaping_agents.has(nav_id) and not _eating_agents.has(nav_id):
			continue
		var spawner_cell: Vector2i = INVALID_CELL
		if agent.has_meta("spawner_cell"):
			spawner_cell = agent.get_meta("spawner_cell") as Vector2i
		var garden_id: int = 0
		if agent.has_meta("garden_id"):
			garden_id = int(agent.get_meta("garden_id"))
		_queue_agent_for_garden_retarget(nav_id, agent, "escape", spawner_cell, garden_id)

# Time-budgeted: spend at most garden_retarget_budget_ms per frame on the expensive
# A*/escape work (in _retarget_single_waiting_agent), falling back on the count cap
# garden_retarget_budget_per_frame as a hard upper bound. Because a single retarget
# can exceed the whole time budget by itself, we always do at least one *expensive*
# retarget per frame (so the queue keeps draining) and then stop once the elapsed
# time crosses the budget. Cheap skips (invalid/freed/stale agents) do NOT count
# against either budget so they can't stall the queue. Returns the number of agents
# actually retargeted (expensive work done) for debug context.
func _process_garden_retarget_queue() -> int:
	if _garden_retarget_queue.is_empty():
		return 0
	var start_us: int = Time.get_ticks_usec()
	var budget_us: int = int(garden_retarget_budget_ms * 1000.0)
	var count_cap: int = garden_retarget_budget_per_frame
	var processed: int = 0
	while not _garden_retarget_queue.is_empty():
		# Hard upper bound on expensive retargets per frame.
		if processed >= count_cap:
			break
		# Time budget is the primary limiter: once we've done at least one expensive
		# retarget and spent the budget, stop. When budget_us <= 0 this collapses to
		# "one expensive retarget per frame" — the safest non-spiking fallback.
		if processed > 0:
			if budget_us <= 0:
				break
			if Time.get_ticks_usec() - start_us >= budget_us:
				break
		var item: Dictionary = _garden_retarget_queue.pop_front() as Dictionary
		var nav_id: int = int(item.get("nav_id", -1))
		_garden_retarget_queued.erase(nav_id)
		if nav_id < 0:
			continue
		var agent: Node2D = _agent_from_nav_id(nav_id)
		if not is_instance_valid(agent):
			# Agent was freed before we got to it: nothing to do.
			continue
		# If the agent already received a newer valid state (e.g. another path was
		# re-issued by other logic), it is no longer waiting — don't override it.
		if str(agent.get("status")) != "waiting_new_status":
			continue
		_retarget_single_waiting_agent(nav_id, agent, item)
		processed += 1
	return processed

# Re-assign one parked agent. intent "escape" routes it to a map exit; intent
# "retarget" finds a new valid garden if one exists, otherwise escapes.
#
# CRITICAL: "waiting_new_status" is only cleared AFTER the assignment actually
# succeeds. The assignment functions return bool now, so on failure we keep the
# agent waiting and requeue it (bounded retries) instead of stranding it with no
# nav state. This fixes the old bug where stop_waiting_new_status() ran first and
# a silently-failing assignment left the agent in a dead empty status.
func _retarget_single_waiting_agent(nav_id: int, agent: Node2D, item: Dictionary) -> void:
	if not is_instance_valid(agent):
		return
	var single_us: int = Time.get_ticks_usec()
	var intent: String = str(item.get("intent", "retarget"))
	var spawner_cell: Vector2i = item.get("spawner_cell", INVALID_CELL) as Vector2i

	var assigned: bool = false
	if intent == "escape":
		assigned = _assign_agent_to_escape(agent)
	else:
		assigned = _retarget_agent_or_escape(agent, spawner_cell)
	_warn_garden_task_lag_us("_retarget_single_waiting_agent", Time.get_ticks_usec() - single_us,
		"nav_id=%d intent=%s assigned=%s" % [nav_id, intent, str(assigned)])

	if assigned:
		if agent.has_method("stop_waiting_new_status"):
			agent.call("stop_waiting_new_status")
		return
	# Assignment failed (no escape route / garden route ready yet). Keep the agent
	# parked in waiting_new_status and requeue it for a later frame.
	_requeue_waiting_agent(item)

# Max times a single agent is retried through the budgeted queue before we give
# up. Prevents an unroutable agent (e.g. no escape ready at all) from being
# requeued forever every frame. After the cap we clear waiting so it falls back to
# the normal idle/arrival logic rather than spinning.
const _GARDEN_RETARGET_MAX_RETRIES: int = 30

func _requeue_waiting_agent(item: Dictionary) -> void:
	var nav_id: int = int(item.get("nav_id", -1))
	if nav_id < 0:
		return
	var retries: int = int(item.get("retries", 0)) + 1
	if retries > _GARDEN_RETARGET_MAX_RETRIES:
		# Give up requeuing; let the agent leave waiting so other systems can act on
		# it. It keeps whatever (empty) status it has; arrival/idle logic recovers it.
		var agent: Node2D = _agent_from_nav_id(nav_id)
		if is_instance_valid(agent) and agent.has_method("stop_waiting_new_status"):
			agent.call("stop_waiting_new_status")
		return
	if _garden_retarget_queued.has(nav_id):
		return
	item["retries"] = retries
	_garden_retarget_queue.append(item)
	_garden_retarget_queued[nav_id] = true

func get_plant_zone_tiles() -> Array:
	return _plant_zone_tiles.keys()

func get_plant_zone_margin_tiles() -> Array:
	return _plant_zone_margin_tiles.keys()

func get_plant_zone_route_tiles() -> Array:
	var route_tiles: Dictionary = {}
	for raw_garden in _gardens.values():
		var garden: Dictionary = raw_garden as Dictionary
		var entry_cells: Array = garden.get("entry_cells", []) as Array
		for raw_entry_cell in entry_cells:
			var entry_cell: Vector2i = raw_entry_cell
			route_tiles[entry_cell] = true
	return route_tiles.keys()

func get_garden_entry_cells() -> Array:
	return get_plant_zone_route_tiles()

func set_show_enters_exits(value: bool) -> void:
	_show_enters_exits = value
	if _zone_overlay:
		_zone_overlay.queue_redraw()

func get_show_enters_exits() -> bool:
	return _show_enters_exits

func set_verbose(value: bool) -> void:
	_verbose = value
	_verbose_pushed = true

# True when verbose garden logging is on. Once CppDebugOptions has pushed a value
# via set_verbose() we trust that (it is already gated by debug_enabled there);
# before that push (e.g. the startup recompute, which can run before
# CppDebugOptions._ready()) we pull the value straight from the CPP node AND its
# debug_enabled flag, so the master debug gate holds even for the first recompute.
func _is_verbose() -> bool:
	if _verbose_pushed:
		return _verbose
	if _cpp_debug_options == null and is_inside_tree():
		var scene: Node = get_tree().get_current_scene()
		if scene:
			_cpp_debug_options = scene.get_node_or_null("CPP")
	if _cpp_debug_options and "verbose" in _cpp_debug_options and "debug_enabled" in _cpp_debug_options:
		return bool(_cpp_debug_options.get("verbose")) and bool(_cpp_debug_options.get("debug_enabled"))
	return _verbose

# Garden border tiles a monster crosses to ENTER: per spawner, the garden
# entry cell nearest that spawner. Aggregated across all spawners/gardens.
func get_garden_enter_tiles() -> Array:
	var tiles: Dictionary = {}
	for raw_spawner_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_spawner_cell
		for raw_garden_id in _gardens.keys():
			var garden_id: int = int(raw_garden_id)
			var enter_cell: Vector2i = _nearest_garden_entry(garden_id, spawner_cell)
			if enter_cell != INVALID_CELL:
				tiles[enter_cell] = true
	return tiles.keys()

# Garden border tiles a monster crosses to EXIT: per spawner, the garden
# entry cell nearest that spawner's exit-wall. Aggregated across all spawners.
func get_garden_exit_tiles() -> Array:
	var tiles: Dictionary = {}
	for raw_spawner_cell in _spawners.keys():
		var spawner_cell: Vector2i = raw_spawner_cell
		for raw_garden_id in _gardens.keys():
			var garden_id: int = int(raw_garden_id)
			var exit_cell: Vector2i = _nearest_garden_entry_to_exit(garden_id, spawner_cell)
			if exit_cell != INVALID_CELL:
				tiles[exit_cell] = true
	return tiles.keys()

func get_unreachable_garden_cells() -> Array:
	var cells: Dictionary = {}
	for raw_garden in _gardens.values():
		var garden: Dictionary = raw_garden as Dictionary
		if bool(garden.get("reachable", false)):
			continue
		var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
		var zone_tiles: Dictionary = garden.get("zone_tiles", {}) as Dictionary
		for raw_cell in zone_tiles.keys():
			var zone_cell: Vector2i = raw_cell
			cells[zone_cell] = true
		for raw_cell in plant_cells.keys():
			var plant_cell: Vector2i = raw_cell
			cells[plant_cell] = true
	return cells.keys()

func get_dirty_garden_cells() -> Array:
	var cells: Dictionary = {}
	for raw_garden in _gardens.values():
		var garden: Dictionary = raw_garden as Dictionary
		if not bool(garden.get("dirty", false)):
			continue
		var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
		var zone_tiles: Dictionary = garden.get("zone_tiles", {}) as Dictionary
		for raw_cell in zone_tiles.keys():
			var zone_cell: Vector2i = raw_cell
			cells[zone_cell] = true
		for raw_cell in plant_cells.keys():
			var plant_cell: Vector2i = raw_cell
			cells[plant_cell] = true
	return cells.keys()

func get_debug_monster_path(nav_id: int) -> PackedVector2Array:
	if _entry_path_agents.has(nav_id):
		var entry_data: Dictionary = _entry_path_agents[nav_id] as Dictionary
		return entry_data.get("path_world", PackedVector2Array()) as PackedVector2Array
	if _astar_in_agents.has(nav_id):
		var astar_in_data: Dictionary = _astar_in_agents[nav_id] as Dictionary
		return astar_in_data.get("path_world", PackedVector2Array()) as PackedVector2Array
	if _escaping_agents.has(nav_id):
		var escape_data: Dictionary = _escaping_agents[nav_id] as Dictionary
		var escape_target: Vector2i = escape_data.get("target_cell", INVALID_CELL) as Vector2i
		return _debug_path_to_cell(escape_target)
	for node in get_tree().get_nodes_in_group("monsters"):
		if not (node is Node2D):
			continue
		var agent: Node2D = node
		if int(agent.get("nav_id")) != nav_id:
			continue
		if agent.has_meta("garden_entry_cell"):
			var entry_cell: Vector2i = agent.get_meta("garden_entry_cell") as Vector2i
			return _debug_path_to_cell(entry_cell)
		break
	return PackedVector2Array()

func _debug_path_to_cell(cell: Vector2i) -> PackedVector2Array:
	var path: PackedVector2Array = PackedVector2Array()
	if cell == INVALID_CELL:
		return path
	path.append(_cell_center(cell))
	return path

func get_floorz() -> TileMapLayer:
	return floorz

func _wall_blockers_for_zone_bounds() -> PackedVector2Array:
	return _wall_blockers_for_cells(_plant_zone_tiles)

func _wall_blockers_for_cells(cells: Dictionary) -> PackedVector2Array:
	var blockers: PackedVector2Array = PackedVector2Array()
	if not wallz or cells.is_empty():
		return blockers
	var min_cell: Vector2i = INVALID_CELL
	var max_cell: Vector2i = Vector2i(-2147483648, -2147483648)
	for raw_cell in cells.keys():
		var c: Vector2i = raw_cell
		if min_cell == INVALID_CELL:
			min_cell = c
			max_cell = c
		else:
			min_cell.x = mini(min_cell.x, c.x)
			min_cell.y = mini(min_cell.y, c.y)
			max_cell.x = maxi(max_cell.x, c.x)
			max_cell.y = maxi(max_cell.y, c.y)

	for raw_cell in wallz.get_used_cells():
		var c: Vector2i = raw_cell
		if c.x < min_cell.x or c.x > max_cell.x or c.y < min_cell.y or c.y > max_cell.y:
			continue
		blockers.append(Vector2(float(c.x), float(c.y)))
	return blockers

# ---------------------------------------------------------------------------
# Exit-wall & adjacency helpers.
# ---------------------------------------------------------------------------
func _nearest_exit_wall_for_spawner(spawner_cell: Vector2i) -> Vector2i:
	if not wallz:
		return INVALID_CELL
	var best_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for raw_cell in wallz.get_used_cells():
		var c: Vector2i = raw_cell
		if wallz.get_cell_atlas_coords(c) != EXIT_WALL_ATLAS:
			continue
		var d: Vector2i = c - spawner_cell
		var manhattan: int = abs(d.x) + abs(d.y)
		if manhattan < best_dist:
			best_dist = manhattan
			best_cell = c
	return best_cell

func _nearest_walkable_adjacent(cell: Vector2i) -> Vector2i:
	var best_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			if dx == 0 and dy == 0:
				continue
			var n: Vector2i = cell + Vector2i(dx, dy)
			if not _is_walkable(n):
				continue
			var manhattan: int = abs(dx) + abs(dy)
			if manhattan < best_dist:
				best_dist = manhattan
				best_cell = n
	return best_cell

func _nearest_margin_tile(from_cell: Vector2i) -> Vector2i:
	var best_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for raw_cell in _plant_zone_margin_tiles.keys():
		var c: Vector2i = raw_cell
		var d: Vector2i = c - from_cell
		var manhattan: int = abs(d.x) + abs(d.y)
		if manhattan < best_dist:
			best_dist = manhattan
			best_cell = c
	return best_cell

# ---------------------------------------------------------------------------
# A* glue: find paths via PathfinderNative.
# ---------------------------------------------------------------------------
func _find_path_on_walkable_map(from_tile: Vector2i, to_tile: Vector2i) -> PackedVector2Array:
	if pathfinder == null or not pathfinder.has_method("find_path"):
		return PackedVector2Array()
	if _walkable_map_tiles.is_empty():
		_rebuild_walkable_map_cache()
	if _walkable_map_tiles.is_empty():
		return PackedVector2Array()
	var path_tiles: Dictionary = _walkable_map_tiles
	var path_tiles_copied: bool = false
	if _is_walkable(from_tile) and not path_tiles.has(from_tile):
		path_tiles = _walkable_map_tiles.duplicate()
		path_tiles_copied = true
		path_tiles[from_tile] = true
	if _is_walkable(to_tile) and not path_tiles.has(to_tile):
		if not path_tiles_copied:
			path_tiles = _walkable_map_tiles.duplicate()
			path_tiles_copied = true
		path_tiles[to_tile] = true
	_sync_pathfinder_zone_tiles(path_tiles)
	var start_tile: Vector2i = from_tile if path_tiles.has(from_tile) else _nearest_zone_tile_to(from_tile, path_tiles)
	var end_tile: Vector2i = to_tile if path_tiles.has(to_tile) else _nearest_zone_tile_to(to_tile, path_tiles)
	if start_tile == INVALID_CELL or end_tile == INVALID_CELL:
		return PackedVector2Array()
	return pathfinder.call("find_path", start_tile, end_tile) as PackedVector2Array

func _find_path_in_zone(from_tile: Vector2i, to_tile: Vector2i, garden_id: int = 0) -> PackedVector2Array:
	if pathfinder == null or not pathfinder.has_method("find_path"):
		return PackedVector2Array()
	var zone_tiles: Dictionary = _plant_zone_tiles
	if garden_id > 0 and _gardens.has(garden_id):
		var garden: Dictionary = _gardens[garden_id] as Dictionary
		zone_tiles = garden.get("zone_tiles", {}) as Dictionary
	if zone_tiles.is_empty():
		return PackedVector2Array()
	# An agent arriving via the flow field can settle one tile *outside* the
	# interior (FF overshoot at the entry), so its actual cell may not be in
	# zone_tiles. Add any walkable endpoint to the A* walkable set so the path
	# starts/ends where the agent really stands instead of snapping a tile short.
	# Use a local copy so the cached garden zone_tiles is not mutated.
	# .prep: endpoint handling + zone duplicate cost (the duplicate can be the cost
	# when a garden's zone_tiles dictionary is large and both endpoints are outside).
	# Sub-warnings are gated on _over_garden_threshold_us so the context string is
	# built only on a real spike — _find_path_in_zone is called in tight retarget
	# loops, so unconditional formatting here would be the wrong kind of overhead.
	var call_start_us: int = Time.get_ticks_usec()
	var prep_us: int = Time.get_ticks_usec()
	var path_tiles: Dictionary = zone_tiles
	if _is_walkable(from_tile) and not zone_tiles.has(from_tile):
		path_tiles = zone_tiles.duplicate()
		path_tiles[from_tile] = true
	if _is_walkable(to_tile) and not path_tiles.has(to_tile):
		if path_tiles == zone_tiles:
			path_tiles = zone_tiles.duplicate()
		path_tiles[to_tile] = true
	if _over_garden_threshold_us(Time.get_ticks_usec() - prep_us):
		_warn_garden_task_lag_us("_find_path_in_zone.prep", Time.get_ticks_usec() - prep_us,
			"garden=%d zone_tiles=%d from=%s to=%s" % [garden_id, zone_tiles.size(), str(from_tile), str(to_tile)])
	# .sync_zone: pushes the walkable set + wall blockers into the pathfinder.
	var sync_us: int = Time.get_ticks_usec()
	_sync_pathfinder_zone_tiles(path_tiles)
	var sync_elapsed: int = Time.get_ticks_usec() - sync_us
	if _over_garden_threshold_us(sync_elapsed):
		_warn_garden_task_lag_us("_find_path_in_zone.sync_zone", sync_elapsed,
			"garden=%d zone_tiles=%d from=%s to=%s" % [garden_id, path_tiles.size(), str(from_tile), str(to_tile)])
	# Snap endpoints to walkable tiles if needed (non-walkable endpoints only).
	var start_tile: Vector2i = from_tile if path_tiles.has(from_tile) else _nearest_zone_tile_to(from_tile, path_tiles)
	var end_tile: Vector2i = to_tile if path_tiles.has(to_tile) else _nearest_zone_tile_to(to_tile, path_tiles)
	if start_tile == INVALID_CELL or end_tile == INVALID_CELL:
		_accumulate_find_path_in_zone(call_start_us, sync_elapsed, 0, from_tile, to_tile, path_tiles.size())
		return PackedVector2Array()
	# .find_path: the pathfinder A* itself.
	var find_us: int = Time.get_ticks_usec()
	var result: PackedVector2Array = pathfinder.call("find_path", start_tile, end_tile) as PackedVector2Array
	var find_elapsed: int = Time.get_ticks_usec() - find_us
	if _over_garden_threshold_us(find_elapsed):
		_warn_garden_task_lag_us("_find_path_in_zone.find_path", find_elapsed,
			"garden=%d from=%s to=%s len=%d" % [garden_id, str(start_tile), str(end_tile), result.size()])
	_accumulate_find_path_in_zone(call_start_us, sync_elapsed, find_elapsed, from_tile, to_tile, path_tiles.size())
	return result

# Fold one _find_path_in_zone call's timings into the per-retarget accumulator (reset
# at the start of the local plant search). Tracks totals + the single most expensive
# call so the parent breakdown can show whether the path cost is spread across many
# calls or dominated by one. Cheap; no per-call warning here.
func _accumulate_find_path_in_zone(call_start_us: int, sync_elapsed: int, find_elapsed: int, from_tile: Vector2i, to_tile: Vector2i, zone_tiles: int) -> void:
	var call_us: int = Time.get_ticks_usec() - call_start_us
	var a: Dictionary = _find_path_in_zone_accum
	a["call_count"] = int(a.get("call_count", 0)) + 1
	a["total_us"] = int(a.get("total_us", 0)) + call_us
	a["sync_zone_total_us"] = int(a.get("sync_zone_total_us", 0)) + sync_elapsed
	a["blocker_total_us"] = int(a.get("blocker_total_us", 0)) + _last_zone_blocker_us
	a["find_path_total_us"] = int(a.get("find_path_total_us", 0)) + find_elapsed
	if call_us > int(a.get("max_single_call_us", 0)):
		a["max_single_call_us"] = call_us
		a["max_single_call_from"] = from_tile
		a["max_single_call_to"] = to_tile
	if zone_tiles > int(a.get("max_zone_tiles", 0)):
		a["max_zone_tiles"] = zone_tiles

func _sync_pathfinder_zone_tiles(zone_tiles: Dictionary) -> void:
	_last_zone_blocker_us = 0
	if pathfinder == null:
		return
	var zone_arr: PackedVector2Array = PackedVector2Array()
	zone_arr.resize(zone_tiles.size())
	var i: int = 0
	for raw_cell in zone_tiles.keys():
		var cell: Vector2i = raw_cell
		zone_arr[i] = Vector2(float(cell.x), float(cell.y))
		i += 1
	if pathfinder.has_method("set_walkable_tiles"):
		pathfinder.call("set_walkable_tiles", zone_arr)
	if pathfinder.has_method("set_blockers"):
		# _wall_blockers_for_cells scans every wall tile against the zone bbox; time it
		# separately since it can dominate sync on a large wall layer. Gated so context
		# is built only on a spike (this runs once per path query). The time is also
		# stashed in _last_zone_blocker_us so the caller can split it out of sync time.
		var blockers_us: int = Time.get_ticks_usec()
		var blockers: PackedVector2Array = _wall_blockers_for_cells(zone_tiles)
		var blocker_elapsed: int = Time.get_ticks_usec() - blockers_us
		_last_zone_blocker_us = blocker_elapsed
		if _over_garden_threshold_us(blocker_elapsed):
			_warn_garden_task_lag_us("_wall_blockers_for_cells", blocker_elapsed,
				"zone_tiles=%d blockers=%d" % [zone_tiles.size(), blockers.size()])
		pathfinder.call("set_blockers", blockers)

func _nearest_zone_tile_to(cell: Vector2i, zone_tiles: Dictionary) -> Vector2i:
	var best_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for raw_cell in zone_tiles.keys():
		var c: Vector2i = raw_cell
		var d: Vector2i = c - cell
		var manhattan: int = abs(d.x) + abs(d.y)
		if manhattan < best_dist:
			best_dist = manhattan
			best_cell = c
	return best_cell

func _path_cells_to_world(path_cells: PackedVector2Array) -> PackedVector2Array:
	var out: PackedVector2Array = PackedVector2Array()
	out.resize(path_cells.size())
	for i in range(path_cells.size()):
		var v: Vector2 = path_cells[i]
		out[i] = _cell_center(Vector2i(int(v.x), int(v.y)))
	return out

func _resolve_plant_target_for_agent_in_garden(from_cell: Vector2i, garden_id: int) -> Vector2i:
	if not _gardens.has(garden_id):
		return INVALID_CELL
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
	var zone_tiles: Dictionary = garden.get("zone_tiles", {}) as Dictionary
	var best_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for raw_cell in plant_cells.keys():
		var c: Vector2i = raw_cell
		if not zone_tiles.has(c):
			continue
		if plant_manager and plant_manager.has_method("has_plant") and not bool(plant_manager.call("has_plant", c)):
			continue
		var d: Vector2i = c - from_cell
		var manhattan: int = abs(d.x) + abs(d.y)
		if manhattan < best_dist:
			best_dist = manhattan
			best_cell = c
	return best_cell

# Truth is plant_cells (cross-checked against the plant_manager), never the cached
# edible_count: that counter drifts on incremental removal and was flagging
# non-empty gardens as empty. This predicate may be called while iterating
# _gardens, so it only queues stale-empty gardens; callers drain after scans.
func _garden_has_edible_plants(garden_id: int) -> bool:
	if not _gardens.has(garden_id):
		return false
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
	if plant_cells.is_empty():
		_pending_empty_gardens[garden_id] = true
		return false
	if plant_manager == null or not plant_manager.has_method("has_plant"):
		return true
	for raw_cell in plant_cells.keys():
		var cell: Vector2i = raw_cell
		if bool(plant_manager.call("has_plant", cell)):
			return true
	# plant_cells is non-empty but the plant_manager confirms none survive: stale
	# cache, genuinely empty. Queue for removal outside any garden iteration.
	_pending_empty_gardens[garden_id] = true
	return false

# Drain gardens flagged empty by _garden_has_edible_plants. Plant removal still
# removes its own empty garden immediately; this catches stale caches found by
# route/retarget scans without mutating _gardens mid-iteration.
func _drain_pending_empty_gardens() -> void:
	if _pending_empty_gardens.is_empty():
		return
	if _gardens_iter_depth > 0:
		push_warning("GARDEN-CRASH-GUARD: drain requested mid-iteration; deferring %d" % _pending_empty_gardens.size())
		return
	var ids: Array = _pending_empty_gardens.keys()
	_pending_empty_gardens.clear()
	for raw_id in ids:
		_mark_garden_empty(int(raw_id))

func _mark_garden_empty(garden_id: int) -> void:
	if not _gardens.has(garden_id):
		return
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var plant_cells: Dictionary = garden.get("plant_cells", {}) as Dictionary
	for raw_cell in plant_cells.keys():
		var cell: Vector2i = raw_cell
		_garden_by_plant_cell.erase(cell)
	garden["plant_cells"] = {}
	garden["edible_count"] = 0
	garden["targetable"] = false
	_gardens[garden_id] = garden
	_pending_empty_gardens.erase(garden_id)
	_release_garden_routes(garden_id)
	_erase_garden(garden_id, "mark_empty")

func _manhattan_cell(a: Vector2i, b: Vector2i) -> int:
	var delta: Vector2i = a - b
	return abs(delta.x) + abs(delta.y)

# Walkable cells *outside* the garden that a monster could actually step to from
# this interior access cell. "Outside" = not in zone_tiles. Uses the same
# walkability + diagonal no-corner-cut rules as _recompute_garden_geometry(), so
# the neighbors returned mirror the transitions that made access_cell an access
# cell in the first place.
func _garden_access_outside_neighbors(garden: Dictionary, access_cell: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var zone_tiles: Dictionary = garden.get("zone_tiles", {}) as Dictionary
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			if dx == 0 and dy == 0:
				continue
			var neighbor: Vector2i = access_cell + Vector2i(dx, dy)
			if not _is_walkable(neighbor):
				continue
			if zone_tiles.has(neighbor):
				continue
			if dx != 0 and dy != 0:
				if not _is_walkable(access_cell + Vector2i(dx, 0)) or not _is_walkable(access_cell + Vector2i(0, dy)):
					continue
			out.append(neighbor)
	return out

# Walkable neighbors of a cell using the same no-corner-cut rule. Pure local
# geometry (no zone awareness): used to gauge whether an outside tile is cramped
# or dead-ended for continuation scoring.
func _valid_walkable_neighbors_no_corner_cut(cell: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			if dx == 0 and dy == 0:
				continue
			var neighbor: Vector2i = cell + Vector2i(dx, dy)
			if not _is_walkable(neighbor):
				continue
			if dx != 0 and dy != 0:
				if not _is_walkable(cell + Vector2i(dx, 0)) or not _is_walkable(cell + Vector2i(0, dy)):
					continue
			out.append(neighbor)
	return out

# Route cost for a group at a cell center, or INF when flow / the group is not
# available. Wraps the optional flow.group_route_cost_at_world cache so callers
# can compare inside vs outside cost along the real escape flow.
func _group_route_cost_at_cell(escape_group: int, cell: Vector2i) -> float:
	if escape_group <= IDLE_GROUP:
		return INF
	if not flow or not flow.has_method("group_route_cost_at_world"):
		return INF
	return float(flow.call("group_route_cost_at_world", escape_group, _cell_center(cell)))

# Low-cost score for a garden access (entry/exit) cell. Lower is better. The base
# is Manhattan distance to target_cell so behavior stays close to the old
# nearest-entry selection; penalties are purely additive and only discourage
# obviously bad local geometry. Wall proximity alone is never enough to reject a
# cell — it only adds a small cramped penalty, which doors naturally incur.
func _score_garden_access_cell(
	garden_id: int,
	access_cell: Vector2i,
	target_cell: Vector2i,
	mode: String,
	forbidden_cell: Vector2i = INVALID_CELL,
	escape_group: int = -1
) -> float:
	if not _gardens.has(garden_id):
		return INF
	if access_cell == forbidden_cell:
		return INF
	if not _is_walkable(access_cell):
		return INF
	var garden: Dictionary = _gardens[garden_id] as Dictionary

	var score: float = float(_manhattan_cell(access_cell, target_cell))

	var outside_neighbors: Array[Vector2i] = _garden_access_outside_neighbors(garden, access_cell)
	if outside_neighbors.is_empty():
		# Degenerate: an access cell with no reachable outside step. Penalize
		# heavily but never crash — the cell may still be the only option.
		return score + ACCESS_NO_OUTSIDE_PENALTY

	# Pick the outside neighbor that best follows the target / escape flow.
	var use_flow: bool = escape_group > IDLE_GROUP and flow and flow.has_method("group_route_cost_at_world")
	var outside_neighbor: Vector2i = outside_neighbors[0]
	var best_outside_metric: float = INF
	for candidate in outside_neighbors:
		var metric: float
		if use_flow:
			metric = _group_route_cost_at_cell(escape_group, candidate)
			if not is_finite(metric):
				metric = float(_manhattan_cell(candidate, target_cell))
		else:
			metric = float(_manhattan_cell(candidate, target_cell))
		if metric < best_outside_metric:
			best_outside_metric = metric
			outside_neighbor = candidate

	if mode == "exit":
		# Stepping outside should not lose progress toward the target. Prefer the
		# real escape flow when available, fall back to Manhattan otherwise.
		var compared: bool = false
		if use_flow:
			var inside_cost: float = _group_route_cost_at_cell(escape_group, access_cell)
			var outside_cost: float = _group_route_cost_at_cell(escape_group, outside_neighbor)
			if is_finite(inside_cost) and is_finite(outside_cost):
				compared = true
				if outside_cost > inside_cost:
					score += ACCESS_EXIT_WORSE_PENALTY
				elif outside_cost == inside_cost:
					score += ACCESS_EXIT_FLAT_PENALTY
		if not compared:
			var inside_dist: int = _manhattan_cell(access_cell, target_cell)
			var outside_dist: int = _manhattan_cell(outside_neighbor, target_cell)
			if outside_dist > inside_dist:
				score += ACCESS_EXIT_WORSE_PENALTY
			elif outside_dist == inside_dist:
				score += ACCESS_EXIT_FLAT_PENALTY

		# Continuation: how many ways out of the outside tile, excluding stepping
		# straight back inside. A dead end forces an immediate reversal.
		var continuations: Array[Vector2i] = []
		for cont in _valid_walkable_neighbors_no_corner_cut(outside_neighbor):
			if cont == access_cell:
				continue
			continuations.append(cont)
		if continuations.is_empty():
			score += ACCESS_DEAD_CONTINUATION_PENALTY
		elif continuations.size() == 1:
			score += ACCESS_NARROW_CONTINUATION_PENALTY

		# Immediate reversal: if the best next step from the outside tile heads
		# back the way we came, the exit geometry is awkward (wall pocket).
		if not continuations.is_empty():
			var best_next: Vector2i = continuations[0]
			var best_next_metric: float = INF
			for cont in continuations:
				var cont_metric: float
				if use_flow:
					cont_metric = _group_route_cost_at_cell(escape_group, cont)
					if not is_finite(cont_metric):
						cont_metric = float(_manhattan_cell(cont, target_cell))
				else:
					cont_metric = float(_manhattan_cell(cont, target_cell))
				if cont_metric < best_next_metric:
					best_next_metric = cont_metric
					best_next = cont
			var exit_dir: Vector2i = outside_neighbor - access_cell
			var best_dir: Vector2i = best_next - outside_neighbor
			var dot: int = signi(exit_dir.x) * signi(best_dir.x) + signi(exit_dir.y) * signi(best_dir.y)
			if dot < 0:
				score += ACCESS_REVERSAL_PENALTY
			elif dot == 0:
				score += ACCESS_TURN_PENALTY

		# Small cramped penalty: blocked cardinal tiles around the outside cell.
		# Kept tiny so it can never dominate a real door's distance advantage.
		score += float(_blocked_cardinal_count(outside_neighbor)) * ACCESS_BLOCKED_CARDINAL_PENALTY
	else:
		# Enter mode: agent heads inward, so outside continuation matters less and
		# we do not penalize "outside farther than inside" (direction is reversed).
		var enter_continuations: int = 0
		for cont in _valid_walkable_neighbors_no_corner_cut(outside_neighbor):
			if cont == access_cell:
				continue
			enter_continuations += 1
		if enter_continuations == 0:
			score += ACCESS_ENTER_DEAD_CONTINUATION_PENALTY
		elif enter_continuations == 1:
			score += ACCESS_ENTER_NARROW_CONTINUATION_PENALTY
		score += float(_blocked_cardinal_count(outside_neighbor)) * ACCESS_BLOCKED_CARDINAL_PENALTY

	return score

# Count of the 4 cardinal neighbors of `cell` that are not walkable.
func _blocked_cardinal_count(cell: Vector2i) -> int:
	var blocked: int = 0
	if not _is_walkable(cell + Vector2i(1, 0)):
		blocked += 1
	if not _is_walkable(cell + Vector2i(-1, 0)):
		blocked += 1
	if not _is_walkable(cell + Vector2i(0, 1)):
		blocked += 1
	if not _is_walkable(cell + Vector2i(0, -1)):
		blocked += 1
	return blocked

# Shared scored selector for garden access cells. Loops entry_cells, scores each
# candidate, and returns the lowest-scoring one, tie-broken by old Manhattan
# distance to target_cell for predictable behavior. If every candidate scores INF
# (or scoring finds nothing usable), falls back to the old pure-Manhattan logic.
func _select_scored_garden_entry(
	garden_id: int,
	target_cell: Vector2i,
	mode: String,
	forbidden_cell: Vector2i = INVALID_CELL,
	escape_group: int = -1
) -> Vector2i:
	if not _gardens.has(garden_id):
		return INVALID_CELL
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var entry_cells: Array = garden.get("entry_cells", []) as Array
	var best_cell: Vector2i = INVALID_CELL
	var best_score: float = INF
	var best_tiebreak: int = 2147483647
	for raw_cell in entry_cells:
		var cell: Vector2i = raw_cell
		var score: float = _score_garden_access_cell(garden_id, cell, target_cell, mode, forbidden_cell, escape_group)
		if not is_finite(score):
			continue
		var tiebreak: int = _manhattan_cell(cell, target_cell)
		if score < best_score or (score == best_score and tiebreak < best_tiebreak):
			best_score = score
			best_tiebreak = tiebreak
			best_cell = cell
	if best_cell != INVALID_CELL:
		# Gated on the opt-in export (defaults off) so the debug overlay's
		# per-frame path queries can't spam this; selection itself is rare.
		if debug_logs:
			print("BuildingManager: garden %d %s access %s score=%.1f target=%s" % [garden_id, mode, str(best_cell), best_score, str(target_cell)])
		return best_cell
	# Nothing scored finite: fall back to the old Manhattan nearest logic so
	# behavior is never worse than before.
	return _nearest_garden_entry_manhattan(garden_id, target_cell, forbidden_cell)

# Old pure-Manhattan nearest-entry selection, preserved as the fallback for the
# scored selector. Honors forbidden_cell (pass INVALID_CELL to disable).
func _nearest_garden_entry_manhattan(garden_id: int, from_cell: Vector2i, forbidden_cell: Vector2i = INVALID_CELL) -> Vector2i:
	if not _gardens.has(garden_id):
		return INVALID_CELL
	var garden: Dictionary = _gardens[garden_id] as Dictionary
	var entry_cells: Array = garden.get("entry_cells", []) as Array
	var best_cell: Vector2i = INVALID_CELL
	var best_dist: int = 2147483647
	for raw_cell in entry_cells:
		var cell: Vector2i = raw_cell
		if cell == forbidden_cell:
			continue
		if not _is_walkable(cell):
			continue
		var manhattan: int = _manhattan_cell(cell, from_cell)
		if manhattan < best_dist:
			best_dist = manhattan
			best_cell = cell
	return best_cell

# Clears the memoized garden-entry resolution. Called from every rebuild path
# that can change garden topology, entries, walls, or routes. Cheap (a dict
# clear); the optional reason is only for tracing if we ever log it.
func _clear_garden_entry_resolve_cache(_reason: String = "") -> void:
	_garden_entry_resolve_cache.clear()

func _garden_entry_resolve_cache_key(garden_id: int, from_cell: Vector2i) -> String:
	# Source cell + garden fully determine the scored "enter" entry, so the key
	# includes the spawner/source context (never garden_id alone — that would let
	# monsters from different spawners share a far/bad entry).
	return "%s|%d" % [str(from_cell), garden_id]

func _nearest_garden_entry(garden_id: int, from_cell: Vector2i) -> Vector2i:
	# Memoized: the retarget path calls this once per (spawner, garden) for every
	# agent, and the scored selection is the dominant cost in target_resolve.
	var cache_key: String = _garden_entry_resolve_cache_key(garden_id, from_cell)
	if _garden_entry_resolve_cache.has(cache_key):
		var cached: Vector2i = _garden_entry_resolve_cache[cache_key] as Vector2i
		# Cheap validation before trusting the cached entry. A real INVALID_CELL is a
		# legitimate cached "no entry" result and is reused as-is; only a finite cell
		# is re-checked for garden existence + membership + walkability.
		if cached == INVALID_CELL:
			_garden_entry_resolve_cache_hit = true
			return cached
		if _gardens.has(garden_id):
			var garden: Dictionary = _gardens[garden_id] as Dictionary
			var entry_cells: Array = garden.get("entry_cells", []) as Array
			if entry_cells.has(cached) and _is_walkable(cached):
				_garden_entry_resolve_cache_hit = true
				return cached
		# Stale (garden gone, entry no longer listed, or no longer walkable): drop it
		# and fall through to recompute.
		_garden_entry_resolve_cache.erase(cache_key)
	_garden_entry_resolve_cache_hit = false
	var entry: Vector2i = _select_scored_garden_entry(garden_id, from_cell, "enter")
	_garden_entry_resolve_cache[cache_key] = entry
	return entry

func _nearest_garden_entry_to_exit(garden_id: int, spawner_cell: Vector2i) -> Vector2i:
	var exit_wall_cell: Vector2i = INVALID_CELL
	var spawner_route: Dictionary = _spawner_routes.get(spawner_cell, {}) as Dictionary
	exit_wall_cell = spawner_route.get("exit_wall_cell", INVALID_CELL) as Vector2i
	var escape_group: int = int(spawner_route.get("escape_group", -1))
	if exit_wall_cell == INVALID_CELL:
		return _select_scored_garden_entry(garden_id, spawner_cell, "exit", INVALID_CELL, escape_group)
	return _select_scored_garden_entry(garden_id, exit_wall_cell, "exit", INVALID_CELL, escape_group)

func _log(message: String) -> void:
	if debug_logs:
		print("BuildingManager: ", message)

func _log_spawn_failure(message: String) -> void:
	var now_ms: int = Time.get_ticks_msec()
	var last_ms: int = int(_last_spawn_failure_at_ms.get(message, -SPAWN_FAILURE_WARN_INTERVAL_MS))
	if now_ms - last_ms < SPAWN_FAILURE_WARN_INTERVAL_MS:
		return
	_last_spawn_failure = message
	_last_spawn_failure_at_ms[message] = now_ms
	push_warning("BuildingManager: " + message)

func _log_scan_summary(seen_spawners: Dictionary, migrated: bool, walls_changed: bool) -> void:
	var plant_count: int = int(plant_manager.call("size")) if plant_manager and plant_manager.has_method("size") else 0
	var summary: String = "scan indexed_plants=%d spawners=%d registered_spawners=%d migrated=%s walls_changed=%s" % [
		plant_count,
		seen_spawners.size(),
		_spawners.size(),
		migrated,
		walls_changed
	]
	if summary == _last_scan_summary:
		return
	_last_scan_summary = summary
	_log(summary)
