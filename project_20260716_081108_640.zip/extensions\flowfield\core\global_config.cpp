#include "global_config.h"
#include <algorithm>

namespace ffcore
{
    static GlobalConfig g_config;

    GlobalConfig &globalconfig()
    {
        return g_config;
    }

    void GlobalConfig::recompute_from_tile()
    {
        // use global_config.h !! those values arent used.
        wall_avoid_radius = tile_size * 1.2;
        direct_steer_radius = tile_size * 2.5;     
        target_T2_param_margin = tile_size * 2.0;
        separation_radius = tile_size;
        // vitesse cible ratio reste inchangée; lerp constant
    }

    void reset_globalconfig()
    {
        g_config = GlobalConfig();
    }

} // namespace ffcore
