extends Node
## Global game state singleton (autoloaded as "GameState").
## Owns the current top-level gameplay phase and shared run data.

enum GameplayPhase {
	AFTERNOON,
	NIGHT,
	DAWN,
	MORNING,
}

## Emitted whenever the day/night mode changes. `is_night` is the new value.
signal mode_changed(is_night: bool)
signal gameplay_phase_changed(phase: int)
signal afternoon_phase_changed(is_afternoon_phase: bool)
signal dawn_phase_changed(is_dawn_phase: bool)
signal morning_phase_changed(is_morning_phase: bool)
signal client_phase_changed(is_client_phase: bool)
signal seed_merchant_phase_changed(is_seed_merchant_phase: bool)

## The single authoritative owner of the run's broad phase. Narrow flags such as
## `is_client_phase` and `is_seed_merchant_phase` describe activity within it.
var gameplay_phase: int = GameplayPhase.AFTERNOON
var is_afternoon_phase: bool = true
var is_night: bool = false
var is_dawn_phase: bool = false
var is_morning_phase: bool = false
var is_client_phase: bool = false
var is_seed_merchant_phase: bool = false
var is_reservoir_destroyed: bool = false
## True once the player has survived every authored night and the trailing client
## day has finished with the reservoir still alive. Latched by BuildingManager and
## polled by the victory modal; reset on any fresh run.
var is_run_won: bool = false
## True once the player has bought at least one item during the current seed-merchant
## visit. Reset each time a new merchant phase begins; drives the "close the transaction"
## tutorial prompt once the player walks away from the (now hidden) merchant shop.
var seed_merchant_purchase_made: bool = false

## Night special-reward claim tracking. Per-reward keys are "night_index:reward_key".
## `_claimed_one_time_night_rewards` also accepts legacy integer night indices from older
## saves, which still hide the whole old reward bundle for that night.
var _claimed_one_time_night_rewards: Dictionary = {}
var _special_reward_claim_days: Dictionary = {}
var _special_reward_legacy_claim_day: int = -1
var _emitting_restored_phase_signals: bool = false

const SELECTED_LEVEL_META: StringName = &"selected_level_scene_path"
const STARTUP_SAVE_PATH_META: StringName = &"startup_save_path"
const FORCE_LEVEL_SELECTION_META: StringName = &"force_level_selection"


## Reset autoload-only gameplay flags before a fresh main scene is loaded.
## This is intentionally silent: callers use it while replacing/reloading scenes, so
## emitting mode_changed would let the outgoing scene advance a day or start phases.
func reset_transient_run_state() -> void:
	gameplay_phase = GameplayPhase.AFTERNOON
	is_afternoon_phase = true
	is_night = false
	is_dawn_phase = false
	is_morning_phase = false
	is_client_phase = false
	is_seed_merchant_phase = false
	is_reservoir_destroyed = false
	is_run_won = false
	seed_merchant_purchase_made = false


## Restore a canonical phase without running transition side effects. Runtime systems
## rebuild their own state after the save sections have been applied.
func restore_gameplay_phase_flags(phase_name: String) -> void:
	_apply_gameplay_phase(_phase_from_name(phase_name), false)
	is_client_phase = gameplay_phase == GameplayPhase.MORNING
	is_seed_merchant_phase = false
	seed_merchant_purchase_made = false


func emit_restored_phase_signals() -> void:
	_emitting_restored_phase_signals = true
	mode_changed.emit(is_night)
	gameplay_phase_changed.emit(gameplay_phase)
	_emit_phase_flag_signals()
	_emitting_restored_phase_signals = false


func is_emitting_restored_phase_signals() -> bool:
	return _emitting_restored_phase_signals


## Switch to night: monsters are allowed to spawn.
func start_night() -> void:
	set_gameplay_phase(GameplayPhase.NIGHT)


## Switch to day: monster spawning is suppressed.
func start_day() -> void:
	start_dawn()


func start_afternoon() -> void:
	set_gameplay_phase(GameplayPhase.AFTERNOON)


func start_dawn() -> void:
	set_gameplay_phase(GameplayPhase.DAWN)


func start_morning() -> void:
	set_gameplay_phase(GameplayPhase.MORNING)


func set_reservoir_destroyed(value: bool) -> void:
	is_reservoir_destroyed = value


func set_run_won(value: bool) -> void:
	is_run_won = value


func set_client_phase(value: bool) -> void:
	if value and gameplay_phase != GameplayPhase.MORNING:
		start_morning()
	if is_client_phase == value:
		return
	is_client_phase = value
	client_phase_changed.emit(is_client_phase)


func set_seed_merchant_phase(value: bool) -> void:
	if is_seed_merchant_phase == value:
		return
	is_seed_merchant_phase = value
	if value:
		seed_merchant_purchase_made = false
	seed_merchant_phase_changed.emit(is_seed_merchant_phase)


## Toggle between day and night.
func toggle() -> void:
	# Manual toggles cannot end the night while monsters remain on the map.
	# The building manager calls start_day() separately once the group is empty.
	if is_night and get_tree().get_first_node_in_group(&"monsters") != null:
		return
	set_night(not is_night)


func set_night(value: bool) -> void:
	if value:
		start_night()
	elif is_night:
		start_dawn()


func set_gameplay_phase(value: int) -> void:
	if value < GameplayPhase.AFTERNOON or value > GameplayPhase.MORNING:
		push_error("GameState: invalid gameplay phase %d" % value)
		return
	if gameplay_phase == value:
		return
	var was_night: bool = is_night
	_apply_gameplay_phase(value, true)
	if was_night != is_night:
		mode_changed.emit(is_night)
	gameplay_phase_changed.emit(gameplay_phase)


func gameplay_phase_name() -> String:
	match gameplay_phase:
		GameplayPhase.NIGHT:
			return "night"
		GameplayPhase.DAWN:
			return "dawn"
		GameplayPhase.MORNING:
			return "morning"
		_:
			return "afternoon"


func canonical_phase_name_from_legacy(legacy_phase: String) -> String:
	match legacy_phase:
		"night":
			return "night"
		"morning", "seed_merchant":
			return "dawn"
		"client":
			return "morning"
		_:
			return "afternoon"


func _phase_from_name(phase_name: String) -> int:
	match phase_name:
		"night":
			return GameplayPhase.NIGHT
		"dawn":
			return GameplayPhase.DAWN
		"morning":
			return GameplayPhase.MORNING
		_:
			return GameplayPhase.AFTERNOON


func _apply_gameplay_phase(value: int, emit_flag_signals: bool) -> void:
	var previous_afternoon: bool = is_afternoon_phase
	var previous_dawn: bool = is_dawn_phase
	var previous_morning: bool = is_morning_phase
	var previous_client: bool = is_client_phase
	var previous_seed_merchant: bool = is_seed_merchant_phase
	gameplay_phase = value
	is_afternoon_phase = value == GameplayPhase.AFTERNOON
	is_night = value == GameplayPhase.NIGHT
	is_dawn_phase = value == GameplayPhase.DAWN
	is_morning_phase = value == GameplayPhase.MORNING
	if not is_morning_phase:
		is_client_phase = false
	if is_night:
		is_seed_merchant_phase = false
	if not emit_flag_signals:
		return
	if previous_afternoon != is_afternoon_phase:
		afternoon_phase_changed.emit(is_afternoon_phase)
	if previous_dawn != is_dawn_phase:
		dawn_phase_changed.emit(is_dawn_phase)
	if previous_morning != is_morning_phase:
		morning_phase_changed.emit(is_morning_phase)
	if previous_client != is_client_phase:
		client_phase_changed.emit(is_client_phase)
	if previous_seed_merchant != is_seed_merchant_phase:
		seed_merchant_phase_changed.emit(is_seed_merchant_phase)


func _emit_phase_flag_signals() -> void:
	afternoon_phase_changed.emit(is_afternoon_phase)
	dawn_phase_changed.emit(is_dawn_phase)
	morning_phase_changed.emit(is_morning_phase)
	client_phase_changed.emit(is_client_phase)
	seed_merchant_phase_changed.emit(is_seed_merchant_phase)


func set_selected_level_scene_path(scene_path: String) -> void:
	set_meta(SELECTED_LEVEL_META, scene_path)


func clear_selected_level_scene_path() -> void:
	if has_meta(SELECTED_LEVEL_META):
		remove_meta(SELECTED_LEVEL_META)


func get_selected_level_scene_path() -> String:
	return str(get_meta(SELECTED_LEVEL_META, ""))


func request_startup_save_load(save_path: String) -> void:
	set_meta(STARTUP_SAVE_PATH_META, save_path)


func consume_startup_save_load_path(default_save_path: String) -> String:
	if has_meta(STARTUP_SAVE_PATH_META):
		var save_path: String = str(get_meta(STARTUP_SAVE_PATH_META, default_save_path))
		remove_meta(STARTUP_SAVE_PATH_META)
		return save_path
	return ""


func force_level_selection_once() -> void:
	set_meta(FORCE_LEVEL_SELECTION_META, true)


func consume_force_level_selection() -> bool:
	if not has_meta(FORCE_LEVEL_SELECTION_META):
		return false
	remove_meta(FORCE_LEVEL_SELECTION_META)
	return true


## True when the current night's special reward can still be collected: a one-time
## reward not yet claimed this run, and not already collected earlier today.
func is_special_reward_available(night_index: int, day_number: int, one_time: bool, reward_key: String = "") -> bool:
	if one_time and _claimed_one_time_night_rewards.has(night_index):
		return false
	if _special_reward_legacy_claim_day == day_number:
		return false
	if reward_key == "":
		return true
	var claim_key: String = _special_reward_claim_key(night_index, reward_key)
	if one_time and _claimed_one_time_night_rewards.has(claim_key):
		return false
	if int(_special_reward_claim_days.get(claim_key, -1)) == day_number:
		return false
	return true


## Record that the current night's special reward was collected on `day_number`.
func record_special_reward_claim(night_index: int, day_number: int, one_time: bool, reward_key: String = "") -> void:
	if reward_key == "":
		_special_reward_legacy_claim_day = day_number
		return
	var claim_key: String = _special_reward_claim_key(night_index, reward_key)
	_special_reward_claim_days[claim_key] = day_number
	if one_time:
		_claimed_one_time_night_rewards[claim_key] = true


func reset_special_reward_claims() -> void:
	_claimed_one_time_night_rewards.clear()
	_special_reward_claim_days.clear()
	_special_reward_legacy_claim_day = -1


## Serialize claim state for the save file.
func get_special_reward_claim_save_data() -> Dictionary:
	var claimed: Array = []
	for raw_index: Variant in _claimed_one_time_night_rewards.keys():
		claimed.append(raw_index)
	return {
		"claimed_one_time": claimed,
		"claim_day": _special_reward_legacy_claim_day,
		"claim_days": _special_reward_claim_days.duplicate(),
	}


## Restore claim state from a save file (missing/invalid data resets to empty).
func apply_special_reward_claim_save_data(data: Dictionary) -> void:
	reset_special_reward_claims()
	var raw_claimed: Variant = data.get("claimed_one_time", [])
	if raw_claimed is Array:
		for raw_index: Variant in raw_claimed as Array:
			_claimed_one_time_night_rewards[raw_index] = true
	var raw_claim_days: Variant = data.get("claim_days", {})
	if raw_claim_days is Dictionary:
		for raw_key: Variant in (raw_claim_days as Dictionary).keys():
			_special_reward_claim_days[str(raw_key)] = int((raw_claim_days as Dictionary)[raw_key])
	_special_reward_legacy_claim_day = int(data.get("claim_day", -1))


func _special_reward_claim_key(night_index: int, reward_key: String) -> String:
	return "%d:%s" % [night_index, reward_key]
