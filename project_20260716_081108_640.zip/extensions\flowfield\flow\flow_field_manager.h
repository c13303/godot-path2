#pragma once
#include "../core/types.h"
#include "flow_field.h"
#include "../core/nav_config.h"
#include <vector>

namespace ffcore
{
    class FlowFieldManager
    {
    public:
        FlowFieldManager();

        FlowFieldID register_existing(FlowField *f);
        FlowField *get(FlowFieldID id) const;
        void remove(FlowFieldID id);

        FlowFieldID create_field(int width, int height, double tile_size);
        FlowFieldID register_copy(const FlowField &src);
        int used_count() const;
        int capacity() const;
        void collect_occupied_ids(std::vector<FlowFieldID> &out) const;

    private:
        std::vector<FlowField *> fields;
    };

    void cleanup_flow_if_unused(FlowField *ff);

}
